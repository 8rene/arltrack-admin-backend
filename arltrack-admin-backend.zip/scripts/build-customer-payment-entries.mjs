// Generates the customer backend's CommonJS copy of the paymentEntries code from the admin (ESM) source,
// so the two can never drift apart by hand.
//
//   node scripts/build-customer-payment-entries.mjs ../arltrack-customer-backend
//
// Writes (into <customer-backend>/utils/payments/):
//   paymentEntries.mapper.js   <- services/paymentEntries/paymentEntries.mapper.js
//   paymentEntries.core.js     <- services/paymentEntries/paymentEntries.core.js
//   paymentEntries.util.js     <- bound to the customer's Firestore connection
// Re-run it whenever the admin mapper or core changes, then commit the three files.
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const SRC = path.join(HERE, "..", "services", "paymentEntries");
const target = process.argv[2];
if (!target) { console.error("usage: node scripts/build-customer-payment-entries.mjs <path-to-arltrack-customer-backend>"); process.exit(1); }
const OUT = path.join(target, "utils", "payments");
if (!fs.existsSync(path.join(OUT, "paymentBreakdown.util.js"))) { console.error(`not a customer backend: ${OUT}/paymentBreakdown.util.js is missing`); process.exit(1); }

const HEADER = (name) => `// GENERATED from arltrack-admin-backend/services/paymentEntries/${name} -- DO NOT EDIT BY HAND.\n// Change the admin file, then run: node scripts/build-customer-payment-entries.mjs <this repo>\n`;
const must = (src, from, to, label) => { if (!src.includes(from)) throw new Error(`build: could not find ${label} in source`); return src.replace(from, to); };

// ── mapper ──
let mapper = fs.readFileSync(path.join(SRC, "paymentEntries.mapper.js"), "utf8").replace(/\r\n/g, "\n");
mapper = must(mapper, 'import { getPaymentBreakdown, resolvePaymongoIDs, payTypeOf } from "../payments/paymentBreakdown.js";',
  'const { getPaymentBreakdown, resolvePaymongoIDs, payTypeOf } = require("./paymentBreakdown.util");', "breakdown import");
mapper = mapper.replace(/export \{([\s\S]*?)\};\s*$/, (_, names) => `module.exports = {${names}};\n`);
if (/^export /m.test(mapper) || /^import /m.test(mapper)) throw new Error("build: mapper still has ESM syntax");

// ── core ──
let core = fs.readFileSync(path.join(SRC, "paymentEntries.core.js"), "utf8").replace(/\r\n/g, "\n");
core = core.replace(/import \{ ENTRY_COLLECTION \} from "[^"]+";\n/, 'const ENTRY_COLLECTION = "paymentEntries";\n');
core = core.replace(/import \{([\s\S]*?)\} from "\.\/paymentEntries\.mapper\.js";\n/, (_, names) => `const {${names}} = require("./paymentEntries.mapper");\n`);
core = core.replace(/export \{([\s\S]*?)\};\s*$/, (_, names) => `module.exports = {${names}};\n`);
if (/^export /m.test(core) || /^import /m.test(core)) throw new Error("build: core still has ESM syntax");

const util = `${HEADER("paymentEntries.core.js")}// paymentEntries bound to the customer backend's Firestore connection.
// syncPaymentEntries(paymentDocID, opts) re-derives a payment's deposit / balance rows from the document
// after it was written. It NEVER throws -- a failure must not block a real payment.
const { db } = require("../../config/firebaseConnection/firebase");
const { makeEntriesDb } = require("./paymentEntries.core");

const svc = makeEntriesDb(db);

module.exports = {
  syncPaymentEntries:      svc.syncPaymentEntries,
  getEntriesForPaymentIDs: svc.getEntriesForPaymentIDs,
  hydratePayments:         svc.hydratePayments,
};
`;
fs.writeFileSync(path.join(OUT, "paymentEntries.mapper.js"), HEADER("paymentEntries.mapper.js") + mapper);
fs.writeFileSync(path.join(OUT, "paymentEntries.core.js"), HEADER("paymentEntries.core.js") + core);
fs.writeFileSync(path.join(OUT, "paymentEntries.util.js"), util);
console.log(`wrote 3 files to ${OUT}`);
