// One-off: remove the "migratedFrom" field from paymentEntries, driverAssignments and
// cancellationRequests rows.
// Put this file in arltrack-admin-backend/scripts/ and run it from arltrack-admin-backend/.
//
//   node scripts/remove-migrated-from.js                        dry run, all 3 collections (writes nothing)
//   node scripts/remove-migrated-from.js --write                removes the field from all 3
//   node scripts/remove-migrated-from.js --only=driverAssignments,cancellationRequests --write
//                                                               only the collections you list
//
// NOTE: paymentEntries.migratedFrom is also removed by scripts/migrate-entry-columns.js (along with the other
// retired entry columns), and no code writes it any more. This script is still the way to clear it from
// driverAssignments and cancellationRequests.
//
// Safe to re-run. Only the field "migratedFrom" is removed; nothing else on the rows is touched.
// Nothing in the app reads this field. The payment migration's rollback works from the report
// file's list of row ids, so it does NOT need the field either.
import "dotenv/config";
import admin from "firebase-admin";
import { db } from "../config/firebaseConnection/firebase.js";

const COLLECTIONS = ["paymentEntries", "driverAssignments", "cancellationRequests"];
const WRITE = process.argv.includes("--write");
const onlyArg = process.argv.find((a) => a.startsWith("--only="));
const targets = onlyArg ? onlyArg.slice(7).split(",").map((s) => s.trim()).filter(Boolean) : COLLECTIONS;
const unknown = targets.filter((t) => !COLLECTIONS.includes(t));
if (unknown.length) { console.error(`Unknown collection(s): ${unknown.join(", ")}. Choose from: ${COLLECTIONS.join(", ")}`); process.exit(1); }

const FieldValue = admin.firestore.FieldValue;

try {
  console.log(`REMOVE migratedFrom -- ${WRITE ? "WRITE" : "DRY RUN (nothing will be written)"}\n`);
  for (const name of targets) {
    const snap = await db.collection(name).get();
    const withField = snap.docs.filter((d) => Object.prototype.hasOwnProperty.call(d.data(), "migratedFrom"));
    const byValue = {};
    withField.forEach((d) => { const v = String(d.data().migratedFrom); byValue[v] = (byValue[v] || 0) + 1; });
    console.log(`${name}`);
    console.log(`  rows scanned          : ${snap.size}`);
    console.log(`  rows with migratedFrom: ${withField.length}   ${JSON.stringify(byValue)}`);

    if (WRITE && withField.length) {
      let batch = db.batch(); let n = 0;
      for (const d of withField) {
        batch.update(d.ref, { migratedFrom: FieldValue.delete() });
        n += 1;
        if (n >= 400) { await batch.commit(); batch = db.batch(); n = 0; }
      }
      if (n) await batch.commit();
      console.log(`  removed from ${withField.length} rows.`);
    }
    console.log("");
  }
  console.log(WRITE ? "Done." : "(dry run -- add --write to apply)");
  process.exit(0);
} catch (err) {
  console.error("Failed:", err);
  process.exit(1);
}