// READ-ONLY scan. Never writes. Run it before the migration (what will it find?) and after
// (do the entries match the documents?).
//
//   node scripts/check-payment-fields.js
//   node scripts/check-payment-fields.js --verbose      list every id, not the first 10
//
// Reports:
//   1. data problems the migration will flag (online + paid but no pay_ id, discounts, unknown methods ...)
//   2. if paymentEntries already exists: payments with no / different entries, orphan entries,
//      penalties whose rows don't add up to what was paid
//   3. transaction logs still carrying refundRequestID without refID, and sentinel reference numbers
import { fileURLToPath, pathToFileURL } from "node:url";
import { ENTRY_COLLECTION } from "../models/paymentEntries/paymentEntry.model.js";
import { buildPaymentEntries, buildLegacyPenaltyEntry, nullIfSentinel } from "../services/paymentEntries/paymentEntries.mapper.js";

export const main = async ({ db, argv = [], log = console.log }) => {
  const verbose = argv.includes("--verbose");
  const show = (ids) => (ids.length ? "  " + (verbose ? ids : ids.slice(0, 10)).join(", ") + (!verbose && ids.length > 10 ? ` … (+${ids.length - 10})` : "") : "");
  const load = async (name) => (await db.collection(name).get()).docs.map((d) => ({ id: d.id, data: d.data() }));

  const [payments, archivedPayments, penalties, archivedPenalties, entries, logs] = await Promise.all([
    load("payments"), load("paymentsArchives"), load("penalties"), load("penaltyArchives"), load(ENTRY_COLLECTION), load("transactionLogs"),
  ]);
  const result = { problems: {}, verify: {} };
  const P = result.problems; const V = result.verify;
  const all = [...payments.map((d) => ({ ...d, archived: false })), ...archivedPayments.map((d) => ({ ...d, archived: true }))];

  // ── 1. what the migration will find ──
  const byStatus = {};
  P.missingPaymentID = []; P.discountReview = []; P.amountInferred = []; P.unmappedMethod = []; P.notStarted = []; P.refunded = [];
  P.sentinelReference = 0;
  const expectedByPayment = new Map();
  for (const d of all) {
    const docID = d.data.originalId || d.id; const pid = d.data.paymentID || docID;
    byStatus[String(d.data.status || "?").toLowerCase()] = (byStatus[String(d.data.status || "?").toLowerCase()] || 0) + 1;
    const { entries: exp, skipped } = buildPaymentEntries(d.data, docID);
    expectedByPayment.set(pid, exp);
    if (skipped.some((s) => s.phase === "deposit" && s.reason === "not_started")) P.notStarted.push(pid);
    for (const e of exp) {
      if (e.flags.includes("missing_payment_id")) P.missingPaymentID.push(pid);
      if (e.flags.includes("discount_review")) P.discountReview.push(pid);
      if (e.flags.includes("amount_inferred")) P.amountInferred.push(pid);
      if (e.flags.includes("refunded_legacy")) P.refunded.push(pid);
      e.flags.filter((f) => f.startsWith("method_unmapped:")).forEach((f) => P.unmappedMethod.push(`${pid} ${f.slice(16)}`));
    }
    const rn = d.data.referenceNumber;
    if (!d.archived && rn !== undefined && rn !== null && nullIfSentinel(rn) === null) P.sentinelReference += 1;
  }
  log(`\npayments: ${payments.length} live, ${archivedPayments.length} archived     status: ${JSON.stringify(byStatus)}`);
  log(`  online + paid, NO payment id ("Payment ID does not exist")  : ${P.missingPaymentID.length}${show(P.missingPaymentID)}`);
  log(`  staff discount, paid amount unconfirmed                      : ${P.discountReview.length}${show(P.discountReview)}`);
  log(`  balance collected, amount not recorded (inferred)            : ${P.amountInferred.length}${show(P.amountInferred)}`);
  log(`  already Refunded (refund rows come in step 2)                : ${P.refunded.length}`);
  log(`  deposit checkout never started (no row will be made)         : ${P.notStarted.length}`);
  log(`  unknown payment method text                                  : ${P.unmappedMethod.length}${show(P.unmappedMethod)}`);
  log(`  payments.referenceNumber that is "N/A" / "—" / ""            : ${P.sentinelReference}`);

  // penalties
  const paymentsByID = new Map(all.map((d) => [d.data.paymentID || d.data.originalId || d.id, d.data]));
  P.penaltyDepositInvolved = []; let penaltyConvertible = 0; let penaltyOffset = 0;
  for (const d of [...penalties, ...archivedPenalties]) {
    const penaltyID = d.data.penaltyID || d.data.originalId || d.id;
    const out = buildLegacyPenaltyEntry({ ...d.data, penaltyID }, penaltyID, paymentsByID.get(d.data.paymentID));
    if (out.entry) penaltyConvertible += 1; else if (out.review === "deposit_involved") P.penaltyDepositInvolved.push(penaltyID); else if (out.review === "deposit_offset") penaltyOffset += 1;
  }
  log(`\npenalties: ${penalties.length} live, ${archivedPenalties.length} archived`);
  log(`  paid with real money -> one row each                         : ${penaltyConvertible}`);
  log(`  covered entirely by the deposit (no money moved, no row)     : ${penaltyOffset}`);
  log(`  on a deposit-settled booking (CANNOT be split -- staff review): ${P.penaltyDepositInvolved.length}${show(P.penaltyDepositInvolved)}`);

  // ── 2. entries vs documents ──
  log(`\npaymentEntries: ${entries.length} rows`);
  if (!entries.length) {
    log("  (none yet -- nothing to verify)");
  } else {
    const byPayment = new Map(); const byRef = new Map();
    for (const e of entries) {
      const id = e.data.paymentID;
      if (id) (byPayment.get(id) || byPayment.set(id, []).get(id)).push(e.data);
      if (e.data.refCollection === "penalties") (byRef.get(e.data.refID) || byRef.set(e.data.refID, []).get(e.data.refID)).push(e.data);
    }
    V.missing = []; V.different = [];
    for (const [pid, exp] of expectedByPayment) {
      const have = new Map((byPayment.get(pid) || []).map((e) => [e.paymentEntryID, e]));
      for (const e of exp) {
        const h = have.get(e.paymentEntryID);
        if (!h) V.missing.push(e.paymentEntryID);
        else if (h.amount !== e.amount || h.status !== e.status || h.source !== e.source) V.different.push(`${e.paymentEntryID} (have ${h.status} ₱${h.amount}, document says ${e.status} ₱${e.amount})`);
      }
    }
    V.orphans = entries.filter((e) => e.data.paymentID && !expectedByPayment.has(e.data.paymentID)).map((e) => e.id);
    V.penaltyMismatch = [];
    for (const d of [...penalties, ...archivedPenalties]) {
      const penaltyID = d.data.penaltyID || d.data.originalId || d.id;
      const rows = (byRef.get(penaltyID) || []).filter((r) => r.status === "success" && r.direction === "in");
      if (!rows.length) continue;
      const sum = rows.reduce((a, r) => a + r.amount, 0);
      if (sum > Number(d.data.paidAmount || 0)) V.penaltyMismatch.push(`${penaltyID} (rows ₱${sum} > paidAmount ₱${d.data.paidAmount || 0})`);
    }
    log(`  payments whose expected rows are MISSING                     : ${V.missing.length}${show(V.missing)}`);
    log(`  rows that DISAGREE with their payment document               : ${V.different.length}${show(V.different)}`);
    log(`  orphan rows (their payment no longer exists)                 : ${V.orphans.length}${show(V.orphans)}`);
    log(`  penalties whose rows add up to MORE than paidAmount          : ${V.penaltyMismatch.length}${show(V.penaltyMismatch)}`);
  }

  // ── 3. logs ──
  const refPending = logs.filter((l) => l.data.refundRequestID && !l.data.refID).length;
  const logSentinel = logs.filter((l) => l.data.referenceNumber !== undefined && l.data.referenceNumber !== null && nullIfSentinel(l.data.referenceNumber) === null).length;
  log(`\ntransactionLogs: ${logs.length}`);
  log(`  with refundRequestID but no refID yet                        : ${refPending}`);
  log(`  with a sentinel referenceNumber ("—" / "")                   : ${logSentinel}`);
  result.logs = { refPending, logSentinel };
  log("\n(read-only: nothing was written)");
  return result;
};

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const { db } = await import("../config/firebaseConnection/firebase.js");
  try { await main({ db, argv: process.argv.slice(2) }); process.exit(0); }
  catch (err) { console.error("Check failed:", err); process.exit(1); }
}
