// READ-ONLY full export of your Firestore data to local JSON files. Never writes to Firestore.
// Put this file in arltrack-admin-backend/scripts/ and run it from arltrack-admin-backend/.
//
//   node scripts/export-firestore.js                          every top-level collection + subcollections
//   node scripts/export-firestore.js --only=payments,penalties   just those collections
//   node scripts/export-firestore.js --no-subcollections      skip subcollections (faster)
//
// Output: scripts/exports/firestore-export-<timestamp>/
//   <collection>.json     array of { id, path, data }       (subcollections: parent__doc__child.json)
//   manifest.json         how many documents each file holds
//
// Unlike a plain JSON.stringify, special Firestore types are kept in a tagged form so they can be
// restored exactly (a Timestamp is NOT turned into a plain {_seconds,_nanoseconds} object):
//   Timestamp     -> { "__type": "timestamp", "seconds": n, "nanoseconds": n, "iso": "..." }
//   GeoPoint      -> { "__type": "geopoint", "latitude": n, "longitude": n }
//   Reference     -> { "__type": "reference", "path": "col/doc" }
//   Bytes         -> { "__type": "bytes", "base64": "..." }
//   NaN/Infinity  -> { "__type": "number", "value": "NaN" }
//
// This folder will hold your customers' data (names, emails, payments). Do NOT commit or share it:
// add  scripts/exports/  to .gitignore.
import "dotenv/config";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import admin from "firebase-admin";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const { Timestamp, GeoPoint, DocumentReference } = admin.firestore;

export const encode = (v) => {
  if (v === null || v === undefined) return v === undefined ? null : v;
  if (typeof v === "number") return Number.isFinite(v) ? v : { __type: "number", value: String(v) };
  if (typeof v !== "object") return v;
  if (v instanceof Timestamp) return { __type: "timestamp", seconds: v.seconds, nanoseconds: v.nanoseconds, iso: v.toDate().toISOString() };
  if (v instanceof GeoPoint) return { __type: "geopoint", latitude: v.latitude, longitude: v.longitude };
  if (v instanceof DocumentReference) return { __type: "reference", path: v.path };
  if (v instanceof Date) return { __type: "timestamp", seconds: Math.floor(v.getTime() / 1000), nanoseconds: (v.getTime() % 1000) * 1e6, iso: v.toISOString() };
  if (Buffer.isBuffer(v) || v instanceof Uint8Array) return { __type: "bytes", base64: Buffer.from(v).toString("base64") };
  if (Array.isArray(v)) return v.map(encode);
  return Object.fromEntries(Object.entries(v).map(([k, val]) => [k, encode(val)]));
};

const stamp = (d) => d.toISOString().replace(/[:.]/g, "-");

export const main = async ({ db, argv = [], log = console.log, now = new Date(), outDir = path.join(HERE, "exports") }) => {
  const subs = !argv.includes("--no-subcollections");
  const onlyArg = argv.find((a) => a.startsWith("--only="));
  const only = onlyArg ? onlyArg.slice(7).split(",").map((s) => s.trim()).filter(Boolean) : null;

  const dir = path.join(outDir, `firestore-export-${stamp(now)}`);
  fs.mkdirSync(dir, { recursive: true });
  const manifest = { exportedAt: now.toISOString(), subcollections: subs, only: only || "all", counts: {} };

  const exportCollection = async (colRef) => {
    const snap = await colRef.get();
    const rows = []; const children = [];
    for (const d of snap.docs) {
      rows.push({ id: d.id, path: d.ref.path, data: encode(d.data()) });
      if (subs) for (const c of await d.ref.listCollections()) children.push(c);
    }
    const file = `${colRef.path.replace(/\//g, "__")}.json`;
    fs.writeFileSync(path.join(dir, file), JSON.stringify(rows, null, 2));
    manifest.counts[colRef.path] = rows.length;
    log(`  ${colRef.path.padEnd(48)} ${String(rows.length).padStart(6)} docs`);
    for (const c of children) await exportCollection(c);
  };

  log(`\nEXPORT (read-only) -> ${path.relative(process.cwd(), dir) || dir}\n`);
  const roots = only ? only.map((n) => db.collection(n)) : await db.listCollections();
  for (const c of roots) await exportCollection(c);

  const total = Object.values(manifest.counts).reduce((a, b) => a + b, 0);
  manifest.totalDocuments = total;
  fs.writeFileSync(path.join(dir, "manifest.json"), JSON.stringify(manifest, null, 2));
  log(`\nDone: ${total} documents in ${Object.keys(manifest.counts).length} files.`);
  log("(read-only: nothing was written to Firestore)");
  return { dir, manifest };
};

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const { db } = await import("../config/firebaseConnection/firebase.js");
  try { await main({ db, argv: process.argv.slice(2) }); process.exit(0); }
  catch (err) { console.error("Export failed:", err); process.exit(1); }
}