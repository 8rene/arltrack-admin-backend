// Removes the payment / penalty columns that now live in paymentEntries. Run from arltrack-admin-backend/
//
//   node scripts/remove-payment-leftovers.js                         dry run: report only, nothing written
//   node scripts/remove-payment-leftovers.js --write                 applies it
//   node scripts/remove-payment-leftovers.js --rollback=<file> --write   puts the removed fields back
//
// Run it AFTER the code that no longer writes these fields is deployed (payments.service.js, penalty.service.js).
//
// payments
//   balanceCollected, balanceCollectedAmount   removed only when a settled in-person balance row exists
//                                              (<paymentID>_balance, source "in_person", status "success") and, if the
//                                              payment recorded an amount, the row holds the same amount. A payment
//                                              that says "collected" but has no row is KEPT and listed: pressing
//                                              "Collect balance" again writes the row (see collectRemainingBalance).
//                                              balanceCollected: false / missing is just a default and is removed.
//   refundIssuedBy, refundIssuedAt             removed only when the <paymentID>_discountrefund row exists
// penalties
//   paymentMethod, referenceNumber, paidAt     removed only when readers can get them back:
//                                                - the penalty has settled "penalty" rows in paymentEntries, or
//                                                - it was paid from the deposit and payments.deposit.settlement has a
//                                                  settledAt (hydratePenalty derives "Deposit" / "DepositPartial"), or
//                                                - nothing was paid and the fields are blank
//
// Every write run saves scripts/backups/payment-leftovers-<time>.json BEFORE writing; --rollback restores from it.
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

const EMPTY = new Set(["", "—", "-", "n/a", "na", "none", "null"]);
const isEmpty = (v) => v === undefined || v === null || (typeof v === "string" && EMPTY.has(v.trim().toLowerCase()));
const has = (d, k) => Object.prototype.hasOwnProperty.call(d, k);
const num = (v) => (v === undefined || v === null || v === "" ? 0 : Number(v));
const chunk = (arr, n) => { const out = []; for (let i = 0; i < arr.length; i += n) out.push(arr.slice(i, i + n)); return out; };

const toJSONSafe = (v) => JSON.parse(JSON.stringify(v, function (k, x) {
  const raw = this[k];
  if (raw instanceof Date) return { __ts: raw.getTime() };
  return raw && typeof raw.toMillis === "function" ? { __ts: raw.toMillis() } : x;
}));
const revive = (v) => JSON.parse(JSON.stringify(v), (k, x) => (x && typeof x === "object" && "__ts" in x ? new Date(x.__ts) : x));

const PAYMENT_FIELDS = ["balanceCollected", "balanceCollectedAmount", "refundIssuedBy", "refundIssuedAt"];
const PENALTY_FIELDS = ["paymentMethod", "referenceNumber", "paidAt"];

export const main = async ({ db, FieldValue, argv = [], log = console.log, now = new Date(), outDir } = {}) => {
  const arg = (k) => (argv.find((a) => a.startsWith(`--${k}=`)) || "").slice(k.length + 3);
  const WRITE = argv.includes("--write");
  const rollbackFile = arg("rollback");
  const dir = outDir || path.join(path.dirname(fileURLToPath(import.meta.url)), "backups");
  const commit = async (ops) => { for (const part of chunk(ops, 400)) { const b = db.batch(); part.forEach((op) => op(b)); await b.commit(); } };

  // ── rollback ──
  if (rollbackFile) {
    const saved = JSON.parse(fs.readFileSync(rollbackFile, "utf8"));
    const ops = saved.docs.map((d) => (b) => b.update(db.collection(d.collection).doc(d.id), revive(d.removed)));
    log(`ROLLBACK ${rollbackFile}: ${ops.length} documents${WRITE ? "" : " (dry run -- add --write)"}`);
    if (WRITE) await commit(ops);
    return { restored: WRITE ? ops.length : 0 };
  }

  log(`REMOVE payment leftovers -- ${WRITE ? "WRITE" : "DRY RUN (nothing will be written)"}\n`);
  const entrySnap = await db.collection("paymentEntries").get();
  const entryByID = new Map(entrySnap.docs.map((d) => [d.id, d.data()]));
  const penaltyRows = new Map();   // penaltyID -> settled "penalty" in-rows
  entryByID.forEach((e) => {
    if (e.phase === "penalty" && e.direction !== "out" && e.status === "success" && e.penaltyID) {
      if (!penaltyRows.has(e.penaltyID)) penaltyRows.set(e.penaltyID, []);
      penaltyRows.get(e.penaltyID).push(e);
    }
  });

  const ops = [];
  const backup = [];
  const kept = [];
  const stats = { payments: { scanned: 0, cleaned: 0 }, penalties: { scanned: 0, cleaned: 0 } };
  const plan = (collection, doc, fields, why) => {
    const data = doc.data();
    const present = fields.filter((k) => has(data, k));
    if (!present.length) return;
    backup.push({ collection, id: doc.id, removed: toJSONSafe(Object.fromEntries(present.map((k) => [k, data[k]]))), why });
    ops.push((b) => b.update(doc.ref, Object.fromEntries(present.map((k) => [k, FieldValue.delete()]))));
    stats[collection].cleaned += 1;
  };

  // ── payments ──
  const paySnap = await db.collection("payments").get();
  const paymentsByID = new Map();
  for (const doc of paySnap.docs) {
    stats.payments.scanned += 1;
    const p = doc.data();
    const paymentID = p.paymentID || doc.id;
    paymentsByID.set(paymentID, p);
    const fields = [];

    const bal = entryByID.get(`${paymentID}_balance`);
    const settledInPerson = bal && bal.direction !== "out" && bal.source === "in_person" && bal.status === "success";
    if (has(p, "balanceCollected") || has(p, "balanceCollectedAmount")) {
      if (!p.balanceCollected) {
        fields.push("balanceCollected", "balanceCollectedAmount");               // a default false: nothing to lose
      } else if (!settledInPerson) {
        kept.push(`payments/${doc.id}: balanceCollected but no settled in-person balance row -- kept (press "Collect balance" to write it)`);
      } else if (!isEmpty(p.balanceCollectedAmount) && num(bal.amount) !== num(p.balanceCollectedAmount)) {
        kept.push(`payments/${doc.id}: balanceCollectedAmount ${p.balanceCollectedAmount} differs from the row's ${bal.amount} -- kept`);
      } else {
        fields.push("balanceCollected", "balanceCollectedAmount");
      }
    }
    if (has(p, "refundIssuedBy") || has(p, "refundIssuedAt")) {
      const out = entryByID.get(`${paymentID}_discountrefund`);
      if (out && out.status === "success") fields.push("refundIssuedBy", "refundIssuedAt");
      else kept.push(`payments/${doc.id}: refundIssuedBy/At but no ${paymentID}_discountrefund row -- kept`);
    }
    plan("payments", doc, fields, "balance/refund facts live on entries");
  }

  // ── penalties ──
  const penSnap = await db.collection("penalties").get();
  for (const doc of penSnap.docs) {
    stats.penalties.scanned += 1;
    const pen = doc.data();
    const penaltyID = pen.penaltyID || doc.id;
    if (!PENALTY_FIELDS.some((k) => has(pen, k))) continue;
    const paid = num(pen.paidAmount);
    const methodKey = String(pen.paymentMethod || "").toLowerCase().replace(/[\s_-]/g, "");
    const viaDeposit = methodKey === "deposit" || methodKey === "depositpartial";
    const settledAt = (paymentsByID.get(pen.paymentID) || {}).deposit?.settlement?.settledAt;

    if ((penaltyRows.get(penaltyID) || []).length) plan("penalties", doc, PENALTY_FIELDS, "rows hold method/reference/date");
    else if (paid <= 0 && PENALTY_FIELDS.every((k) => isEmpty(pen[k]))) plan("penalties", doc, PENALTY_FIELDS, "blank, nothing paid");
    else if (paid > 0 && viaDeposit && settledAt) plan("penalties", doc, PENALTY_FIELDS, "deposit offset, date from the settlement");
    else kept.push(`penalties/${doc.id}: paymentMethod "${pen.paymentMethod ?? ""}", paid ₱${paid}, no penalty rows / no deposit settlement -- kept`);
  }

  log(`payments  scanned ${stats.payments.scanned}, to clean ${stats.payments.cleaned}`);
  log(`penalties scanned ${stats.penalties.scanned}, to clean ${stats.penalties.cleaned}`);
  if (kept.length) { log(`\nKept (${kept.length}) -- not proven to live elsewhere:`); kept.slice(0, 40).forEach((s) => log(`  ${s}`)); if (kept.length > 40) log(`  ... and ${kept.length - 40} more`); }

  const report = { stats, kept, rows: ops.length };
  if (WRITE && ops.length) {
    fs.mkdirSync(dir, { recursive: true });
    const file = path.join(dir, `payment-leftovers-${now.toISOString().replace(/[:.]/g, "-")}.json`);
    fs.writeFileSync(file, JSON.stringify({ at: now.toISOString(), docs: backup }, null, 1));   // BEFORE any write
    await commit(ops);
    report.file = file;
    log(`\nDone. ${ops.length} documents updated. Backup: ${file}`);
    log(`Undo with: node scripts/remove-payment-leftovers.js --rollback=${file} --write`);
  } else if (!WRITE) {
    log("\n(dry run -- add --write to apply)");
  }
  return report;
};

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  await import("dotenv/config");
  const { default: admin } = await import("firebase-admin");
  const { db } = await import("../config/firebaseConnection/firebase.js");
  try { await main({ db, FieldValue: admin.firestore.FieldValue, argv: process.argv.slice(2) }); process.exit(0); }
  catch (err) { console.error("Failed:", err); process.exit(1); }
}
