// One-off migration: bookings + bookingArchives
//
//   Renames the field `returnedAt` -> `completedAt`.
//
// `returnedAt` was stamped when staff closed a trip (the "Return" button, now "Mark Complete"),
// so it never meant "the car came back" (that is the session's droppedOffTime). `completedAt`
// says what it really is. The value is copied as-is (Firestore Timestamp stays a Timestamp) and
// then `returnedAt` is removed from the document.
//
// Put this file in arltrack-admin-backend/scripts/ and run it from arltrack-admin-backend/.
// DRY RUN BY DEFAULT. Nothing is written unless you pass --write.
//
//   node scripts/migrate-returnedAt-to-completedAt.js           dry run (report only)
//   node scripts/migrate-returnedAt-to-completedAt.js --write   apply
//
// Order:
//   1. Take an export first:  node scripts/export-firestore.js --only=bookings,bookingArchives
//   2. Deploy the backend that writes `completedAt` (and reads `completedAt ?? returnedAt`).
//   3. Run this script (dry run, then --write).
//   Run it AFTER the deploy: until the new code is live, the old code keeps writing `returnedAt`
//   on every newly completed booking, which would put the legacy field back.
//
// Safe to re-run: documents without `returnedAt` are skipped.
// If a document has BOTH fields with different values it is left untouched and listed as a
// conflict for you to look at; if both have the same value, only the leftover `returnedAt` is removed.
//
// Credentials: FIREBASE_SERVICE_ACCOUNT from .env (same as the other scripts/),
// otherwise Application Default Credentials (GOOGLE_APPLICATION_CREDENTIALS).

import "dotenv/config";
import admin from "firebase-admin";

const WRITE = process.argv.slice(2).includes("--write");

// ── Firebase init ────────────────────────────────────────────
if (process.env.FIREBASE_SERVICE_ACCOUNT) {
  const sa = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT.replace(/\r?\n/g, ""));
  sa.private_key = sa.private_key.replace(/\\n/g, "\n");
  admin.initializeApp({ credential: admin.credential.cert(sa) });
} else {
  admin.initializeApp({ credential: admin.credential.applicationDefault() });
}
const db = admin.firestore();
const { FieldValue, FieldPath } = admin.firestore;

const COLLECTIONS = ["bookings", "bookingArchives"];
const OLD = "returnedAt";
const NEW = "completedAt";
const PAGE = 400; // under Firestore's 500-writes-per-batch limit

// ── helpers ──────────────────────────────────────────────────
// Compare two stored values (Timestamp / Date / null) by their millisecond value.
const toMs = (v) => {
  if (v == null) return null;
  if (typeof v.toMillis === "function") return v.toMillis();
  if (v._seconds != null) return v._seconds * 1000 + Math.floor((v._nanoseconds || 0) / 1e6);
  const t = new Date(v).getTime();
  return Number.isNaN(t) ? null : t;
};

async function* pages(collection) {
  let last = null;
  for (;;) {
    let q = db.collection(collection).orderBy(FieldPath.documentId()).limit(PAGE);
    if (last) q = q.startAfter(last);
    const snap = await q.get();
    if (snap.empty) return;
    yield snap.docs;
    last = snap.docs[snap.docs.length - 1];
  }
}

async function commit(ops) {
  if (!ops.length) return;
  const batch = db.batch();
  for (const { ref, data } of ops) batch.update(ref, data);
  await batch.commit();
}

const sample = (arr, n = 5) => (arr.length ? `  e.g. ${arr.slice(0, n).join(", ")}${arr.length > n ? ", ..." : ""}` : "");

// ── per collection ───────────────────────────────────────────
async function migrate(collection) {
  const stat = { scanned: 0, rename: [], dedupe: [], conflict: [], untouched: 0 };
  let pending = [];

  for await (const docs of pages(collection)) {
    for (const doc of docs) {
      stat.scanned++;
      const d = doc.data();

      if (!(OLD in d)) { stat.untouched++; continue; }

      const hasNew = NEW in d && d[NEW] != null;

      if (!hasNew) {
        // normal case: move the value (null stays null) and drop the old key
        stat.rename.push(doc.id);
        pending.push({ ref: doc.ref, data: { [NEW]: d[OLD] ?? null, [OLD]: FieldValue.delete() } });
      } else if (toMs(d[OLD]) === toMs(d[NEW])) {
        // both present and identical: only the leftover old key needs to go
        stat.dedupe.push(doc.id);
        pending.push({ ref: doc.ref, data: { [OLD]: FieldValue.delete() } });
      } else {
        // both present and different: don't guess which one is right
        stat.conflict.push(doc.id);
      }

      if (WRITE && pending.length >= PAGE) { await commit(pending); pending = []; }
    }
  }
  if (WRITE) await commit(pending);
  return stat;
}

// After writing, count what is still left so you can see it worked.
async function remaining(collection) {
  let n = 0;
  for await (const docs of pages(collection)) n += docs.filter((x) => OLD in x.data()).length;
  return n;
}

// ── main ─────────────────────────────────────────────────────
(async () => {
  console.log(WRITE ? "MODE: WRITE (changes will be saved)\n" : "MODE: DRY RUN (nothing is written, pass --write to apply)\n");

  let conflicts = 0;
  for (const collection of COLLECTIONS) {
    const s = await migrate(collection);
    conflicts += s.conflict.length;
    console.log(`── ${collection}`);
    console.log(`   scanned                         ${s.scanned}`);
    console.log(`   ${OLD} -> ${NEW} ${WRITE ? "renamed" : "to rename"}        ${s.rename.length}${sample(s.rename)}`);
    console.log(`   duplicate ${OLD} ${WRITE ? "removed" : "to remove"}      ${s.dedupe.length}${sample(s.dedupe)}`);
    console.log(`   conflicts (left untouched)      ${s.conflict.length}${sample(s.conflict)}`);
    console.log(`   no ${OLD} field (skipped)    ${s.untouched}`);
    if (WRITE) console.log(`   still have ${OLD} after run  ${await remaining(collection)}`);
    console.log("");
  }

  if (conflicts) console.log(`! ${conflicts} document(s) have both fields with different values. Check them by hand.`);
  if (!WRITE) console.log("Dry run only. Re-run with --write to apply.");
  process.exit(0);
})().catch((err) => {
  console.error("Migration failed:", err);
  process.exit(1);
});