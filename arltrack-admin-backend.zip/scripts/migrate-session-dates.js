// One-off migration: bookingSessions + bookingSessionArchives
//
//   Phase 1 (safe, additive): add `startedAt` to sessions that actually started.
//   Phase 2 (destructive):    remove pickupTime / returnTime / activatedAt.
//
// Put this file in arltrack-admin-backend/scripts/ and run it from arltrack-admin-backend/.
// DRY RUN BY DEFAULT. Nothing is written unless you pass --write.
//
//   node scripts/migrate-session-dates.js                   phase 1 dry run (report)
//   node scripts/migrate-session-dates.js --write           phase 1 apply
//   node scripts/migrate-session-dates.js --audit           phase 1 report + compare returnTime vs bookings
//   node scripts/migrate-session-dates.js --cleanup         phase 2 dry run (report)
//   node scripts/migrate-session-dates.js --cleanup --write phase 2 apply (take a Firestore export first!)
//
// Run phase 1 BEFORE deploying the code that reads startedAt. Run phase 2 only
// AFTER the new admin + customer backends are deployed and verified.
//
// Credentials: FIREBASE_SERVICE_ACCOUNT (same JSON string the backend uses),
// otherwise Application Default Credentials (GOOGLE_APPLICATION_CREDENTIALS).
//
// The legacy bookingSessions/{id}/archive sub-collections are NOT touched.
// Safe to re-run: phase 1 skips docs that already have startedAt.

import "dotenv/config"; // loads FIREBASE_SERVICE_ACCOUNT from .env, same as the other scripts/
import admin from "firebase-admin";

const args = new Set(process.argv.slice(2));
const WRITE = args.has("--write");
const CLEANUP = args.has("--cleanup");
const AUDIT = args.has("--audit");
const FORCE = args.has("--force");

// ── Firebase init ────────────────────────────────────────────
if (process.env.FIREBASE_SERVICE_ACCOUNT) {
  const sa = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT.replace(/\r?\n/g, ""));
  sa.private_key = sa.private_key.replace(/\\n/g, "\n");
  admin.initializeApp({ credential: admin.credential.cert(sa) });
} else {
  admin.initializeApp({ credential: admin.credential.applicationDefault() });
}
const db = admin.firestore();
const { Timestamp, FieldValue, FieldPath } = admin.firestore;

const COLLECTIONS = ["bookingSessions", "bookingSessionArchives"];
const STARTED_STATUSES = new Set(["active", "ended", "stolen"]);
const PAGE = 400; // under the 500-op batch limit

// ── helpers ──────────────────────────────────────────────────
const toTimestamp = (v) => {
  if (!v) return null;
  if (typeof v.toDate === "function") return v; // already a Timestamp
  if (v._seconds != null) return new Timestamp(v._seconds, v._nanoseconds || 0);
  const d = new Date(v);
  return isNaN(d.getTime()) ? null : Timestamp.fromDate(d);
};
const toMs = (v) => toTimestamp(v)?.toMillis() ?? null;

async function* pages(collection) {
  let last = null;
  for (;;) {
    let q = db.collection(collection).orderBy(FieldPath.documentId()).limit(PAGE);
    if (last) q = q.startAfter(last);
    const snap = await q.get();
    if (snap.empty) return;
    yield snap.docs;
    last = snap.docs[snap.docs.length - 1];
  }
}

async function commit(ops) {
  if (!ops.length) return;
  const batch = db.batch();
  for (const { ref, data } of ops) batch.update(ref, data);
  await batch.commit();
}

// ── Phase 1 ──────────────────────────────────────────────────
async function phase1(collection) {
  const s = {
    scanned: 0, alreadyDone: 0, notStarted: 0,
    fromActivatedAt: 0, fromPickupTime: 0, noSource: [],
    returnTimeDiffers: [],
  };
  let ops = [];

  for await (const docs of pages(collection)) {
    // For --audit: load the matching live bookings in one batched read.
    let bookings = new Map();
    if (AUDIT && collection === "bookingSessions") {
      const refs = docs
        .map((d) => d.data().bookingID)
        .filter(Boolean)
        .map((id) => db.collection("bookings").doc(id));
      if (refs.length) {
        const snaps = await db.getAll(...refs);
        bookings = new Map(snaps.filter((x) => x.exists).map((x) => [x.id, x.data()]));
      }
    }

    for (const doc of docs) {
      s.scanned++;
      const d = doc.data();

      if (AUDIT && d.returnTime) {
        const b = bookings.get(d.bookingID);
        const bEnd = toMs(b?.endDateTime);
        const rt = toMs(d.returnTime);
        if (b && bEnd && rt && Math.abs(bEnd - rt) > 60_000) {
          s.returnTimeDiffers.push({
            id: doc.id,
            returnTime: new Date(rt).toISOString(),
            bookingEndDateTime: new Date(bEnd).toISOString(),
            bookingReturnedAt: b.returnedAt ? "set" : "EMPTY",
          });
        }
      }

      if (d.startedAt) { s.alreadyDone++; continue; }
      if (!STARTED_STATUSES.has(d.status)) { s.notStarted++; continue; }

      const activated = toTimestamp(d.activatedAt);
      const scheduled = toTimestamp(d.pickupTime);
      if (activated) {
        s.fromActivatedAt++;
        ops.push({ ref: doc.ref, data: { startedAt: activated, startedAtSource: "activatedAt" } });
      } else if (scheduled) {
        // Approximate: the SCHEDULED pickup, not a real handover moment. Marked
        // so it can never be mistaken for a real timestamp.
        s.fromPickupTime++;
        ops.push({ ref: doc.ref, data: { startedAt: scheduled, startedAtSource: "pickupTime(scheduled)" } });
      } else {
        s.noSource.push(`${doc.id} (status=${d.status})`);
      }

      if (WRITE && ops.length >= PAGE) { await commit(ops); ops = []; }
    }
  }
  if (WRITE) await commit(ops);
  return s;
}

// ── Phase 2 ──────────────────────────────────────────────────
async function phase2(collection) {
  const s = { scanned: 0, hasOldFields: 0, startedButNoStartedAt: [] };
  let ops = [];

  for await (const docs of pages(collection)) {
    for (const doc of docs) {
      s.scanned++;
      const d = doc.data();

      if (STARTED_STATUSES.has(d.status) && !d.startedAt) {
        s.startedButNoStartedAt.push(`${doc.id} (status=${d.status})`);
      }

      const has = ["pickupTime", "returnTime", "activatedAt"].some((f) => f in d);
      if (!has) continue;
      s.hasOldFields++;
      ops.push({
        ref: doc.ref,
        data: {
          pickupTime: FieldValue.delete(),
          returnTime: FieldValue.delete(),
          activatedAt: FieldValue.delete(),
        },
      });
      if (WRITE && ops.length >= PAGE) { await commit(ops); ops = []; }
    }
  }
  return { s, ops };
}

// ── main ─────────────────────────────────────────────────────
const show = (list, max = 15) => {
  list.slice(0, max).forEach((x) => console.log("     ", typeof x === "string" ? x : JSON.stringify(x)));
  if (list.length > max) console.log(`      … and ${list.length - max} more`);
};

(async () => {
  console.log(`Mode: ${CLEANUP ? "PHASE 2 (cleanup)" : "PHASE 1 (add startedAt)"} — ${WRITE ? "WRITE" : "DRY RUN"}\n`);

  if (!CLEANUP) {
    for (const col of COLLECTIONS) {
      const s = await phase1(col);
      console.log(`[${col}]`);
      console.log(`  scanned:                    ${s.scanned}`);
      console.log(`  already have startedAt:     ${s.alreadyDone}`);
      console.log(`  not started (left as-is):   ${s.notStarted}`);
      console.log(`  ${WRITE ? "set" : "would set"} from activatedAt:      ${s.fromActivatedAt}`);
      console.log(`  ${WRITE ? "set" : "would set"} from pickupTime:       ${s.fromPickupTime}  (approximate, marked startedAtSource)`);
      console.log(`  started but NO source:      ${s.noSource.length}`);
      show(s.noSource);
      if (AUDIT) {
        console.log(`  returnTime != booking.endDateTime: ${s.returnTimeDiffers.length}`);
        show(s.returnTimeDiffers);
      }
      console.log();
    }
    if (!WRITE) console.log("Dry run only. Re-run with --write to apply.");
    return;
  }

  // Phase 2
  const results = [];
  for (const col of COLLECTIONS) {
    const { s, ops } = await phase2(col);
    results.push({ col, s, ops });
    console.log(`[${col}]`);
    console.log(`  scanned:                         ${s.scanned}`);
    console.log(`  with old fields to remove:       ${s.hasOldFields}`);
    console.log(`  started but missing startedAt:   ${s.startedButNoStartedAt.length}`);
    show(s.startedButNoStartedAt);
    console.log();
  }

  const blocked = results.some((r) => r.s.startedButNoStartedAt.length);
  if (blocked && !FORCE) {
    console.log("STOPPED: some started sessions have no startedAt, so removing the old fields would lose their only start time.");
    console.log("Run phase 1 first (or pass --force if you accept losing those).");
    process.exitCode = 1;
    return;
  }
  if (!WRITE) {
    console.log("Dry run only. Take a Firestore export, then re-run with --cleanup --write.");
    return;
  }
  for (const r of results) {
    for (let i = 0; i < r.ops.length; i += PAGE) await commit(r.ops.slice(i, i + PAGE));
    console.log(`[${r.col}] removed old fields from ${r.ops.length} doc(s).`);
  }
})().catch((e) => {
  console.error("Migration failed:", e);
  process.exit(1);
});