// One-time script — run this once from your terminal, then you can delete it.
// It uses the SAME Firebase service account your backend already has, so
// there's nothing new to install or configure.
//
// index.js normally loads .env via its own "dotenv/config" import before
// firebase.js ever reads process.env.FIREBASE_SERVICE_ACCOUNT — this script
// doesn't go through index.js, so it has to load .env itself, first.
import "dotenv/config";
import { bucket } from "../config/firebaseConnection/firebase.js";

const corsConfig = [
  {
    origin: [
      "http://localhost:3000",
      // TODO: replace this with your actual deployed admin-frontend URL
    ],
    method: ["GET", "HEAD"],
    responseHeader: ["Content-Type"],
    maxAgeSeconds: 3600,
  },
];

try {
  await bucket.setCorsConfiguration(corsConfig);
  console.log("✅ CORS applied to bucket:", bucket.name);
  console.log(JSON.stringify(corsConfig, null, 2));
} catch (err) {
  console.error("❌ Failed to set CORS:", err.message);
}