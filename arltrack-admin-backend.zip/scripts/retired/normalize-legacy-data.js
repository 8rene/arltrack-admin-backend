// One-shot data normalizer: bookings, payments, paymentEntries, driverAssignments,
// refundRequests, cancellationRequests, penalties, transactionLogs.
//
// It does three things, in this order, for every document it finds:
//   1. FIX / MIGRATE  -- move data that still lives in an old place into the normalized model
//                        (missing cancellation rows, missing paymentEntries rows, stale webhook keys, ...)
//   2. NORMALIZE      -- repair mixed / inconsistent values (sentinels, wrong ids, two "assigned" drivers, ...)
//   3. DROP LEGACY    -- delete columns that are no longer part of the model, but ONLY when the value
//                        is proven to live somewhere else already (per document, per field).
//
//   node scripts/normalize-legacy-data.js                       DRY RUN. Prints + saves a report. Writes nothing.
//   node scripts/normalize-legacy-data.js --write               steps 1 + 2 only (additive, nothing is deleted)
//   node scripts/normalize-legacy-data.js --write --drop-legacy --confirm-readers-switched
//                                                               steps 1 + 2 + 3
//   add --drop-unverified   also delete keys that are in NO model and that no admin code reads
//   add --only=bookings,payments,paymentEntries,driverAssignments,refundRequests,cancellationRequests,penalties,transactionLogs
//
//   UNDO:  node scripts/normalize-legacy-data.js --rollback=scripts/reports/<report>.json --write
//          (deletes the rows this run created, puts every changed / deleted field back)
//
// Why two flags for deleting: the customer backend reads these collections too and deploys separately.
// --confirm-readers-switched means "the customer backend already reads money movements through
// hydratePayment / hydrateRefundRequest / hydratePenalty" -- same gate as migrate-payment-entries.js --cleanup.
//
// Every write run first saves the ORIGINAL version of each document it is about to change to
// scripts/backups/normalize-legacy-<timestamp>/<collection>.json (Timestamps kept typed).
import "dotenv/config";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { Booking } from "../models/booking/booking.model.js";
import { Payment } from "../models/payment/payment.model.js";
import { DriverAssignment } from "../models/driverAssignments/driverAssignment.model.js";
import { RefundRequest } from "../models/refundRequest/refundRequest.model.js";
import { CancellationRequest } from "../models/cancellationRequests/cancellationRequest.model.js";
import { createPenaltyPayload } from "../models/penalty/penalty.model.js";
import { TransactionLog } from "../models/transactionLogs/transactionLogs.model.js";
import {
  PaymentEntry, ENTRY_COLLECTION, ENTRY_DIRECTIONS, ENTRY_PHASES, ENTRY_SOURCES, ENTRY_METHODS, ENTRY_STATUSES,
} from "../models/paymentEntries/paymentEntry.model.js";
import {
  buildPaymentEntries, buildLegacyPenaltyEntry, buildRefundEntries, hydratePayment, nullIfSentinel,
  normalizeMethod, entryIDFor, MOVED_PAYMENT_FIELDS, MOVED_PENALTY_FIELDS, MOVED_REFUND_FIELDS,
} from "../services/paymentEntries/paymentEntries.mapper.js";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const stamp = (d) => d.toISOString().replace(/[:.]/g, "-");

// ═════════════════════ the normalized sets ═════════════════════
// keep = fields that belong to the collection. Model file + fields an admin service demonstrably writes / reads
// (the comment says who). Anything not listed anywhere is "unverified": reported, deleted only with --drop-unverified.
const keys = (o) => Object.keys(o);
const SPEC = {
  bookings: {
    keep: new Set([...keys(Booking), "updatedAt",
      "serviceType", "serviceTypeID",   // booking.service.js
      "pickupAt", "returnedAt",         // refundRequest.service.js / booking.service.js / penalty.service.js
    ]),
    // driver + cancellation data moved to driverAssignments / cancellationRequests (see booking.model.js)
    presplit: ["cancellationReason", "driverID", "driverAssignedAt", "driverAssignedBy", "cancellationRequestStatus",
      "cancellationRequestReason", "cancellationRequestedAt", "cancellationRejectReason", "statusBeforeCancellationRequest"],
    statuses: ["upcoming", "ongoing", "completed", "cancelled", "cancellation_request", "stolen", "to pay"],
  },
  payments: {
    keep: new Set([...keys(Payment), "userID", "paymongoSessionID", "checkoutUrl", "referenceNumber", "paymentMethod",
      "methodOfPayment", "payNow", "balanceAmount", "balanceStatus", "currentPhase", "balanceCollected",
      "balanceCollectedAmount", "depositFee", "deposit", "refundedAt", "refundIssuedAt", "refundIssuedBy", "paymongoFeeTotal"]),
  },
  paymentEntries: { keep: new Set(keys(PaymentEntry)) },
  driverAssignments: { keep: new Set(keys(DriverAssignment)), statuses: ["assigned", "reassigned", "unassigned", "completed"] },
  refundRequests: {
    keep: new Set([...keys(RefundRequest), "paymongoRefundIDs", "manualAmount", "onlineAmount",
      "approvalLockedAt", "contextLabel", "customerNotified", "depositAmount", "depositForfeited", "forfeitWaived",
      "forfeitWaivedAmount", "forfeitWaivedReason", "grossPaid", "hoursBeforePickup", "pickupAt", "policyTier", "requestedAt",
    ]),
    statuses: ["Pending", "Approved", "Refunded", "Rejected", "Failed"],
  },
  cancellationRequests: { keep: new Set(keys(CancellationRequest)), statuses: ["pending", "approved", "rejected"] },
  penalties: {
    keep: new Set(keys(createPenaltyPayload("x"))),
    custom: new Set([...MOVED_PENALTY_FIELDS, "confirmedBy", "confirmedAt"]),   // handled by explicit rules below
    statuses: ["Confirmed", "Voided", "Waived"],
  },
  // refundRequestID / transactionID are handled by explicit rules in section 9 (they are not part of the model any more)
  transactionLogs: {
    keep: new Set(keys(TransactionLog)),
    types: ["Payment", "Refund", "Deposit", "DepositReturn", "Discount", "Expense"],
    statuses: ["Success", "Failed", "Pending", "Refunded", "Rejected"],
  },
};
// Moved fields hydratePayment() can rebuild from the rows -> only dropped when the row reproduces the value.
const VERIFIED_PAYMENT_FIELDS = [
  "depositPaymongoPaymentID", "balancePaymongoPaymentID", "paymongoPaymentID", "depositPaymongoFee", "balancePaymongoFee",
  "paymongoChannel", "proofUrl", "paidAt", "balancePaidAt", "confirmedBy", "confirmedAt", "balanceMethod",
  "balanceCollectedBy", "balanceCollectedAt",
];
// Moved fields nothing reads and nothing can rebuild (kept only as history): dropped once the rows exist.
const INFO_PAYMENT_FIELDS = ["lastSettledVia", "paymongoTransactions"];

// ═════════════════════ small helpers ═════════════════════
const isTs = (v) => v && typeof v === "object" && (typeof v.toMillis === "function" || v._seconds !== undefined || v.__type === "timestamp");
const toMillis = (v) => (typeof v.toMillis === "function" ? v.toMillis() : v._seconds !== undefined ? v._seconds * 1000 + Math.floor((v._nanoseconds || 0) / 1e6)
  : v.seconds !== undefined ? v.seconds * 1000 + Math.floor((v.nanoseconds || 0) / 1e6) : Date.parse(v.iso));
// canonical form for "are these two the same value?": empty-ish -> null, timestamps -> millis
const canon = (v) => {
  if (v === undefined || v === null || v === "") return null;
  if (v instanceof Date) return v.getTime();
  if (isTs(v)) return toMillis(v);
  if (Array.isArray(v)) return JSON.stringify(v.map(canon));
  if (typeof v === "object") return JSON.stringify(Object.fromEntries(Object.entries(v).sort().map(([k, x]) => [k, canon(x)])));
  return v;
};
const same = (a, b) => canon(a) === canon(b);
const isEmpty = (v) => v === undefined || v === null || v === "" || (Array.isArray(v) && !v.length) || nullIfSentinel(v) === null;
const sec = (v) => (v ? Math.floor(canon(v) / 1000) : 0);

// JSON that keeps Firestore types (same tags as scripts/export-firestore.js)
const encode = (v) => {
  if (v === undefined) return null;
  if (v === null || typeof v !== "object") return v;
  if (v instanceof Date) return { __type: "timestamp", seconds: Math.floor(v.getTime() / 1000), nanoseconds: (v.getTime() % 1000) * 1e6, iso: v.toISOString() };
  if (isTs(v) && typeof v.toDate === "function") return { __type: "timestamp", seconds: v.seconds ?? v._seconds, nanoseconds: v.nanoseconds ?? v._nanoseconds, iso: v.toDate().toISOString() };
  if (Array.isArray(v)) return v.map(encode);
  return Object.fromEntries(Object.entries(v).map(([k, x]) => [k, encode(x)]));
};
const decode = (v, Timestamp) => {
  if (v === null || typeof v !== "object") return v;
  if (v.__type === "timestamp") return Timestamp ? new Timestamp(v.seconds, v.nanoseconds) : new Date(v.iso);
  if (Array.isArray(v)) return v.map((x) => decode(x, Timestamp));
  return Object.fromEntries(Object.entries(v).map(([k, x]) => [k, decode(x, Timestamp)]));
};
const inferCancelledBy = (reason) => {   // same rules as cancellationRequests.service.js
  const r = String(reason || "");
  if (r.startsWith("Cancelled by staff:")) return "staff";
  if (r.startsWith("Cancelled by admin:")) return "admin";
  if (r.startsWith("Auto-cancelled")) return "system";
  if (r.startsWith("Cancelled: refund")) return "refund";
  if (r === "Cancelled by user.") return "customer";
  return "unknown";
};
const push = (m, k, v) => { if (!m.has(k)) m.set(k, []); m.get(k).push(v); };

// ═════════════════════ main ═════════════════════
export const main = async ({ db, FieldValue, Timestamp = null, argv = [], log = console.log, now = new Date(), outDir = HERE }) => {
  const flag = (n) => argv.includes(`--${n}`);
  const val = (n) => { const a = argv.find((x) => x.startsWith(`--${n}=`)); return a ? a.slice(n.length + 3) : null; };
  const WRITE = flag("write"), DROP = flag("drop-legacy"), CONFIRM = flag("confirm-readers-switched"), DROP_UNV = flag("drop-unverified");
  const ALL = ["bookings", "payments", "paymentEntries", "driverAssignments", "refundRequests", "cancellationRequests", "penalties", "transactionLogs"];
  const only = val("only") ? val("only").split(",").map((s) => s.trim()) : null;
  const want = (c) => !only || only.includes(c);
  const mode = WRITE ? "WRITE" : "DRY RUN";
  const reportDir = path.join(outDir, "reports");

  const saveReport = (report, name) => {
    fs.mkdirSync(reportDir, { recursive: true });
    const file = path.join(reportDir, `${name}-${stamp(now)}.json`);
    fs.writeFileSync(file, JSON.stringify(report, null, 2));
    log(`\nReport saved: ${path.relative(process.cwd(), file) || file}`);
    return file;
  };
  const makeBatcher = () => {
    let batch = db.batch(), n = 0;
    const flush = async () => { if (n) { await batch.commit(); batch = db.batch(); n = 0; } };
    const add = async (fn) => { fn(batch); n += 1; if (n >= 400) await flush(); };
    return { add, flush };
  };

  // ───────── ROLLBACK ─────────
  if (val("rollback")) {
    const rep = JSON.parse(fs.readFileSync(val("rollback"), "utf8"));
    log(`\n[${mode}] rollback of ${val("rollback")}: delete ${rep.created.length} created docs, restore ${rep.changes.length} fields`);
    if (!WRITE) { log("  (dry run -- add --write to apply)"); return { rolledBack: false }; }
    const b = makeBatcher();
    for (const c of rep.created) await b.add((bt) => bt.delete(db.collection(c.col).doc(c.id)));
    for (const c of rep.changes) {
      await b.add((bt) => bt.update(db.collection(c.col).doc(c.id), { [c.field]: c.old === null && c.wasMissing ? FieldValue.delete() : decode(c.old, Timestamp) }));
    }
    await b.flush();
    log("  rollback written.");
    return { rolledBack: true };
  }

  if (WRITE && DROP && !CONFIRM) {
    log("\nREFUSING to delete fields. --drop-legacy removes columns the customer backend may still read.");
    log("Once it reads money movements through hydratePayment / hydrateRefundRequest / hydratePenalty,");
    log("re-run with --confirm-readers-switched.");
    return { refused: true };
  }
  if (DROP_UNV && !DROP) { log("\n--drop-unverified only makes sense together with --drop-legacy."); return { refused: true }; }

  // ───────── load ─────────
  const load = async (name) => {
    const m = new Map();
    for (const d of (await db.collection(name).get()).docs) m.set(d.id, { id: d.id, data: d.data(), ref: d.ref, col: name });
    return m;
  };
  const C = {};
  for (const n of [...ALL, "paymentsArchives", "bookingArchives", "user"]) C[n] = await load(n);
  log(`\n[${mode}] normalize-legacy-data${only ? ` (only: ${only.join(", ")})` : ""}${DROP ? " +drop-legacy" : ""}${DROP_UNV ? " +drop-unverified" : ""}`);
  log("  loaded: " + ALL.map((n) => `${n} ${C[n].size}`).join("   "));

  // lookups
  const bookingKeyOf = (d) => d.data.bookingID || d.id;
  const liveBookingKeys = new Set(); for (const b of C.bookings.values()) { liveBookingKeys.add(b.id); liveBookingKeys.add(bookingKeyOf(b)); }
  const archivedBookingKeys = new Set(); for (const b of C.bookingArchives.values()) [b.id, b.data.bookingID, b.data.originalId].filter(Boolean).forEach((k) => archivedBookingKeys.add(k));
  const knownBooking = (k) => liveBookingKeys.has(k) || archivedBookingKeys.has(k);
  const bookingByKey = new Map(); for (const b of C.bookings.values()) { bookingByKey.set(b.id, b); bookingByKey.set(bookingKeyOf(b), b); }
  const paymentsByID = new Map();
  for (const d of [...C.payments.values(), ...C.paymentsArchives.values()]) paymentsByID.set(d.data.paymentID || d.data.originalId || d.id, d.data);

  // entries: in-memory so later steps (and the dry run) see rows this run creates
  const entryMap = new Map([...C.paymentEntries.values()].map((e) => [e.id, e.data]));
  const entriesBy = (field, v) => [...entryMap.values()].filter((e) => e[field] === v);

  // ───────── change accumulator ─────────
  const patches = new Map();       // "col/id" -> { doc, set:{}, del:Set }
  const creates = [];              // { col, id, data }
  const changes = [];              // for rollback: { col, id, field, old, wasMissing }
  const issues = [];               // things a human must look at
  const stats = Object.fromEntries(ALL.map((c) => [c, { fixed: {}, dropped: {}, created: 0, unverified: {} }]));
  const inc = (o, k, n = 1) => { o[k] = (o[k] || 0) + n; };
  const patchOf = (doc) => { const k = `${doc.col}/${doc.id}`; if (!patches.has(k)) patches.set(k, { doc, set: {}, del: new Set() }); return patches.get(k); };
  const issue = (col, id, code, detail = "") => issues.push({ col, id, code, detail });
  const setField = (doc, field, value, why) => {
    const cur = doc.data[field];
    if (cur !== undefined && (cur === value || (canon(value) !== null && same(cur, value)))) return;   // already that value ("" -> null is a real change)
    patchOf(doc).set[field] = value; inc(stats[doc.col].fixed, why);
  };
  const dropField = (doc, field, why) => {
    if (!DROP || doc.data[field] === undefined) return;
    patchOf(doc).del.add(field); inc(stats[doc.col].dropped, why);
  };
  const createDoc = (col, id, data, why) => { creates.push({ col, id, data }); if (stats[col]) inc(stats[col].fixed, `created:${why}`); };
  // unknown keys: reported always, deleted only with --drop-unverified
  const sweepUnknown = (doc, extra = []) => {
    const spec = SPEC[doc.col];
    for (const k of Object.keys(doc.data)) {
      if (spec.keep.has(k) || extra.includes(k)) continue;
      inc(stats[doc.col].unverified, k);
      if (DROP && DROP_UNV) dropField(doc, k, `unverified:${k}`);
    }
  };

  // ═══════════ 1. cancellationRequests that bookings are missing ═══════════
  // A cancelled booking must have a "direct" row (doc id = booking key); the reason used to live on bookings.cancellationReason.
  const cancelByBooking = new Map();   // bookingKey -> rows (existing + created now)
  for (const c of C.cancellationRequests.values()) push(cancelByBooking, c.data.bookingID, c);
  const directExists = (k) => (cancelByBooking.get(k) || []).some((r) => r.data.type === "direct" || (!r.data.type && r.id === k));
  const staffRefundBookings = new Set([...C.refundRequests.values()].filter((r) => r.data.source === "staff").map((r) => r.data.bookingID));
  const createdDirect = new Map();   // bookingKey -> data
  if (want("bookings") || want("cancellationRequests")) {
    for (const b of C.bookings.values()) {
      const key = bookingKeyOf(b);
      if (b.data.status !== "cancelled" || directExists(key) || directExists(b.id)) continue;
      const reason = b.data.cancellationReason || "";
      let cancelledBy = inferCancelledBy(reason);
      if (cancelledBy === "unknown" && (staffRefundBookings.has(key) || staffRefundBookings.has(b.id))) cancelledBy = "refund";
      const data = {
        cancellationRequestID: key, type: "direct", bookingID: key, userID: b.data.userID || null, reason,
        status: "approved", cancelledBy, requestedAt: b.data.updatedAt || null, processedBy: null,
        processedAt: b.data.updatedAt || null, rejectReason: null, migratedFrom: reason ? "booking.cancellationReason" : "booking.status=cancelled",
      };
      createDoc("cancellationRequests", key, data, "direct_row_for_cancelled_booking");
      createdDirect.set(key, data);
      if (!reason) issue("bookings", b.id, "cancelled_without_any_reason", "direct row created with empty reason + cancelledBy=" + cancelledBy);
    }
  }
  const hasDirectRow = (k) => directExists(k) || createdDirect.has(k);

  // ═══════════ 2. bookings ═══════════
  if (want("bookings")) {
    for (const b of C.bookings.values()) {
      const d = b.data, key = bookingKeyOf(b);
      if (d.status && !SPEC.bookings.statuses.includes(d.status)) issue("bookings", b.id, "unknown_status", d.status);
      if (d.bookingID && d.bookingID !== b.id) issue("bookings", b.id, "bookingID_differs_from_doc_id", d.bookingID);
      // reason text: the direct row wins; fill it from the booking if the row is empty
      if (d.cancellationReason !== undefined) {
        const row = (cancelByBooking.get(key) || cancelByBooking.get(b.id) || []).find((r) => r.data.type === "direct");
        if (row && !row.data.reason && d.cancellationReason) { setField(row, "reason", d.cancellationReason, "reason_filled_from_booking"); }
        if (hasDirectRow(key) || hasDirectRow(b.id)) dropField(b, "cancellationReason", "moved_to_cancellationRequests");
        else issue("bookings", b.id, "cancellationReason_kept", "booking is not cancelled and has no direct row");
      }
      // pre-split fields: only dropped once the row they became exists
      const asg = [...C.driverAssignments.values()].some((a) => a.data.bookingID === key || a.data.bookingID === b.id);
      for (const f of ["driverID", "driverAssignedAt", "driverAssignedBy"]) {
        if (d[f] === undefined) continue;
        if (asg) dropField(b, f, "moved_to_driverAssignments");
        else if (f === "driverID" && d.driverID) { /* migrated and dropped in step 3a below */ }
        else if (!d.driverID) dropField(b, f, "empty_legacy_driver_field");
      }
      for (const f of ["cancellationRequestStatus", "cancellationRequestReason", "cancellationRequestedAt", "cancellationRejectReason", "statusBeforeCancellationRequest"]) {
        if (d[f] === undefined) continue;
        if ((cancelByBooking.get(key) || cancelByBooking.get(b.id) || []).length) dropField(b, f, "moved_to_cancellationRequests");
        else issue("bookings", b.id, `${f}_needs_scripts/migrate-driver-and-cancellation.js`, "no cancellationRequests row yet -- field kept");
      }
      sweepUnknown(b, SPEC.bookings.presplit);
    }
  }

  // ═══════════ 3. driverAssignments ═══════════
  if (want("driverAssignments") || want("bookings")) {
    const terminal = new Set(["cancelled", "completed", "stolen"]);
    const byBooking = new Map(); for (const a of C.driverAssignments.values()) push(byBooking, a.data.bookingID, a);
    // 3a. a booking that still carries driverID but has no assignment row -> create it
    for (const b of C.bookings.values()) {
      const key = bookingKeyOf(b);
      if (!b.data.driverID || byBooking.has(key) || byBooking.has(b.id)) continue;
      const active = !terminal.has(b.data.status);
      const data = {
        assignmentID: b.id, bookingID: key, driverID: b.data.driverID, status: active ? "assigned" : "completed",
        assignedAt: b.data.driverAssignedAt || b.data.updatedAt || b.data.createdAt || null,
        assignedBy: b.data.driverAssignedBy || "", endedAt: active ? null : (b.data.updatedAt || null), endedBy: null,
        migratedFrom: "booking.driverID",
      };
      createDoc("driverAssignments", b.id, data, "assignment_from_booking.driverID");
      // the new row now holds all three values, so the old booking fields can go in this same run (keeps the script idempotent)
      for (const f of ["driverID", "driverAssignedAt", "driverAssignedBy"]) dropField(b, f, "moved_to_driverAssignments");
      push(byBooking, key, { id: b.id, data, col: "driverAssignments", created: true });
    }
    if (want("driverAssignments")) {
      for (const a of C.driverAssignments.values()) {
        const d = a.data;
        if (d.assignmentID !== a.id) setField(a, "assignmentID", a.id, "assignmentID_set_to_doc_id");
        if (!SPEC.driverAssignments.statuses.includes(d.status)) issue("driverAssignments", a.id, "unknown_status", d.status);
        if (d.driverID && !C.user.has(d.driverID)) issue("driverAssignments", a.id, "driver_not_in_user", d.driverID);
        if (d.bookingID && !knownBooking(d.bookingID)) issue("driverAssignments", a.id, "booking_not_found", d.bookingID);
        if (d.status === "assigned" && d.endedAt) issue("driverAssignments", a.id, "assigned_but_has_endedAt", "left alone -- decide by hand");
        if (d.status && d.status !== "assigned" && !d.endedAt && SPEC.driverAssignments.statuses.includes(d.status)) {
          setField(a, "endedAt", d.assignedAt || now, "endedAt_backfilled"); issue("driverAssignments", a.id, "endedAt_was_missing", "set to assignedAt");
        }
        sweepUnknown(a);
      }
      for (const [bk, rows] of byBooking) {
        const open = rows.filter((r) => r.data.status === "assigned");
        const booking = bookingByKey.get(bk);
        if (open.length > 1) {   // keep the newest, close the others as "reassigned"
          open.sort((x, y) => sec(y.data.assignedAt) - sec(x.data.assignedAt));
          for (const old of open.slice(1)) if (!old.created) {
            setField(old, "status", "reassigned", "duplicate_assigned_closed"); setField(old, "endedAt", open[0].data.assignedAt || now, "duplicate_assigned_closed");
            issue("driverAssignments", old.id, "two_assigned_rows_for_one_booking", `kept ${open[0].id}`);
          }
        }
        if (booking && terminal.has(booking.data.status)) {   // trip is over: nobody is "currently" driving it (driverAssignments.service completes it)
          for (const r of open.slice(0, 1)) if (!r.created) { setField(r, "status", "completed", "assigned_on_finished_booking"); setField(r, "endedAt", booking.data.updatedAt || now, "assigned_on_finished_booking"); }
        }
      }
    }
  }

  // ═══════════ 4. payments: rows first, then the legacy fields ═══════════
  const paymentKeyOf = (d) => d.data.paymentID || d.data.originalId || d.id;
  if (want("payments") || want("paymentEntries")) {
    for (const p of C.payments.values()) {
      const rows = entriesBy("paymentID", paymentKeyOf(p)).filter((e) => e.direction !== "out" && e.phase !== "penalty");
      const { entries } = buildPaymentEntries(hydratePayment(p.data, rows), p.id, { now, migratedFrom: "payments.legacy" });
      for (const e of entries) if (!entryMap.has(e.paymentEntryID)) {
        entryMap.set(e.paymentEntryID, e); createDoc(ENTRY_COLLECTION, e.paymentEntryID, e, "payment_row"); stats.payments.created += 1;
      }
    }
  }
  if (want("payments")) {
    for (const p of C.payments.values()) {
      const d = p.data, pk = paymentKeyOf(p);
      if (d.paymentID && d.paymentID !== p.id) issue("payments", p.id, "paymentID_differs_from_doc_id", d.paymentID);
      if (!knownBooking(d.bookingID)) issue("payments", p.id, "booking_not_found", d.bookingID);
      if (d.referenceNumber !== undefined && d.referenceNumber !== null && nullIfSentinel(d.referenceNumber) === null) setField(p, "referenceNumber", null, "sentinel_referenceNumber->null");
      let rows = entriesBy("paymentID", pk).filter((e) => e.direction !== "out" && e.phase !== "penalty");
      // Deposit row says "paid online" but has no pay_... id, while the document carries exactly one. Readers only look at the
      // rows (rowsOnly), so the id is invisible today. Copy it over ONLY when it cannot belong to anything else.
      const depRow = rows.find((e) => e.paymentEntryID === entryIDFor(pk, "deposit"));
      const depDoc = C.paymentEntries.get(entryIDFor(pk, "deposit"));
      const docPayID = nullIfSentinel(d.paymongoPaymentID);
      if (depRow && depDoc && depRow.source === "online" && depRow.status === "success" && !depRow.referenceNumber && (depRow.flags || []).includes("missing_payment_id")
          && docPayID && docPayID !== nullIfSentinel(d.balancePaymongoPaymentID) && !nullIfSentinel(d.depositPaymongoPaymentID)
          && !rows.some((e) => e.phase === "balance" && e.source === "online" && e.status === "success")
          && ![...entryMap.values()].some((e) => e.referenceNumber === docPayID)) {
        setField(depDoc, "referenceNumber", docPayID, "payment_id_restored_on_deposit_row");
        setField(depDoc, "flags", (depRow.flags || []).filter((f) => f !== "missing_payment_id"), "payment_id_restored_on_deposit_row");
        entryMap.set(depDoc.id, { ...depDoc.data, referenceNumber: docPayID, flags: (depRow.flags || []).filter((f) => f !== "missing_payment_id") });   // never mutate depDoc.data: rollback reads the original from it
        issue("payments", p.id, "payment_id_restored", `${depDoc.id} <- ${docPayID} (check against PayMongo)`);
        rows = entriesBy("paymentID", pk).filter((e) => e.direction !== "out" && e.phase !== "penalty");   // see the repaired row below
      }
      if (DROP) {
        const { entries: expected } = buildPaymentEntries(hydratePayment(d, rows), p.id);
        const missing = expected.filter((e) => { const h = entryMap.get(e.paymentEntryID); return !h || h.amount !== e.amount || h.status !== e.status; });
        if (!expected.length) inc(stats.payments.dropped, "SKIPPED:no_entries_expected");
        else if (missing.length) { inc(stats.payments.dropped, "SKIPPED:entries_missing_or_different"); issue("payments", p.id, "entries_differ_from_payment", missing.map((e) => e.paymentEntryID).join(",")); }
        else {
          const stripped = { ...d }; for (const f of MOVED_PAYMENT_FIELDS) delete stripped[f];
          const back = hydratePayment(stripped, rows, { rowsOnly: true });
          for (const f of VERIFIED_PAYMENT_FIELDS) {
            if (d[f] === undefined) continue;
            if (isEmpty(d[f]) || same(back[f], d[f])) dropField(p, f, "moved_to_paymentEntries");
            else { inc(stats.payments.dropped, `KEPT:${f}`); issue("payments", p.id, "field_differs_from_entry", `${f}: doc=${JSON.stringify(encode(d[f]))} row=${JSON.stringify(encode(back[f]))}`); }
          }
          for (const f of INFO_PAYMENT_FIELDS) dropField(p, f, "moved_to_paymentEntries");
        }
      }
      sweepUnknown(p, MOVED_PAYMENT_FIELDS);
    }
  }

  // ═══════════ 5. refundRequests: "out" rows first, then the legacy fields ═══════════
  if (want("refundRequests") || want("paymentEntries")) {
    for (const r of C.refundRequests.values()) {
      const rid = r.data.refundRequestID || r.id;
      const { entries } = buildRefundEntries({ ...r.data, refundRequestID: rid }, rid, { now, migratedFrom: "refunds.legacy", payment: paymentsByID.get(r.data.paymentID) });
      for (const e of entries) if (!entryMap.has(e.paymentEntryID)) {
        entryMap.set(e.paymentEntryID, e); createDoc(ENTRY_COLLECTION, e.paymentEntryID, e, "refund_row"); stats.refundRequests.created += 1;
      }
    }
  }
  if (want("refundRequests")) {
    for (const r of C.refundRequests.values()) {
      const d = r.data, rid = d.refundRequestID || r.id;
      if (d.refundRequestID !== r.id) setField(r, "refundRequestID", r.id, "refundRequestID_set_to_doc_id");
      if (!SPEC.refundRequests.statuses.includes(d.status)) issue("refundRequests", r.id, "unknown_status", d.status);
      if (d.paymentID && !paymentsByID.has(d.paymentID)) issue("refundRequests", r.id, "payment_not_found", d.paymentID);
      if (d.bookingID && !knownBooking(d.bookingID)) issue("refundRequests", r.id, "booking_not_found", d.bookingID);
      if (d.status === "Rejected" && !d.rejectReason) issue("refundRequests", r.id, "rejected_without_reason");
      const rows = entriesBy("refID", rid).filter((e) => e.refCollection === "refundRequests" && e.direction === "out");
      // the webhook finds a refund by paymongoRefundIDs[]; older docs only had the single paymongoRefundID
      const refs = [...new Set([...(d.paymongoRefundIDs || []), nullIfSentinel(d.paymongoRefundID), ...rows.filter((e) => e.source === "online").map((e) => e.referenceNumber)].filter(Boolean))];
      if (refs.length && !same(refs, d.paymongoRefundIDs || [])) setField(r, "paymongoRefundIDs", refs, "paymongoRefundIDs_filled");
      if (DROP) {
        const { entries: expected } = buildRefundEntries({ ...d, refundRequestID: rid }, rid, { payment: paymentsByID.get(d.paymentID) });
        const haveAll = expected.every((e) => entryMap.has(e.paymentEntryID));
        for (const f of MOVED_REFUND_FIELDS) {
          if (d[f] === undefined) continue;
          if (isEmpty(d[f]) || (typeof d[f] === "number" && d[f] === 0) || haveAll) dropField(r, f, "moved_to_paymentEntries");
          else { inc(stats.refundRequests.dropped, `KEPT:${f}`); issue("refundRequests", r.id, "field_kept_rows_missing", f); }
        }
      }
      sweepUnknown(r, MOVED_REFUND_FIELDS);
    }
  }

  // ═══════════ 6. penalties ═══════════
  if (want("penalties") || want("paymentEntries")) {
    for (const n of C.penalties.values()) {
      const pid = n.data.penaltyID || n.id;
      if (entriesBy("refID", pid).some((e) => e.refCollection === "penalties")) continue;
      const out = buildLegacyPenaltyEntry({ ...n.data, penaltyID: pid }, pid, paymentsByID.get(n.data.paymentID), { now, migratedFrom: "penalties.legacy" });
      if (out.entry && !entryMap.has(out.entry.paymentEntryID)) { entryMap.set(out.entry.paymentEntryID, out.entry); createDoc(ENTRY_COLLECTION, out.entry.paymentEntryID, out.entry, "penalty_row"); stats.penalties.created += 1; }
      else if (out.review === "deposit_involved") issue("penalties", n.id, "deposit_involved", "paid penalty on a deposit-settled booking -- not converted, check by hand");
    }
  }
  if (want("penalties")) {
    for (const n of C.penalties.values()) {
      const d = n.data, pid = d.penaltyID || n.id;
      const paidRows = entriesBy("refID", pid).filter((e) => e.refCollection === "penalties" && e.direction !== "out" && e.status === "success");
      if (d.penaltyID !== n.id) setField(n, "penaltyID", n.id, "penaltyID_set_to_doc_id");
      if (!SPEC.penalties.statuses.includes(d.status)) issue("penalties", n.id, "unknown_status", d.status);
      if (!paymentsByID.has(d.paymentID)) issue("penalties", n.id, "payment_not_found", d.paymentID);
      if (!knownBooking(d.bookingID)) issue("penalties", n.id, "booking_not_found", d.bookingID);
      const sum = (d.lineItems || []).reduce((s, i) => s + (Number(i.amount) || 0), 0);
      if (sum !== Number(d.amount) && !d.overrideReason) issue("penalties", n.id, "amount_differs_from_lineItems", `${d.amount} vs ${sum}`);
      if (Number(d.paidAmount) > Number(d.amount)) issue("penalties", n.id, "paidAmount_exceeds_amount", `${d.paidAmount} > ${d.amount}`);
      for (const f of MOVED_PENALTY_FIELDS) {
        if (d[f] === undefined) continue;
        if (isEmpty(d[f])) { if (DROP) dropField(n, f, "empty_legacy_field"); else if (d[f] !== null) setField(n, f, null, "sentinel->null"); }
        else if (paidRows.length) { if (DROP) dropField(n, f, "moved_to_paymentEntries"); }
        else if (DROP) inc(stats.penalties.dropped, `KEPT:${f}(deposit-covered, settleBooking cache)`);
      }
      if (DROP) {   // confirmed* were always equal to created* once the Draft step went away; older docs that differ keep theirs
        if (d.confirmedBy !== undefined && (isEmpty(d.confirmedBy) || d.confirmedBy === d.createdBy)) dropField(n, "confirmedBy", "equals_createdBy");
        if (d.confirmedAt !== undefined && (isEmpty(d.confirmedAt) || same(d.confirmedAt, d.createdAt))) dropField(n, "confirmedAt", "equals_createdAt");
      }
      sweepUnknown(n, [...SPEC.penalties.custom]);
    }
  }

  // ═══════════ 7. cancellationRequests (existing rows) ═══════════
  if (want("cancellationRequests")) {
    const pendingBy = new Map();
    for (const c of C.cancellationRequests.values()) {
      const d = c.data;
      if (d.cancellationRequestID !== c.id) setField(c, "cancellationRequestID", c.id, "cancellationRequestID_set_to_doc_id");
      const st = String(d.status || "").toLowerCase();
      if (d.status !== st && SPEC.cancellationRequests.statuses.includes(st)) setField(c, "status", st, "status_lowercased");
      else if (!SPEC.cancellationRequests.statuses.includes(st)) issue("cancellationRequests", c.id, "unknown_status", d.status);
      if (!d.type) { const t = c.id === d.bookingID && st === "approved" ? "direct" : "request"; setField(c, "type", t, "type_inferred"); }
      const type = d.type || (c.id === d.bookingID && st === "approved" ? "direct" : "request");
      if (type === "direct") {
        if (!d.cancelledBy) setField(c, "cancelledBy", inferCancelledBy(d.reason), "cancelledBy_inferred");
        if (c.id !== d.bookingID) issue("cancellationRequests", c.id, "direct_row_id_differs_from_booking_key", d.bookingID);
        if (!d.reason) issue("cancellationRequests", c.id, "direct_row_without_reason");
      }
      if (st === "pending") push(pendingBy, d.bookingID, c);
      if (!knownBooking(d.bookingID)) issue("cancellationRequests", c.id, "booking_not_found", d.bookingID);
      sweepUnknown(c);
    }
    for (const [bk, rows] of pendingBy) if (rows.length > 1) issue("cancellationRequests", bk, "several_pending_requests_for_one_booking", rows.map((r) => r.id).join(","));
  }

  // ═══════════ 8. paymentEntries (existing rows) ═══════════
  if (want("paymentEntries")) {
    const seen = new Map();
    for (const e of C.paymentEntries.values()) {
      const d = e.data;
      if (d.paymentEntryID !== e.id) setField(e, "paymentEntryID", e.id, "paymentEntryID_set_to_doc_id");
      if (d.referenceNumber !== undefined && d.referenceNumber !== null && nullIfSentinel(d.referenceNumber) === null) setField(e, "referenceNumber", null, "sentinel_referenceNumber->null");
      if (!Array.isArray(d.flags)) setField(e, "flags", [], "flags_set_to_array");
      if (d.method) {   // "GCash" -> "gcash"
        const m = normalizeMethod(d.method);
        if (m.method && m.method !== d.method) setField(e, "method", m.method, "method_normalized");
        else if (!ENTRY_METHODS.includes(d.method) && !m.method) issue("paymentEntries", e.id, "unknown_method", d.method);
      }
      for (const [f, list] of [["direction", ENTRY_DIRECTIONS], ["phase", ENTRY_PHASES], ["source", ENTRY_SOURCES], ["status", ENTRY_STATUSES]]) {
        if (!list.includes(d[f])) issue("paymentEntries", e.id, `invalid_${f}`, String(d[f]));
      }
      if (d.paymentID && !paymentsByID.has(d.paymentID)) issue("paymentEntries", e.id, "payment_not_found", d.paymentID);
      if (d.direction === "out" && d.source === "online" && d.status !== "unrefundable" && !d.parentEntryID && d.paymentID) {
        const parent = entryIDFor(d.paymentID, d.phase);
        if (entryMap.has(parent)) setField(e, "parentEntryID", parent, "parentEntryID_linked");
      }
      if (d.parentEntryID && !entryMap.has(d.parentEntryID)) issue("paymentEntries", e.id, "parent_entry_missing", d.parentEntryID);
      if (d.direction === "in") { const k = `${d.paymentID}|${d.phase}`; if (seen.has(k)) issue("paymentEntries", e.id, "duplicate_in_row", `also ${seen.get(k)}`); else seen.set(k, e.id); }
      sweepUnknown(e);
    }
  }

  // ═══════════ 9. transactionLogs ═══════════
  // The log has ONE link to its source record: refID + refCollection (no refundRequestID column).
  //   refundRequestID -> refID/refCollection "refundRequests"   (the value is only deleted once refID holds the same id)
  //   Payment logs   -> refID/refCollection "paymentEntries"    (only when the entry is certain; see below)
  // paymentID / bookingID stay: one log can cover several entries, and Discount / DepositReturn / Expense logs have none.
  if (want("transactionLogs")) {
    const linked = new Set();   // entries some log already points at
    for (const l of C.transactionLogs.values()) if (l.data.refCollection === "paymentEntries" && l.data.refID) linked.add(l.data.refID);
    const entriesIn = new Map(); for (const [id, e] of entryMap) if (e.direction === "in") push(entriesIn, e.paymentID, { id, e });
    // refID + refCollection are one change: counted once, written together
    const setRef = (l, id, coll, why) => { setField(l, "refID", id, why); if (l.data.refCollection !== coll) patchOf(l).set.refCollection = coll; };
    const linkTo = (l, entryID, why) => { setRef(l, entryID, ENTRY_COLLECTION, why); linked.add(entryID); };
    const isPaymentLog = (d) => d.type === "Payment" && isEmpty(d.refID);

    for (const l of C.transactionLogs.values()) {   // pass 1: identity + refundRequestID + the log whose doc id IS the entry id
      const d = l.data;
      if (d.transactionLogsID !== l.id) setField(l, "transactionLogsID", l.id, "transactionLogsID_set_to_doc_id");
      if (!SPEC.transactionLogs.types.includes(d.type)) issue("transactionLogs", l.id, "unknown_type", String(d.type));
      if (!SPEC.transactionLogs.statuses.includes(d.status)) issue("transactionLogs", l.id, "unknown_status", String(d.status));

      let refID = d.refID, refColl = d.refCollection;
      if (!isEmpty(d.refundRequestID)) {
        if (isEmpty(refID)) { setRef(l, d.refundRequestID, "refundRequests", "refID_filled_from_refundRequestID"); refID = d.refundRequestID; refColl = "refundRequests"; }
        else if (refID === d.refundRequestID && isEmpty(refColl)) { setField(l, "refCollection", "refundRequests", "refCollection_filled_from_refundRequestID"); refColl = "refundRequests"; }
        if (refID === d.refundRequestID && refColl === "refundRequests") dropField(l, "refundRequestID", "moved_to_refID");
        else issue("transactionLogs", l.id, "refundRequestID_differs_from_refID", `${d.refundRequestID} vs ${refColl}/${refID} -- field kept`);
      } else dropField(l, "refundRequestID", "empty_legacy_field");

      if (d.transactionID !== undefined) {   // old name of transactionLogsID
        if (isEmpty(d.transactionID) || d.transactionID === l.id) dropField(l, "transactionID", "equals_doc_id");
        else issue("transactionLogs", l.id, "transactionID_differs_from_doc_id", String(d.transactionID));
      }
      if (refColl === ENTRY_COLLECTION && refID && !entryMap.has(refID)) issue("transactionLogs", l.id, "entry_not_found", refID);

      const own = entryMap.get(l.id);   // e.g. log "<paymentID>_deposit" <-> entry "<paymentID>_deposit"
      if (isPaymentLog(d) && own && (!d.paymentID || own.paymentID === d.paymentID)) linkTo(l, l.id, "entry_linked_by_doc_id");
      sweepUnknown(l, ["refundRequestID", "transactionID"]);
    }
    for (const l of C.transactionLogs.values()) {   // pass 2: single, unclaimed entry with the same payment + amount
      const d = l.data;
      if (!isPaymentLog(d) || patchOf(l).set.refID !== undefined || !d.paymentID) continue;
      let c = (entriesIn.get(d.paymentID) || []).filter((x) => Number(x.e.amount) === Number(d.amount) && !linked.has(x.id));
      if (nullIfSentinel(d.referenceNumber) !== null) { const c2 = c.filter((x) => x.e.referenceNumber === d.referenceNumber); if (c2.length) c = c2; }
      if (c.length === 1) linkTo(l, c[0].id, "entry_linked_by_amount_match");
      else if (c.length > 1) issue("transactionLogs", l.id, "log_matches_several_entries", c.map((x) => x.id).join(","));
      // 0 candidates = the log is one settled total for several entries: left unlinked on purpose
    }
  }

  // ═══════════ plan -> report ═══════════
  const touched = [...patches.values()].filter((p) => Object.keys(p.set).length || p.del.size);
  for (const p of touched) {
    for (const f of [...Object.keys(p.set), ...p.del]) changes.push({ col: p.doc.col, id: p.doc.id, field: f, old: encode(p.doc.data[f] === undefined ? null : p.doc.data[f]), wasMissing: p.doc.data[f] === undefined });
  }
  const report = {
    mode, startedAt: now.toISOString(), flags: { drop: DROP, dropUnverified: DROP_UNV, only },
    stats, issues, created: creates.map((c) => ({ col: c.col, id: c.id })), changes,
  };
  log("\n──────── summary ────────");
  for (const c of ALL.filter(want)) {
    const s = stats[c];
    log(`  ${c.padEnd(21)} ${JSON.stringify({ created: s.created || undefined, fixed: Object.keys(s.fixed).length ? s.fixed : undefined, dropped: Object.keys(s.dropped).length ? s.dropped : undefined, unverified_keys: Object.keys(s.unverified).length ? s.unverified : undefined })}`);
  }
  log(`  new docs: ${creates.length}   documents changed: ${touched.length}   field changes: ${changes.length}`);
  const byCode = {}; for (const i of issues) inc(byCode, `${i.col}:${i.code}`);
  log("\n  NEEDS YOUR EYES (not changed automatically):");
  if (!issues.length) log("    none");
  for (const [k, n] of Object.entries(byCode)) log(`    ${String(n).padStart(3)}  ${k}`);

  if (!WRITE) {
    log("\n  (dry run -- nothing written; add --write to apply)");
    report.file = saveReport(report, "normalize-legacy-dryrun");
    return report;
  }

  // ═══════════ write ═══════════
  const bdir = path.join(outDir, "backups", `normalize-legacy-${stamp(now)}`);
  fs.mkdirSync(bdir, { recursive: true });
  const byCol = new Map(); for (const p of touched) push(byCol, p.doc.col, { id: p.doc.id, ...encode(p.doc.data) });
  for (const [col, rows] of byCol) { fs.writeFileSync(path.join(bdir, `${col}.json`), JSON.stringify(rows, null, 2)); log(`  backup  ${col}: ${rows.length} docs -> ${path.relative(process.cwd(), bdir) || bdir}`); }

  const b = makeBatcher();
  for (const c of creates) await b.add((bt) => bt.set(db.collection(c.col).doc(c.id), c.data));
  await b.flush();   // new rows exist before anything that depends on them is changed
  for (const p of touched) {
    const patch = { ...p.set }; for (const f of p.del) patch[f] = FieldValue.delete();
    await b.add((bt) => bt.update(p.doc.ref || db.collection(p.doc.col).doc(p.doc.id), patch));
  }
  await b.flush();
  log("\n  written. To undo: --rollback=<report> --write");
  report.file = saveReport(report, "normalize-legacy-write");
  return report;
};

// ═════════════════════ built-in self-test (touches NO real database) ═════════════════════
//   node scripts/normalize-legacy-data.js --selftest=scripts/exports/<export-folder>
// Loads that export into a tiny in-memory Firestore, then: write -> write again (must change nothing) -> rollback (must restore exactly).
const makeFakeDb = (seed) => {
  const cols = new Map(); const getCol = (n) => { if (!cols.has(n)) cols.set(n, new Map()); return cols.get(n); };
  for (const [name, rows] of Object.entries(seed)) for (const [id, d] of Object.entries(rows)) getCol(name).set(id, structuredClone(d));
  const DEL = Symbol("delete"); const FieldValue = { delete: () => DEL };
  const snapOf = (name, id, ref) => ({ id, exists: getCol(name).has(id), ref, data: () => (getCol(name).has(id) ? structuredClone(getCol(name).get(id)) : undefined) });
  const mkRef = (name, id) => {
    const ref = { id, path: `${name}/${id}` };
    ref.get = async () => snapOf(name, id, ref);
    ref.set = async (d) => { getCol(name).set(id, structuredClone(d)); };
    ref.update = async (patch) => {
      if (!getCol(name).has(id)) throw new Error(`NOT_FOUND: ${name}/${id}`);
      const cur = { ...getCol(name).get(id) };
      for (const [k, v] of Object.entries(patch)) { if (v === DEL) delete cur[k]; else cur[k] = structuredClone(v); }
      getCol(name).set(id, cur);
    };
    ref.delete = async () => { getCol(name).delete(id); };
    return ref;
  };
  const db = {
    collection: (name) => ({ doc: (id) => mkRef(name, id), get: async () => ({ docs: [...getCol(name).keys()].map((id) => snapOf(name, id, mkRef(name, id))) }) }),
    batch: () => { const ops = []; return { set: (r, d) => ops.push(() => r.set(d)), update: (r, d) => ops.push(() => r.update(d)), delete: (r) => ops.push(() => r.delete()), commit: async () => { for (const o of ops) await o(); } }; },
  };
  return { db, FieldValue, raw: getCol };
};

const selfTest = async (dir) => {
  const os = await import("node:os");
  const revive = (v) => (v === null || typeof v !== "object" ? v : v.__type === "timestamp" ? new Date(v.iso) : Array.isArray(v) ? v.map(revive) : Object.fromEntries(Object.entries(v).map(([k, x]) => [k, revive(x)])));
  const seed = {};
  for (const f of fs.readdirSync(dir)) if (f.endsWith(".json") && f !== "manifest.json") seed[f.slice(0, -5)] = Object.fromEntries(JSON.parse(fs.readFileSync(path.join(dir, f), "utf8")).map((r) => [r.id, revive(r.data)]));
  const names = ["bookings", "payments", "paymentEntries", "driverAssignments", "refundRequests", "cancellationRequests", "penalties", "transactionLogs"];
  const missing = names.filter((n) => !seed[n]);
  if (missing.length) { console.log(`\nThis export folder has no: ${missing.join(", ")}. Use a full export (node scripts/export-firestore.js).`); return false; }
  const fake = makeFakeDb(seed);
  const sortKeys = (v) => (v instanceof Date ? v.toISOString() : Array.isArray(v) ? v.map(sortKeys) : v && typeof v === "object" ? Object.fromEntries(Object.keys(v).sort().map((k) => [k, sortKeys(v[k])])) : v);
  const snap = () => JSON.stringify(names.map((n) => [n, [...fake.raw(n).entries()].sort(([a], [b]) => (a < b ? -1 : 1)).map(([id, d]) => [id, sortKeys(d)])]));
  const outDir = fs.mkdtempSync(path.join(os.tmpdir(), "normalize-selftest-"));
  const A = ["--write", "--drop-legacy", "--confirm-readers-switched"];
  const run = (argv, t) => main({ db: fake.db, FieldValue: fake.FieldValue, argv, outDir, log: () => {}, now: new Date(Date.now() + t) });
  const before = snap();
  const r1 = await run(A, 0);
  const afterWrite = snap();
  const r2 = await run(A, 1000);
  await run([`--rollback=${r1.file}`, "--write"], 2000);
  const checks = [
    [`write changed the data (${r1.created.length} new docs, ${r1.changes.length} field changes)`, before !== afterWrite],
    [`second run changes nothing (${r2.created.length} new docs, ${r2.changes.length} field changes)`, r2.created.length === 0 && r2.changes.length === 0],
    ["rollback restores the original data exactly", snap() === before],
  ];
  console.log("\nSELF-TEST (in-memory copy of your export, no real database touched)");
  const tlIssues = {}; for (const i of r1.issues) if (i.col === "transactionLogs") tlIssues[i.code] = (tlIssues[i.code] || 0) + 1;
  console.log(`  transactionLogs, first run: fixed ${JSON.stringify(r1.stats.transactionLogs.fixed)}  dropped ${JSON.stringify(r1.stats.transactionLogs.dropped)}  needs eyes ${JSON.stringify(tlIssues)}`);
  if (r2.changes.length || r2.created.length) {
    console.log("\n  Second run still changed:");
    for (const c of r2.created) console.log(`    NEW DOC   ${c.col || c.collection}/${c.id}`);
    for (const c of r2.changes) console.log(`    ${c.col}/${c.id}  field "${c.field}"  was ${JSON.stringify(c.old)}${c.wasMissing ? " (missing)" : ""}`);
  }
  if (snap() !== before) {
    const a = JSON.parse(before), b = JSON.parse(snap());
    console.log("\n  After rollback these documents differ from the original:");
    for (const [i, [n]] of a.entries()) {
      const A1 = new Map(a[i][1]), B1 = new Map(b[i][1]);
      for (const id of new Set([...A1.keys(), ...B1.keys()])) if (JSON.stringify(A1.get(id)) !== JSON.stringify(B1.get(id))) console.log(`    ${n}/${id}\n      original: ${JSON.stringify(A1.get(id))?.slice(0, 400)}\n      now:      ${JSON.stringify(B1.get(id))?.slice(0, 400)}`);
    }
  }
  for (const [label, ok] of checks) console.log(`  ${ok ? "PASS" : "FAIL"}  ${label}`);
  return checks.every(([, ok]) => ok);
};

// ── run directly ──
if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const st = process.argv.find((x) => x.startsWith("--selftest="));
  if (st) { const ok = await selfTest(st.slice(11)); process.exit(ok ? 0 : 1); }
  const { db } = await import("../config/firebaseConnection/firebase.js");
  const admin = (await import("firebase-admin")).default;
  try {
    await main({ db, FieldValue: admin.firestore.FieldValue, Timestamp: admin.firestore.Timestamp, argv: process.argv.slice(2) });
    process.exit(0);
  } catch (err) {
    console.error("\nNormalize failed:", err);
    process.exit(1);
  }
}