# Retired one-off scripts

These ran once against the old paymentEntries shape (flags, parentEntryID, migratedFrom, proofUrl,
refID / refCollection, note) and were retired when those columns were removed. They import the mapper and
write the OLD field names, so they are kept for history only -- do not run them. Their relative imports
are not updated.

The replacement is `scripts/migrate-entry-columns.js`.
