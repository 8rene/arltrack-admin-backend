// One-time migration: legacy payment / penalty fields -> paymentEntries.
//
//   PHASE 1 (additive -- nothing is deleted, safe to re-run)
//     node scripts/migrate-payment-entries.js                  dry run, prints + saves a report
//     node scripts/migrate-payment-entries.js --write          backs up, then writes
//     node scripts/migrate-payment-entries.js --only=payments  payments | penalties | refunds | archives | logs | sentinels
//     node scripts/migrate-payment-entries.js --limit=20       first N payments (try it small)
//     node scripts/migrate-payment-entries.js --overwrite --write   re-derive rows that already exist
//
//   UNDO phase 1 (deletes the rows it created, restores sentinel / log values it changed)
//     node scripts/migrate-payment-entries.js --rollback=scripts/reports/<report>.json --write
//
//   PHASE 2 (destructive -- ONLY after every reader hydrates; see README)
//     node scripts/migrate-payment-entries.js --cleanup                                  dry run
//     node scripts/migrate-payment-entries.js --cleanup --write --confirm-readers-switched
//     add --drop-array to also remove payments.paymongoTransactions
//
// What phase 1 does:
//   payments (+ paymentsArchives)  -> "deposit" / "balance" rows, ids <paymentID>_deposit | _balance
//   penalties (+ penaltyArchives)  -> one "legacy_aggregate" row <penaltyID>_legacy for money actually
//                                     received. Deposit-covered penalties get NO row; penalties on a
//                                     booking whose deposit was settled go to the review list.
//   refundRequests (+ refundArchives) -> "out" rows: one per PayMongo refund part (<id>_part<n>), the in-person
//                                     hand-back (<id>_manual), and any amount recorded as unrefundable.
//                                     Nothing is invented: a Pending / Rejected request has no rows yet.
//   transactionLogs                -> refID / refCollection filled (refundRequestID -> refundRequests,
//                                     <paymentID>_deposit|_balance -> paymentEntries); sentinel
//                                     referenceNumber ("—", "") -> null
//   payments.referenceNumber       -> sentinel ("N/A", "—", "") -> null
//
// A booking's archived payment / penalty uses its originalId, the same id a restore brings back,
// so rows built here reconnect automatically when it is restored.
import "dotenv/config";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { ENTRY_COLLECTION } from "../models/paymentEntries/paymentEntry.model.js";
import {
  buildPaymentEntries, buildLegacyPenaltyEntry, buildRefundEntries, mergeEntry, mergeRefundEntry, nullIfSentinel,
} from "../services/paymentEntries/paymentEntries.mapper.js";

const HERE = path.dirname(fileURLToPath(import.meta.url));

// Phase 2: these move to paymentEntries and are restored on read by hydratePayment / hydratePenalty.
// NOT here on purpose: referenceNumber + paymentMethod (reports read them), paymongoSessionID +
// checkoutUrl (the webhook finds the payment by session id), balanceCollectedAmount (the breakdown
// needs it), paymongoFeeTotal (cache), and everything else analytics / dashboard read.
const MOVED_PAYMENT_FIELDS = [
  "depositPaymongoPaymentID", "balancePaymongoPaymentID", "paymongoPaymentID",
  "depositPaymongoFee", "balancePaymongoFee", "paymongoChannel", "proofUrl", "lastSettledVia",
  "paidAt", "balancePaidAt", "confirmedBy", "confirmedAt",
  "balanceMethod", "balanceCollectedBy", "balanceCollectedAt",
];
const MOVED_PENALTY_FIELDS = ["paymentMethod", "referenceNumber", "paidAt"];

const stamp = (d) => d.toISOString().replace(/[:.]/g, "-");
const inc = (obj, k, n = 1) => { obj[k] = (obj[k] || 0) + n; };

export const main = async ({ db, FieldValue, argv = [], log = console.log, now = new Date(), outDir = HERE }) => {
  const flag = (n) => argv.includes(`--${n}`);
  const val = (n) => { const a = argv.find((x) => x.startsWith(`--${n}=`)); return a ? a.slice(n.length + 3) : null; };
  const WRITE = flag("write");
  const OVERWRITE = flag("overwrite");
  const limit = val("limit") ? Number(val("limit")) : null;
  const only = val("only") ? val("only").split(",").map((s) => s.trim()) : null;
  const want = (k) => !only || only.includes(k);

  const load = async (name) => (await db.collection(name).get()).docs.map((d) => ({ id: d.id, data: d.data(), ref: d.ref }));
  const mode = WRITE ? "WRITE" : "DRY RUN";

  // ── batching ──
  const makeBatcher = () => {
    let batch = db.batch(); let n = 0; let total = 0;
    const flush = async () => { if (n) { if (WRITE) await batch.commit(); total += n; batch = db.batch(); n = 0; } };
    const add = async (fn) => { if (WRITE) fn(batch); n += 1; if (n >= 400) await flush(); };
    return { add, flush, total: () => total + n };
  };

  const backup = async (names) => {
    const dir = path.join(outDir, "backups", `payment-entries-${stamp(now)}`);
    fs.mkdirSync(dir, { recursive: true });
    for (const name of names) {
      const rows = await load(name);
      fs.writeFileSync(path.join(dir, `${name}.json`), JSON.stringify(rows.map((r) => ({ id: r.id, ...r.data })), null, 2));
      log(`  backup  ${name}: ${rows.length} docs -> ${path.relative(process.cwd(), dir) || dir}`);
    }
    return dir;
  };

  const saveReport = (report, name) => {
    const dir = path.join(outDir, "reports");
    fs.mkdirSync(dir, { recursive: true });
    const file = path.join(dir, `${name}-${stamp(now)}.json`);
    fs.writeFileSync(file, JSON.stringify(report, null, 2));
    log(`\nReport saved: ${path.relative(process.cwd(), file) || file}`);
    return file;
  };

  // ═════════════════ ROLLBACK ═════════════════
  if (val("rollback")) {
    const rep = JSON.parse(fs.readFileSync(val("rollback"), "utf8"));
    log(`\n[${mode}] rollback of ${val("rollback")}`);
    log(`  rows to delete: ${(rep.written || []).length}   document fields to restore: ${(rep.docChanges || []).length}`);
    if ((rep.updated || []).length) log(`  note: ${(rep.updated || []).length} rows were re-derived with --overwrite; that cannot be undone (they were re-derived from the same documents).`);
    const b = makeBatcher();
    for (const id of rep.written || []) await b.add((bt) => bt.delete(db.collection(ENTRY_COLLECTION).doc(id)));
    for (const c of rep.docChanges || []) {
      await b.add((bt) => bt.update(db.collection(c.col).doc(c.id), { [c.field]: c.old === undefined ? FieldValue.delete() : c.old }));
    }
    await b.flush();
    log(WRITE ? "  rollback written." : "  (dry run -- add --write to apply)");
    return { rolledBack: WRITE };
  }

  // ═════════════════ PHASE 2: CLEANUP ═════════════════
  if (flag("cleanup")) {
    log(`\n[${mode}] PHASE 2 cleanup -- removes the legacy fields that paymentEntries now holds`);
    if (WRITE && !flag("confirm-readers-switched")) {
      log("\n  REFUSING to write. This deletes fields that code still reads unless every reader goes through");
      log("  hydratePayments / hydratePenalties. Once that is true, re-run with --confirm-readers-switched.");
      return { refused: true };
    }
    const entries = await load(ENTRY_COLLECTION);
    const byPayment = new Map(); const byPenalty = new Map();
    for (const e of entries) {
      if (e.data.paymentID) (byPayment.get(e.data.paymentID) || byPayment.set(e.data.paymentID, []).get(e.data.paymentID)).push(e.data);
      if (e.data.refCollection === "penalties") (byPenalty.get(e.data.refID) || byPenalty.set(e.data.refID, []).get(e.data.refID)).push(e.data);
    }
    const report = { mode, phase: 2, payments: { cleaned: 0, skipped: {}, fieldsRemoved: 0 }, penalties: { cleaned: 0, skipped: {}, fieldsRemoved: 0 }, docChanges: [] };
    const dropFields = flag("drop-array") ? [...MOVED_PAYMENT_FIELDS, "paymongoTransactions"] : MOVED_PAYMENT_FIELDS;
    if (WRITE) await backup(["payments", "paymentsArchives", "penalties", "penaltyArchives"]);
    const b = makeBatcher();

    for (const name of ["payments", "paymentsArchives"]) {
      for (const d of await load(name)) {
        const docID = d.data.originalId || d.id;
        const { entries: expected } = buildPaymentEntries(d.data, docID);
        const have = new Map((byPayment.get(d.data.paymentID || docID) || []).map((e) => [e.paymentEntryID, e]));
        if (!expected.length) { inc(report.payments.skipped, "no_entries_expected"); continue; }
        const missing = expected.filter((e) => {
          const h = have.get(e.paymentEntryID);
          return !h || h.amount !== e.amount || h.status !== e.status;
        });
        if (missing.length) { inc(report.payments.skipped, "entries_missing_or_different"); continue; }
        const present = dropFields.filter((f) => d.data[f] !== undefined);
        if (!present.length) continue;
        const patch = Object.fromEntries(present.map((f) => [f, FieldValue.delete()]));
        for (const f of present) report.docChanges.push({ col: name, id: d.id, field: f, old: d.data[f] });
        report.payments.cleaned += 1; report.payments.fieldsRemoved += present.length;
        await b.add((bt) => bt.update(d.ref, patch));
      }
    }
    for (const name of ["penalties", "penaltyArchives"]) {
      for (const d of await load(name)) {
        const penaltyID = d.data.penaltyID || d.data.originalId || d.id;
        if (!(byPenalty.get(penaltyID) || []).length) { inc(report.penalties.skipped, "no_entries"); continue; }
        const present = MOVED_PENALTY_FIELDS.filter((f) => d.data[f] !== undefined);
        if (!present.length) continue;
        const patch = Object.fromEntries(present.map((f) => [f, FieldValue.delete()]));
        for (const f of present) report.docChanges.push({ col: name, id: d.id, field: f, old: d.data[f] });
        report.penalties.cleaned += 1; report.penalties.fieldsRemoved += present.length;
        await b.add((bt) => bt.update(d.ref, patch));
      }
    }
    await b.flush();
    log(`  payments : ${report.payments.cleaned} cleaned, ${report.payments.fieldsRemoved} fields removed, skipped ${JSON.stringify(report.payments.skipped)}`);
    log(`  penalties: ${report.penalties.cleaned} cleaned, ${report.penalties.fieldsRemoved} fields removed, skipped ${JSON.stringify(report.penalties.skipped)}`);
    log(WRITE ? "  cleanup written." : "  (dry run -- nothing written)");
    report.file = saveReport(report, "payment-entries-cleanup");
    return report;
  }

  // ═════════════════ PHASE 1: BACKFILL ═════════════════
  log(`\n[${mode}] PHASE 1 backfill${only ? ` (only: ${only.join(", ")})` : ""}${limit ? ` (limit ${limit})` : ""}${OVERWRITE ? " (overwrite)" : ""}`);

  const report = {
    mode, phase: 1, startedAt: now.toISOString(),
    entries: { created: 0, updated: 0, skippedExisting: 0, byPhase: {}, byStatus: {}, bySource: {}, byDirection: {}, flags: {} },
    skipped: {},
    review: { depositInvolved: [], depositOffset: 0 },
    flagged: { missing_payment_id: [], payment_id_missing: [], discount_review: [], amount_inferred: [], refunded_legacy: [], legacy_aggregate: 0, unmapped: [] },
    refunds: { scanned: 0, withRows: 0, pendingHandBacks: [] },
    logs: { refIDFilled: 0, sentinelCleared: 0 },
    sentinels: { paymentsReferenceNumber: 0 },
    written: [], updated: [], docChanges: [],
  };

  // existing rows (so a re-run only fills gaps)
  const existing = new Map((await load(ENTRY_COLLECTION)).map((e) => [e.id, e.data]));
  const entryIDs = new Set(existing.keys());

  const b = makeBatcher();
  const writeEntry = async (e) => {
    const prev = existing.get(e.paymentEntryID);
    entryIDs.add(e.paymentEntryID);
    const ref = db.collection(ENTRY_COLLECTION).doc(e.paymentEntryID);
    if (!prev) {
      report.entries.created += 1; report.written.push(e.paymentEntryID);
      await b.add((bt) => bt.set(ref, e));
    } else if (OVERWRITE) {
      const patch = e.direction === "out" ? mergeRefundEntry(prev, e, { now }) : mergeEntry(prev, e);
      if (patch) { report.entries.updated += 1; report.updated.push(e.paymentEntryID); await b.add((bt) => bt.update(ref, patch)); }
    } else {
      report.entries.skippedExisting += 1;
      return;
    }
    inc(report.entries.byPhase, e.phase); inc(report.entries.byStatus, e.status); inc(report.entries.bySource, e.source); inc(report.entries.byDirection, e.direction);
    for (const f of e.flags || []) {
      if (f.startsWith("method_unmapped:")) report.flagged.unmapped.push({ id: e.paymentEntryID, flag: f });
      else if (f === "legacy_aggregate") report.flagged.legacy_aggregate += 1;
      else if (report.flagged[f]) report.flagged[f].push(e.paymentID || e.refID);
    }
  };

  // backup what phase 1 will modify (new rows don't need one -- they only add)
  const modifies = [];
  if (want("logs") || want("sentinels")) modifies.push("transactionLogs");
  if (want("sentinels")) modifies.push("payments");
  if (WRITE && modifies.length) await backup([...new Set(modifies)]);

  const livePayments = await load("payments");
  const archivedPayments = (want("archives") || want("penalties") || want("refunds")) ? await load("paymentsArchives") : [];
  const paymentsByID = new Map();
  for (const d of [...livePayments, ...archivedPayments]) paymentsByID.set(d.data.paymentID || d.data.originalId || d.id, d.data);

  // ── A. payments (+ archived payments) ──
  if (want("payments") || want("archives")) {
    const sets = [];
    if (want("payments")) sets.push({ rows: limit ? livePayments.slice(0, limit) : livePayments, tag: "payments.legacy", label: "payments" });
    if (want("archives")) sets.push({ rows: archivedPayments, tag: "paymentsArchives.legacy", label: "paymentsArchives" });
    for (const s of sets) {
      let n = 0;
      for (const d of s.rows) {
        const docID = d.data.originalId || d.id;
        const { entries, skipped } = buildPaymentEntries(d.data, docID, { now, migratedFrom: s.tag });
        for (const k of skipped) inc(report.skipped, `${s.label}:${k.phase}:${k.reason}`);
        for (const e of entries) await writeEntry(e);
        n += 1;
      }
      log(`  ${s.label.padEnd(17)} ${n} docs scanned`);
    }
  }

  // ── B. penalties (+ archived penalties) ──
  if (want("penalties") || want("archives")) {
    const sets = [];
    if (want("penalties")) sets.push({ name: "penalties", tag: "penalties.legacy" });
    if (want("archives")) sets.push({ name: "penaltyArchives", tag: "penaltyArchives.legacy" });
    for (const s of sets) {
      const rows = await load(s.name);
      for (const d of rows) {
        const penaltyID = d.data.penaltyID || d.data.originalId || d.id;
        const out = buildLegacyPenaltyEntry({ ...d.data, penaltyID }, penaltyID, paymentsByID.get(d.data.paymentID), { now, migratedFrom: s.tag });
        if (out.entry) await writeEntry(out.entry);
        else if (out.review === "deposit_involved") report.review.depositInvolved.push(penaltyID);
        else if (out.review === "deposit_offset") report.review.depositOffset += 1;
      }
      log(`  ${s.name.padEnd(17)} ${rows.length} docs scanned`);
    }
  }

  // ── B2. refund requests (+ archived) -> "out" rows ──
  if (want("refunds") || want("archives")) {
    const sets = [];
    if (want("refunds")) sets.push({ name: "refundRequests", tag: "refunds.legacy" });
    if (want("archives")) sets.push({ name: "refundArchives", tag: "refundArchives.legacy" });
    for (const s of sets) {
      const rows = await load(s.name);
      for (const d of rows) {
        const rid = d.data.refundRequestID || d.data.originalId || d.id;
        const { entries } = buildRefundEntries({ ...d.data, refundRequestID: rid }, rid, { now, migratedFrom: s.tag, payment: paymentsByID.get(d.data.paymentID) });
        report.refunds.scanned += 1;
        if (entries.length) report.refunds.withRows += 1;
        for (const e of entries) {
          await writeEntry(e);
          if (e.source === "in_person" && e.status === "pending") report.refunds.pendingHandBacks.push(rid);
        }
      }
      log(`  ${s.name.padEnd(17)} ${rows.length} docs scanned`);
    }
  }
  await b.flush();

  // ── C + D. transactionLogs (refID / refCollection, sentinels) and payments.referenceNumber ──
  if (want("logs") || want("sentinels")) {
    const lb = makeBatcher();
    const logs = await load("transactionLogs");
    for (const d of logs) {
      const x = d.data; const patch = {};
      if (want("logs") && !x.refID) {
        if (x.refundRequestID) { patch.refID = x.refundRequestID; patch.refCollection = "refundRequests"; }
        else if (/_(deposit|balance)$/.test(d.id) && entryIDs.has(d.id)) { patch.refID = d.id; patch.refCollection = ENTRY_COLLECTION; }
        if (patch.refID) report.logs.refIDFilled += 1;
      }
      if (want("sentinels") && x.referenceNumber !== undefined && x.referenceNumber !== null && nullIfSentinel(x.referenceNumber) === null) {
        patch.referenceNumber = null; report.logs.sentinelCleared += 1;
      }
      if (!Object.keys(patch).length) continue;
      for (const k of Object.keys(patch)) report.docChanges.push({ col: "transactionLogs", id: d.id, field: k, old: x[k] });
      await lb.add((bt) => bt.update(d.ref, patch));
    }
    if (want("sentinels")) {
      for (const d of livePayments) {
        const rn = d.data.referenceNumber;
        if (rn === undefined || rn === null || nullIfSentinel(rn) !== null) continue;
        report.sentinels.paymentsReferenceNumber += 1;
        report.docChanges.push({ col: "payments", id: d.id, field: "referenceNumber", old: rn });
        await lb.add((bt) => bt.update(d.ref, { referenceNumber: null }));
      }
    }
    await lb.flush();
    log(`  transactionLogs   ${logs.length} docs scanned`);
  }

  // ── summary ──
  const E = report.entries;
  log("\n──────── summary ────────");
  log(`  entries   created ${E.created}   updated ${E.updated}   already there ${E.skippedExisting}`);
  log(`  by phase  ${JSON.stringify(E.byPhase)}   by status ${JSON.stringify(E.byStatus)}   by source ${JSON.stringify(E.bySource)}   direction ${JSON.stringify(E.byDirection)}`);
  log(`  skipped   ${JSON.stringify(report.skipped)}`);
  log(`  logs      refID filled ${report.logs.refIDFilled}   sentinel referenceNumber cleared ${report.logs.sentinelCleared}`);
  log(`  payments  referenceNumber sentinel -> null: ${report.sentinels.paymentsReferenceNumber}`);
  log("\n  NEEDS YOUR EYES:");
  log(`    online + paid but NO payment id (the "Payment ID does not exist" cases): ${report.flagged.missing_payment_id.length}${report.flagged.missing_payment_id.length ? "  " + report.flagged.missing_payment_id.slice(0, 10).join(", ") : ""}`);
  log(`    payments with a staff discount, paid amount unconfirmed             : ${report.flagged.discount_review.length}`);
  log(`    balance collected without a recorded amount (amount was inferred)    : ${report.flagged.amount_inferred.length}`);
  log(`    payments already Refunded (their refund rows are made above)         : ${report.flagged.refunded_legacy.length}`);
  log(`    refund amounts with NO payment id ("Payment ID does not exist")       : ${report.flagged.payment_id_missing.length}${report.flagged.payment_id_missing.length ? "  " + report.flagged.payment_id_missing.slice(0, 10).join(", ") : ""}`);
  log(`    refunds still waiting for an in-person hand-back                     : ${report.refunds.pendingHandBacks.length}`);
  log(`    penalties on a deposit-settled booking (not converted, review)       : ${report.review.depositInvolved.length}`);
  log(`    unknown payment method text                                          : ${report.flagged.unmapped.length}`);
  log(WRITE ? "\n  Written. To undo: --rollback=<this report> --write" : "\n  (dry run -- nothing written; add --write to apply)");
  report.file = saveReport(report, WRITE ? "payment-entries-phase1" : "payment-entries-phase1-dryrun");
  return report;
};

// ── run directly: node scripts/migrate-payment-entries.js [flags] ──
if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const { db } = await import("../config/firebaseConnection/firebase.js");
  const admin = (await import("firebase-admin")).default;
  try {
    await main({ db, FieldValue: admin.firestore.FieldValue, argv: process.argv.slice(2) });
    process.exit(0);
  } catch (err) {
    console.error("\nMigration failed:", err);
    process.exit(1);
  }
}
