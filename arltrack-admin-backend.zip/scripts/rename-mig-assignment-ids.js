// One-off: remove the "mig_drv_" prefix from migrated driverAssignments rows.
//   doc ID        mig_drv_<bookingDocID>  ->  <bookingDocID>
//   assignmentID  mig_drv_<bookingDocID>  ->  <bookingDocID>   (kept equal to the doc ID)
// Every other field (status, driverID, assignedAt, endedAt, ...) is copied unchanged, so
// anything the live app has changed since the migration is preserved.
//
// Put this file in arltrack-admin-backend/scripts/ and run it from arltrack-admin-backend/.
// DRY RUN BY DEFAULT. Nothing is written unless you pass --write.
//
//   node scripts/rename-mig-assignment-ids.js
//   node scripts/rename-mig-assignment-ids.js --write
//
// Safe to re-run: rows without the prefix are ignored, and a row is skipped (and reported)
// if a document with the new ID already exists.

import "dotenv/config";
import admin from "firebase-admin";

const WRITE = process.argv.includes("--write");
const PREFIX = "mig_drv_";

if (process.env.FIREBASE_SERVICE_ACCOUNT) {
  const sa = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT.replace(/\r?\n/g, ""));
  sa.private_key = sa.private_key.replace(/\\n/g, "\n");
  admin.initializeApp({ credential: admin.credential.cert(sa) });
} else {
  admin.initializeApp({ credential: admin.credential.applicationDefault() });
}
const db = admin.firestore();

(async () => {
  console.log(`RENAME mig_drv_ IDs -- ${WRITE ? "WRITE" : "DRY RUN (nothing will be written)"}\n`);
  const snap = await db.collection("driverAssignments").get();
  const s = { total: snap.size, withPrefix: 0, renamed: 0, skippedTargetExists: [], sample: [] };
  let batch = db.batch(); let n = 0;

  for (const d of snap.docs) {
    if (!d.id.startsWith(PREFIX)) continue;
    s.withPrefix++;
    const newID = d.id.slice(PREFIX.length);
    if (!newID) continue;
    const target = db.collection("driverAssignments").doc(newID);
    if ((await target.get()).exists) { s.skippedTargetExists.push(newID); continue; }
    s.renamed++;
    if (s.sample.length < 5) s.sample.push(`${d.id}  ->  ${newID}`);
    if (WRITE) {
      batch.create(target, { ...d.data(), assignmentID: newID });
      batch.delete(d.ref);
      n += 2;
      if (n >= 400) { await batch.commit(); batch = db.batch(); n = 0; }
    }
  }
  if (WRITE && n) await batch.commit();

  console.log(JSON.stringify(s, null, 2));
  if (!WRITE) console.log("\nDry run only. Re-run with --write to apply.");
  process.exit(0);
})().catch((err) => { console.error("Rename failed:", err); process.exit(1); });