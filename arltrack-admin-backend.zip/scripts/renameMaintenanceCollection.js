// One-time script — rename Firestore collection "carMaintenance" -> "maintenance".
// Put it in arltrack-admin-backend/scripts/ and run it from arltrack-admin-backend/.
// Delete it afterward.
//
// Firestore can't rename a collection, so this:
//   1. Copies every carMaintenance doc into maintenance, SAME doc ID
//      (other records point at maintenance by ID, so IDs must not change).
//   2. Rewrites refCollection: "carMaintenance" -> "maintenance" on
//      notifications, transactionLogs and transactionLogArchives.
//   3. (only with --delete-old) deletes the old carMaintenance docs after
//      verifying every one of them exists in maintenance.
//
// SAFE BY DEFAULT: with no flags it's a dry run — it only counts and prints.
//
//   node scripts/renameMaintenanceCollection.js                 # dry run
//   node scripts/renameMaintenanceCollection.js --apply         # copy + fix refCollection
//   node scripts/renameMaintenanceCollection.js --apply --overwrite
//        # same, but also overwrite docs already in maintenance with the
//        # carMaintenance version (use for the 2nd pass, right after deploy,
//        # to catch edits made while old code was still live)
//   node scripts/renameMaintenanceCollection.js --apply --delete-old
//        # last step, once the new code is live and working
//
// Recommended order: dry run -> --apply -> deploy all 3 apps (admin backend,
// admin frontend, customer backend) -> --apply --overwrite -> check the app
// -> --apply --delete-old.
import "dotenv/config";
import { db } from "../config/firebaseConnection/firebase.js";

const OLD = "carMaintenance";
const NEW = "maintenance";
const REF_COLLECTIONS_TO_FIX = ["notifications", "transactionLogs", "transactionLogArchives"];

const args = new Set(process.argv.slice(2));
const APPLY = args.has("--apply");
const OVERWRITE = args.has("--overwrite");
const DELETE_OLD = args.has("--delete-old");

const BATCH_LIMIT = 400; // Firestore max is 500 ops per batch

const commitInChunks = async (ops) => {
  for (let i = 0; i < ops.length; i += BATCH_LIMIT) {
    const batch = db.batch();
    ops.slice(i, i + BATCH_LIMIT).forEach((fn) => fn(batch));
    await batch.commit();
  }
};

const step1CopyDocs = async () => {
  console.log(`\n── Step 1: copy ${OLD} -> ${NEW} ──`);
  const [oldSnap, newSnap] = await Promise.all([
    db.collection(OLD).get(),
    db.collection(NEW).get(),
  ]);
  const existingNew = new Set(newSnap.docs.map((d) => d.id));

  const toCopy = [];
  let skipped = 0;
  for (const d of oldSnap.docs) {
    if (existingNew.has(d.id) && !OVERWRITE) { skipped++; continue; }
    toCopy.push(d);
  }

  console.log(`  ${OLD}: ${oldSnap.size} docs | ${NEW} already has: ${newSnap.size} docs`);
  console.log(`  to copy: ${toCopy.length} | skipped (already in ${NEW}): ${skipped}${OVERWRITE ? " (overwrite ON)" : ""}`);

  if (!APPLY) return;
  await commitInChunks(
    toCopy.map((d) => (batch) => batch.set(db.collection(NEW).doc(d.id), d.data()))
  );
  console.log(`  ✅ copied ${toCopy.length} docs`);
};

const step2FixRefCollection = async () => {
  console.log(`\n── Step 2: fix refCollection "${OLD}" -> "${NEW}" ──`);
  for (const col of REF_COLLECTIONS_TO_FIX) {
    const snap = await db.collection(col).where("refCollection", "==", OLD).get();
    console.log(`  ${col}: ${snap.size} docs with refCollection "${OLD}"`);
    if (!APPLY || snap.empty) continue;
    await commitInChunks(
      snap.docs.map((d) => (batch) => batch.update(d.ref, { refCollection: NEW }))
    );
    console.log(`    ✅ updated ${snap.size}`);
  }
};

const step3DeleteOld = async () => {
  console.log(`\n── Step 3: delete old ${OLD} docs ──`);
  const [oldSnap, newSnap] = await Promise.all([
    db.collection(OLD).get(),
    db.collection(NEW).get(),
  ]);
  const inNew = new Set(newSnap.docs.map((d) => d.id));
  const missing = oldSnap.docs.filter((d) => !inNew.has(d.id));

  if (missing.length) {
    console.log(`  ❌ ABORTED: ${missing.length} ${OLD} docs are NOT in ${NEW} yet:`);
    missing.slice(0, 20).forEach((d) => console.log(`     - ${d.id}`));
    console.log("  Run with --apply first, then retry.");
    return;
  }
  console.log(`  verified: all ${oldSnap.size} docs exist in ${NEW}`);
  if (!APPLY) return;
  await commitInChunks(oldSnap.docs.map((d) => (batch) => batch.delete(d.ref)));
  console.log(`  ✅ deleted ${oldSnap.size} docs from ${OLD}`);
};

const main = async () => {
  console.log(APPLY ? "MODE: APPLY (writes to Firestore)" : "MODE: DRY RUN (no writes). Add --apply to execute.");
  if (DELETE_OLD && !APPLY) console.log("Note: --delete-old only takes effect together with --apply.");

  if (DELETE_OLD) {
    await step3DeleteOld();
  } else {
    await step1CopyDocs();
    await step2FixRefCollection();
  }
  console.log("\nDone.");
};

main().then(() => process.exit(0)).catch((err) => {
  console.error("Script failed:", err);
  process.exit(1);
});