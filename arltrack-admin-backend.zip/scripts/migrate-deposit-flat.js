// Moves the security deposit from the nested payments.deposit object to flat fields, and writes the deposit
// that was handed back as a paymentEntries out-row. Run from arltrack-admin-backend/
//
//   node scripts/migrate-deposit-flat.js                       dry run: report only, nothing written
//   node scripts/migrate-deposit-flat.js --write               applies it
//   node scripts/migrate-deposit-flat.js --rollback=<file> --write   puts the nested object back, removes the rows it made
//
// Per payment (collections: payments, paymentsArchives) that still has a nested `deposit` object:
//   securityDeposit      set from deposit.amount when the payment has none (waived deposits have amount 0: left alone)
//   depositStatus        deposit.status                     (Held | Waived | Settled | Forfeited | Refunded)
//   depositSettled       settlement.confirmedPenaltyTotal   (Settled only)
//   depositReturned      returned.amount                    (Settled only)
//   depositSettledAt     settlement.settledAt               (Settled, Waived); forfeitedAt / refundedAt (Forfeited, Refunded)
// Not carried over (the backup keeps them): waivedReason, settlement.settledBy, received.
//   <paymentID>_depositreturn   a paymentEntries out-row from deposit.returned (method, reference, by, at, amount),
//                               only when something was returned (amount > 0)
//   deposit              removed, but only in the same batch that writes the fields and the row.
//
// A deposit is KEPT as it is (and listed) when it does not add up: the stored net is not deposit - penalties, the
// returned amount is not the net, the status is blank or unknown. Nothing is guessed.
//
// Run it AFTER the code that reads both shapes is deployed (services/payments/depositView.js), and after whatever
// still writes the nested object (the customer backend's first-payment settle) has been switched to the flat
// fields -- otherwise new bookings bring the nested object back. Safe to re-run: payments that no longer have a
// nested object are skipped, and the out-row id is deterministic.
//
// Every write run saves scripts/backups/deposit-flat-<time>.json BEFORE writing; --rollback restores from it.
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { normalizeMethod, nullIfSentinel } from "../services/paymentEntries/paymentEntries.mapper.js";
import { getDepositView, settlementStatusFor, DEPOSIT_STATUSES } from "../services/payments/depositView.js";

const COLLECTIONS = ["payments", "paymentsArchives"];
const ENTRY_COLLECTION = "paymentEntries";

const num = (v) => { const n = Number(v); return Number.isFinite(n) ? n : 0; };
const has = (v) => v !== undefined && v !== null && v !== "";
const chunk = (arr, n) => { const out = []; for (let i = 0; i < arr.length; i += n) out.push(arr.slice(i, i + n)); return out; };

const toJSONSafe = (v) => JSON.parse(JSON.stringify(v, function (k, x) {
  const raw = this[k];
  if (raw instanceof Date) return { __ts: raw.getTime() };
  return raw && typeof raw.toMillis === "function" ? { __ts: raw.toMillis() } : x;
}));
const revive = (v) => JSON.parse(JSON.stringify(v), (k, x) => (x && typeof x === "object" && "__ts" in x ? new Date(x.__ts) : x));

/**
 * PURE. One payment document -> what the migration would do with it.
 *   { skip: "reason" }                 nothing to do (no nested object)
 *   { keep: "reason" }                 has a nested object that does not add up: left untouched, listed
 *   { patch, entry, entryID, flatKeys } patch = fields to set (plus the removal of `deposit`), entry = out-row or null
 */
export const planDepositMigration = (data, { id, now = new Date() } = {}) => {
  const p = data || {};
  const d = p.deposit;
  if (!d || typeof d !== "object") return { skip: "no nested deposit" };

  const view = getDepositView({ deposit: d });
  const status = view.status;
  if (!DEPOSIT_STATUSES.includes(status)) return { keep: `deposit.status is "${status}"` };

  // Flat fields already there: they win (as in getDepositView), so only the nested leftover is removed.
  if (has(p.depositStatus)) return { patch: { deposit: "__DELETE__" }, entry: null, entryID: null, flatKeys: [], note: "flat fields already present; nested object removed" };

  const s = d.settlement && d.settlement.status ? d.settlement : null;
  const patch = {};
  const flatKeys = ["depositStatus"];
  patch.depositStatus = status;
  if (view.amount > 0 && !num(p.securityDeposit)) patch.securityDeposit = view.amount;

  let entry = null; let entryID = null;
  if (status === "Settled") {
    if (!s) return { keep: "status Settled but no settlement" };
    const total = num(s.confirmedPenaltyTotal);
    const net = view.amount - total;
    if (num(s.net) !== net) return { keep: `settlement.net ${s.net} is not deposit ${view.amount} - penalties ${total}` };
    if (s.status !== settlementStatusFor(net)) return { keep: `settlement.status "${s.status}" does not match net ${net}` };
    const returned = num(d.returned && d.returned.amount);
    if (returned !== Math.max(0, net)) return { keep: `returned.amount ${returned} is not the net ${Math.max(0, net)}` };
    patch.depositSettled = total;
    patch.depositReturned = returned;
    patch.depositSettledAt = s.settledAt ?? null;
    flatKeys.push("depositSettled", "depositReturned", "depositSettledAt");
    if (returned > 0) {
      const paymentID = p.paymentID || id;
      const r = d.returned || {};
      const at = r.at || s.settledAt || now;
      entryID = `${paymentID}_depositreturn`;
      entry = {
        paymentEntryID: entryID, paymentID, bookingID: p.bookingID || null, userID: p.userID || null,
        refundReqID: null, penaltyID: null,
        direction: "out", phase: "deposit", source: "in_person",
        method: normalizeMethod(r.method).method, amount: returned, status: "success",
        referenceNumber: nullIfSentinel(r.referenceNumber), sessionID: null, transactionFee: null,
        processedBy: r.by ?? s.settledBy ?? null, processedAt: at, settledAt: at,
        groupID: null, transactionErrorNote: null, createdAt: at, updatedAt: now,
      };
    }
  } else if (status === "Waived") {
    patch.depositSettledAt = s ? (s.settledAt ?? null) : null;
    flatKeys.push("depositSettledAt");
  } else if (status === "Forfeited" || status === "Refunded") {
    const at = d.forfeitedAt || d.refundedAt;
    if (at) { patch.depositSettledAt = at; flatKeys.push("depositSettledAt"); }
  } else if (s) {
    return { keep: `status ${status} but a settlement is recorded` };
  }
  patch.deposit = "__DELETE__";
  return { patch, entry, entryID, flatKeys };
};

export const main = async ({ db, FieldValue, argv = [], log = console.log, now = new Date(), outDir } = {}) => {
  const arg = (k) => (argv.find((a) => a.startsWith(`--${k}=`)) || "").slice(k.length + 3);
  const WRITE = argv.includes("--write");
  const rollbackFile = arg("rollback");
  const dir = outDir || path.join(path.dirname(fileURLToPath(import.meta.url)), "backups");
  const commit = async (ops) => { for (const part of chunk(ops, 200)) { const b = db.batch(); part.forEach((op) => op(b)); await b.commit(); } };

  // ── rollback ──
  if (rollbackFile) {
    const saved = JSON.parse(fs.readFileSync(rollbackFile, "utf8"));
    const ops = saved.docs.map((d) => (b) => {
      const back = { deposit: revive(d.deposit), securityDeposit: d.hadSecurityDeposit ? revive(d.securityDeposit) : FieldValue.delete() };
      d.flatKeys.forEach((k) => { back[k] = FieldValue.delete(); });
      b.update(db.collection(d.collection).doc(d.id), back);
      if (d.createdEntryID) b.delete(db.collection(ENTRY_COLLECTION).doc(d.createdEntryID));
    });
    log(`ROLLBACK ${rollbackFile}: ${ops.length} payments${WRITE ? "" : " (dry run -- add --write)"}`);
    if (WRITE) await commit(ops);
    return { restored: WRITE ? ops.length : 0 };
  }

  log(`MIGRATE deposit to flat fields -- ${WRITE ? "WRITE" : "DRY RUN (nothing will be written)"}\n`);
  const ops = []; const backup = []; const kept = [];
  const stats = { scanned: 0, withNested: 0, migrated: 0, entriesCreated: 0, entriesAlreadyThere: 0, nestedOnlyRemoved: 0, kept: 0, byStatus: {} };

  for (const collection of COLLECTIONS) {
    const snap = await db.collection(collection).get();
    for (const doc of snap.docs) {
      stats.scanned += 1;
      const data = doc.data();
      if (!data.deposit || typeof data.deposit !== "object") continue;
      stats.withNested += 1;
      const plan = planDepositMigration(data, { id: doc.id, now });
      if (plan.keep) { stats.kept += 1; kept.push(`${collection}/${doc.id}: ${plan.keep} -- kept`); continue; }
      if (plan.skip) continue;

      let entry = plan.entry;
      if (entry) {
        const existing = await db.collection(ENTRY_COLLECTION).doc(plan.entryID).get();
        if (existing.exists) {
          if (num(existing.data().amount) !== entry.amount) { stats.kept += 1; kept.push(`${collection}/${doc.id}: ${plan.entryID} already exists with amount ${existing.data().amount}, expected ${entry.amount} -- kept`); continue; }
          entry = null; stats.entriesAlreadyThere += 1;   // same row is already there: only the payment is updated
        }
      }

      const patch = Object.fromEntries(Object.entries(plan.patch).map(([k, v]) => [k, v === "__DELETE__" ? FieldValue.delete() : v]));
      const nested = plan.flatKeys.length === 0;
      backup.push({
        collection, id: doc.id, deposit: toJSONSafe(data.deposit),
        hadSecurityDeposit: has(data.securityDeposit), securityDeposit: toJSONSafe(data.securityDeposit ?? null),
        flatKeys: [...plan.flatKeys], createdEntryID: entry ? plan.entryID : null,
      });
      // The row and the payment change in ONE batch: `deposit` can never be removed without the row existing.
      ops.push((b) => {
        if (entry) b.set(db.collection(ENTRY_COLLECTION).doc(plan.entryID), entry);
        b.update(doc.ref, patch);
      });
      if (nested) stats.nestedOnlyRemoved += 1; else stats.migrated += 1;
      if (entry) stats.entriesCreated += 1;
      const st = String(data.deposit.status || ""); stats.byStatus[st] = (stats.byStatus[st] || 0) + 1;
    }
  }

  log(`payments scanned ${stats.scanned}, with a nested deposit ${stats.withNested}`);
  log(`to migrate ${stats.migrated}  (nested object only removed: ${stats.nestedOnlyRemoved}), by status ${JSON.stringify(stats.byStatus)}`);
  log(`_depositreturn rows to create ${stats.entriesCreated}  (already there: ${stats.entriesAlreadyThere})`);
  if (kept.length) { log(`\nKept (${kept.length}) -- do not add up, left as they are:`); kept.forEach((s) => log(`  ${s}`)); }

  const report = { stats, kept, rows: ops.length };
  if (WRITE && ops.length) {
    fs.mkdirSync(dir, { recursive: true });
    const file = path.join(dir, `deposit-flat-${now.toISOString().replace(/[:.]/g, "-")}.json`);
    fs.writeFileSync(file, JSON.stringify({ at: now.toISOString(), docs: backup }, null, 1));   // BEFORE any write
    await commit(ops);
    report.file = file;
    log(`\nDone. ${ops.length} payments updated. Backup: ${file}`);
    log(`Undo with: node scripts/migrate-deposit-flat.js --rollback=${file} --write`);
  } else if (!WRITE) {
    log("\n(dry run -- add --write to apply)");
  }
  return report;
};

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  await import("dotenv/config");
  const { default: admin } = await import("firebase-admin");
  const { db } = await import("../config/firebaseConnection/firebase.js");
  try { await main({ db, FieldValue: admin.firestore.FieldValue, argv: process.argv.slice(2) }); process.exit(0); }
  catch (err) { console.error("Failed:", err); process.exit(1); }
}
