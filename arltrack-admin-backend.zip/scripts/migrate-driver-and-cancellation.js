// One-off migration: legacy booking fields -> driverAssignments + cancellationRequests
//
//   Drivers:        bookings.driverID / driverAssignedAt / driverAssignedBy
//                     -> one driverAssignments row per booking that has a driver
//   Cancellations:  bookings.cancellationRequestStatus / ...Reason / ...RequestedAt /
//                   cancellationRejectReason / statusBeforeCancellationRequest
//                   (and the oldest shape, bookings.status === "cancellation_request")
//                     -> one cancellationRequests row per request
//
//   Phase 1 (safe, additive):  create the new rows. Nothing on any booking is touched.
//   Phase 2 (destructive):     remove the legacy fields from bookings -- only for bookings
//                              whose new row exists, and only after the new code is deployed.
//
// Put this file in arltrack-admin-backend/scripts/ and run it from arltrack-admin-backend/.
// DRY RUN BY DEFAULT. Nothing is written unless you pass --write.
//
//   node scripts/migrate-driver-and-cancellation.js                      phase 1 dry run (report)
//   node scripts/migrate-driver-and-cancellation.js --write              phase 1 apply
//   node scripts/migrate-driver-and-cancellation.js --cleanup            phase 2 dry run (report)
//   node scripts/migrate-driver-and-cancellation.js --cleanup --write    phase 2 apply (take a Firestore export first!)
//
//   --only=drivers | --only=cancellations     run just one half
//   --report=report.json                       also write the full findings to a file
//
// Recommended order:
//   1. Deploy the NEW admin backend  (it reads both the new tables and the legacy fields).
//   2. Run phase 1 --write.
//   3. Deploy the NEW customer backend (it writes new cancellation requests to the table).
//   4. Check the app; then run phase 2 (dry run first, then --write).
//
// Safe to re-run: rows get deterministic IDs (driver: <bookingDocID>, cancellation: mig_cxl_<bookingDocID>)
// and anything that already has a row is skipped.
//
// Credentials: FIREBASE_SERVICE_ACCOUNT (same JSON string the backend uses),
// otherwise Application Default Credentials (GOOGLE_APPLICATION_CREDENTIALS).

import "dotenv/config"; // loads FIREBASE_SERVICE_ACCOUNT from .env, same as the other scripts/
import fs from "fs";
import admin from "firebase-admin";

const args = process.argv.slice(2);
const flag = (name) => args.includes(name);
const opt  = (name) => (args.find((a) => a.startsWith(`${name}=`)) || "").split("=")[1] || null;

const WRITE   = flag("--write");
const CLEANUP = flag("--cleanup");
const ONLY    = opt("--only"); // "drivers" | "cancellations" | null
const REPORT  = opt("--report");
const DO_DRIVERS = !ONLY || ONLY === "drivers";
const DO_CANCELS = !ONLY || ONLY === "cancellations";
if (ONLY && !["drivers", "cancellations"].includes(ONLY)) {
  console.error('--only must be "drivers" or "cancellations"');
  process.exit(1);
}

// -- Firebase init --------------------------------------------
if (process.env.FIREBASE_SERVICE_ACCOUNT) {
  const sa = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT.replace(/\r?\n/g, ""));
  sa.private_key = sa.private_key.replace(/\\n/g, "\n");
  admin.initializeApp({ credential: admin.credential.cert(sa) });
} else {
  admin.initializeApp({ credential: admin.credential.applicationDefault() });
}
const db = admin.firestore();
const { FieldValue, FieldPath } = admin.firestore;

const PAGE = 400; // under the 500-op batch limit
const FINISHED = new Set(["completed", "cancelled", "stolen"]);
const REQUEST_STATUSES = new Set(["pending", "approved", "rejected"]);
const LEGACY_DRIVER_FIELDS = ["driverID", "driverAssignedAt", "driverAssignedBy"];
const LEGACY_CANCEL_FIELDS = [
  "cancellationRequestStatus", "cancellationRequestReason", "cancellationRequestedAt",
  "cancellationRejectReason", "statusBeforeCancellationRequest",
];

// -- helpers --------------------------------------------------
const keyOf = (docID, data) => data.bookingID || docID;
const lower = (v) => String(v || "").toLowerCase();
const has   = (v) => v !== undefined && v !== null && v !== "";

async function* bookingPages() {
  let last = null;
  for (;;) {
    let q = db.collection("bookings").orderBy(FieldPath.documentId()).limit(PAGE);
    if (last) q = q.startAfter(last);
    const snap = await q.get();
    if (snap.empty) return;
    yield snap.docs;
    last = snap.docs[snap.docs.length - 1];
  }
}

// The two target collections start small (or empty), so they are read once
// into memory instead of querying per booking.
async function loadExisting() {
  const assignments = new Map(); // bookingKey -> [rows]
  const requests    = new Map(); // bookingKey -> [rows]
  const ids         = new Set(); // every existing doc id (for idempotency)
  const [aSnap, rSnap] = await Promise.all([
    db.collection("driverAssignments").get(),
    db.collection("cancellationRequests").get(),
  ]);
  aSnap.forEach((d) => { ids.add(`driverAssignments/${d.id}`); const k = d.data().bookingID; (assignments.get(k) || assignments.set(k, []).get(k)).push(d.data()); });
  rSnap.forEach((d) => { ids.add(`cancellationRequests/${d.id}`); const k = d.data().bookingID; (requests.get(k) || requests.set(k, []).get(k)).push(d.data()); });
  return { assignments, requests, ids };
}

async function flush(ops) {
  if (!ops.length) return;
  const batch = db.batch();
  for (const op of ops) {
    if (op.type === "create") batch.create(op.ref, op.data);
    else batch.update(op.ref, op.data);
  }
  await batch.commit();
}

const sample = (arr, n = 15) => arr.slice(0, n);

// -- Phase 1 --------------------------------------------------
async function phase1() {
  const existing = await loadExisting();
  const s = {
    scanned: 0,
    drivers: { withDriver: 0, toCreate: 0, alreadyDone: 0, asAssigned: 0, asCompleted: 0, nonChauffeur: [], missingUser: [] },
    cancellations: { withRequest: 0, toCreate: 0, alreadyDone: 0, byStatus: { pending: 0, approved: 0, rejected: 0 }, oldestShape: 0, mismatches: [], reasonUnknown: 0 },
  };
  const driverIDs = new Set();
  let ops = [];

  for await (const docs of bookingPages()) {
    for (const doc of docs) {
      s.scanned++;
      const b = doc.data();
      const key = keyOf(doc.id, b);

      // ---- drivers ----
      if (DO_DRIVERS && has(b.driverID)) {
        s.drivers.withDriver++;
        driverIDs.add(b.driverID);
        const rowID = doc.id; // plain booking doc ID (older runs used a "mig_drv_" prefix; see rename-mig-assignment-ids.js)
        const rowsForBooking = existing.assignments.get(key) || [];
        const done = existing.ids.has(`driverAssignments/${rowID}`) || rowsForBooking.some((r) => r.driverID === b.driverID);
        if (done) {
          s.drivers.alreadyDone++;
        } else {
          const finished = FINISHED.has(lower(b.status));
          if (b.modeOfDriving && b.modeOfDriving !== "With Chauffeur") {
            s.drivers.nonChauffeur.push({ booking: key, modeOfDriving: b.modeOfDriving, driverID: b.driverID });
          }
          s.drivers.toCreate++;
          finished ? s.drivers.asCompleted++ : s.drivers.asAssigned++;
          const data = {
            assignmentID: rowID,
            bookingID:    key,
            driverID:     b.driverID,
            status:       finished ? "completed" : "assigned",
            assignedAt:   b.driverAssignedAt || b.createdAt || null,
            assignedBy:   b.driverAssignedBy || "unknown",
            endedAt:      finished ? (b.updatedAt || null) : null, // approximate: the booking's last update
            endedBy:      null,
          };
          ops.push({ type: "create", ref: db.collection("driverAssignments").doc(rowID), data });
          existing.ids.add(`driverAssignments/${rowID}`);
          (existing.assignments.get(key) || existing.assignments.set(key, []).get(key)).push(data);
        }
      }

      // ---- cancellation requests ----
      if (DO_CANCELS) {
        const shapeA = REQUEST_STATUSES.has(lower(b.cancellationRequestStatus));
        const shapeB = lower(b.status) === "cancellation_request";
        if (shapeA || shapeB) {
          s.cancellations.withRequest++;
          if (shapeB && !shapeA) s.cancellations.oldestShape++;
          const status = shapeA ? lower(b.cancellationRequestStatus) : "pending";
          s.cancellations.byStatus[status]++;
          const rowID = `mig_cxl_${doc.id}`;
          const rowsForBooking = existing.requests.get(key) || [];
          const done = existing.ids.has(`cancellationRequests/${rowID}`) ||
            (status === "pending" && rowsForBooking.some((r) => r.status === "pending"));
          if (done) {
            s.cancellations.alreadyDone++;
          } else {
            // Things worth a human look before trusting the row.
            const bs = lower(b.status);
            if (status === "pending" && !["ongoing", "cancellation_request"].includes(bs)) {
              s.cancellations.mismatches.push({ booking: key, issue: `pending request but booking status is "${b.status}"` });
            }
            if (status === "approved" && bs !== "cancelled") {
              s.cancellations.mismatches.push({ booking: key, issue: `approved request but booking status is "${b.status}"` });
            }
            const reason = shapeA ? (b.cancellationRequestReason || "") : (b.cancellationReason || "");
            if (!reason) s.cancellations.reasonUnknown++;
            s.cancellations.toCreate++;
            const data = {
              cancellationRequestID: rowID,
              bookingID:    key,
              userID:       b.userID || null,
              reason,
              status,
              requestedAt:  (shapeA ? b.cancellationRequestedAt : null) || b.updatedAt || b.createdAt || null,
              processedBy:  null, // never recorded in the old shape
              processedAt:  status === "pending" ? null : (b.updatedAt || null), // approximate: the booking's last update
              rejectReason: status === "rejected" ? (b.cancellationRejectReason || "") : null,
            };
            ops.push({ type: "create", ref: db.collection("cancellationRequests").doc(rowID), data });
            existing.ids.add(`cancellationRequests/${rowID}`);
            (existing.requests.get(key) || existing.requests.set(key, []).get(key)).push(data);
          }
        }
      }

      if (WRITE && ops.length >= PAGE) { await flush(ops); ops = []; }
    }
  }
  if (WRITE) await flush(ops);

  // Report-only: do the drivers still exist as Driver users?
  if (DO_DRIVERS && driverIDs.size) {
    const ids = [...driverIDs];
    for (let i = 0; i < ids.length; i += 100) {
      const snaps = await db.getAll(...ids.slice(i, i + 100).map((id) => db.collection("user").doc(id)));
      snaps.forEach((x) => { if (!x.exists) s.drivers.missingUser.push(x.id); });
    }
  }
  return s;
}

// -- Phase 2 --------------------------------------------------
async function phase2() {
  const existing = await loadExisting();
  const s = {
    scanned: 0,
    drivers: { cleaned: 0, skippedNoRow: [] },
    cancellations: { cleaned: 0, statusRestored: 0, reasonCopied: 0, skippedNoRow: [] },
  };
  let ops = [];

  for await (const docs of bookingPages()) {
    for (const doc of docs) {
      s.scanned++;
      const b = doc.data();
      const key = keyOf(doc.id, b);
      const patch = {};

      if (DO_DRIVERS && LEGACY_DRIVER_FIELDS.some((f) => f in b)) {
        const rows = existing.assignments.get(key) || [];
        // Only remove the old fields when the table clearly has this booking's driver.
        if (!has(b.driverID) || rows.some((r) => r.driverID === b.driverID)) {
          for (const f of LEGACY_DRIVER_FIELDS) if (f in b) patch[f] = FieldValue.delete();
          s.drivers.cleaned++;
        } else {
          s.drivers.skippedNoRow.push({ booking: key, driverID: b.driverID });
        }
      }

      if (DO_CANCELS) {
        const shapeB = lower(b.status) === "cancellation_request";
        if (LEGACY_CANCEL_FIELDS.some((f) => f in b) || shapeB) {
          const rows = existing.requests.get(key) || [];
          if (rows.length) {
            for (const f of LEGACY_CANCEL_FIELDS) if (f in b) patch[f] = FieldValue.delete();
            if (shapeB) { // oldest shape: put the booking back to what it was
              patch.status = b.statusBeforeCancellationRequest || "ongoing";
              s.cancellations.statusRestored++;
            }
            const approved = rows.find((r) => r.status === "approved");
            if (approved?.reason && !has(b.cancellationReason) && lower(b.status) === "cancelled") {
              patch.cancellationReason = approved.reason; // one reason on every cancelled booking
              s.cancellations.reasonCopied++;
            }
            s.cancellations.cleaned++;
          } else {
            s.cancellations.skippedNoRow.push({ booking: key });
          }
        }
      }

      if (Object.keys(patch).length) ops.push({ type: "update", ref: doc.ref, data: patch });
      if (WRITE && ops.length >= PAGE) { await flush(ops); ops = []; }
    }
  }
  if (WRITE) await flush(ops);
  return s;
}

// -- main -----------------------------------------------------
(async () => {
  const label = CLEANUP ? "PHASE 2 (remove legacy fields)" : "PHASE 1 (create new rows)";
  console.log(`${label} -- ${WRITE ? "WRITE" : "DRY RUN (nothing will be written)"}${ONLY ? ` -- only ${ONLY}` : ""}\n`);

  const result = CLEANUP ? await phase2() : await phase1();

  const show = JSON.parse(JSON.stringify(result));
  const trim = (o) => { for (const k of Object.keys(o)) { if (Array.isArray(o[k])) { const n = o[k].length; o[k] = n ? { count: n, sample: sample(o[k]) } : 0; } else if (o[k] && typeof o[k] === "object") trim(o[k]); } };
  trim(show);
  console.log(JSON.stringify(show, null, 2));

  if (REPORT) {
    fs.writeFileSync(REPORT, JSON.stringify(result, null, 2));
    console.log(`\nFull findings written to ${REPORT}`);
  }
  if (!WRITE) console.log("\nDry run only. Re-run with --write to apply.");
  process.exit(0);
})().catch((err) => { console.error("Migration failed:", err); process.exit(1); });