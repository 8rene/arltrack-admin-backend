// One-off migration: bookings.cancellationReason -> cancellationRequests (type "direct")
//
//   Phase 1 (safe, additive):  for every cancelled booking (bookings AND bookingArchives)
//                              that has a cancellationReason, create a cancellationRequests
//                              row {type:"direct", status:"approved", reason, cancelledBy}.
//                              Nothing on any booking is touched.
//   Phase 2 (destructive):     remove cancellationReason from those bookings -- only where
//                              the row exists and holds the same reason.
//
// Put this file in arltrack-admin-backend/scripts/ and run it from arltrack-admin-backend/.
// DRY RUN BY DEFAULT. Nothing is written unless you pass --write.
//
//   node scripts/migrate-cancellation-reasons.js                  phase 1 dry run
//   node scripts/migrate-cancellation-reasons.js --write          phase 1 apply
//   node scripts/migrate-cancellation-reasons.js --cleanup        phase 2 dry run
//   node scripts/migrate-cancellation-reasons.js --cleanup --write  phase 2 apply (export Firestore first!)
//
//   node scripts/migrate-cancellation-reasons.js --actors         fill processedBy/processedAt on direct rows from
//   node scripts/migrate-cancellation-reasons.js --actors --write refundRequests (dry run / apply). Run after phase 1.
//
// Order: deploy the NEW admin + customer backends (they read the row, and fall back to
// the old field) -> phase 1 -> check the app -> phase 2.
// Safe to re-run: row IDs are deterministic (the booking key) and existing rows are skipped.

import "dotenv/config";
import admin from "firebase-admin";

const args = new Set(process.argv.slice(2));
const WRITE = args.has("--write");
const CLEANUP = args.has("--cleanup");
const ACTORS = args.has("--actors");

if (process.env.FIREBASE_SERVICE_ACCOUNT) {
  const sa = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT.replace(/\r?\n/g, ""));
  sa.private_key = sa.private_key.replace(/\\n/g, "\n");
  admin.initializeApp({ credential: admin.credential.cert(sa) });
} else {
  admin.initializeApp({ credential: admin.credential.applicationDefault() });
}
const db = admin.firestore();
const { FieldValue } = admin.firestore;

const COLLECTIONS = ["bookings", "bookingArchives"];
const has = (v) => v !== undefined && v !== null && v !== "";

const inferCancelledBy = (reason) => {
  const r = String(reason || "");
  if (r.startsWith("Cancelled by staff:")) return "staff";
  if (r.startsWith("Cancelled by admin:")) return "admin";
  if (r.startsWith("Auto-cancelled")) return "system";
  if (r.startsWith("Cancelled: refund")) return "refund";
  if (r === "Cancelled by user.") return "customer";
  return "unknown";
};

// Who processed a cancellation: the refund request for the same booking (status Approved/Refunded)
// holds processedBy/processedAt. Rejected refunds are NOT copied: a rejected refund means the
// booking was not cancelled by it, and a direct row never carries a rejectReason.
async function backfillActors() {
  const refunds = new Map(); // bookingID -> processed refund request
  (await db.collection("refundRequests").get()).forEach((d) => {
    const r = d.data();
    if (!["approved", "refunded"].includes(String(r.status || "").toLowerCase()) || !r.processedBy) return;
    const prev = refunds.get(r.bookingID);
    if (!prev || (r.processedAt?.toMillis?.() || 0) > (prev.processedAt?.toMillis?.() || 0)) refunds.set(r.bookingID, r);
  });
  const rows = await db.collection("cancellationRequests").where("type", "==", "direct").get();
  const s = { directRows: rows.size, alreadyHadActor: 0, filled: 0, noRefundRequest: 0, byCancelledBy: {} };
  let batch = db.batch(); let n = 0;
  for (const d of rows.docs) {
    const row = d.data();
    if (row.processedBy) { s.alreadyHadActor++; continue; }
    const refund = refunds.get(row.bookingID);
    if (!refund) { s.noRefundRequest++; s.byCancelledBy[row.cancelledBy] = (s.byCancelledBy[row.cancelledBy] || 0) + 1; continue; }
    s.filled++;
    if (WRITE) {
      batch.update(d.ref, { processedBy: refund.processedBy, ...(refund.processedAt ? { processedAt: refund.processedAt } : {}) });
      if (++n >= 400) { await batch.commit(); batch = db.batch(); n = 0; }
    }
  }
  if (WRITE && n) await batch.commit();
  return s;
}

(async () => {
  if (ACTORS) {
    console.log(`ACTORS (fill processedBy from refundRequests) -- ${WRITE ? "WRITE" : "DRY RUN (nothing will be written)"}\n`);
    console.log(JSON.stringify(await backfillActors(), null, 2));
    if (!WRITE) console.log("\nDry run only. Re-run with --write to apply.");
    process.exit(0);
  }
  console.log(`${CLEANUP ? "PHASE 2 (remove cancellationReason)" : "PHASE 1 (create direct rows)"} -- ${WRITE ? "WRITE" : "DRY RUN (nothing will be written)"}\n`);

  const rowsSnap = await db.collection("cancellationRequests").get();
  const rows = new Map(); // docID -> data
  rowsSnap.forEach((d) => rows.set(d.id, d.data()));

  const summary = { scanned: 0, withReason: 0, toCreate: 0, alreadyDone: 0, notCancelled: [], cleaned: 0, skippedNoRow: [], byCancelledBy: {} };
  let batch = db.batch();
  let n = 0;
  const commitIfFull = async (force = false) => {
    if (WRITE && n > 0 && (force || n >= 400)) { await batch.commit(); batch = db.batch(); n = 0; }
  };

  const seenKeys = new Set(); // bookings and bookingArchives can hold the same booking; one row per booking
  for (const col of COLLECTIONS) {
    const snap = await db.collection(col).get();
    for (const doc of snap.docs) {
      summary.scanned++;
      const b = doc.data();
      if (!has(b.cancellationReason)) continue;
      summary.withReason++;
      const key = b.bookingID || doc.id;
      const rowID = String(key); // the row ID is just the booking ID
      const row = rows.get(rowID);

      if (!CLEANUP) {
        if (String(b.status || "").toLowerCase() !== "cancelled") {
          summary.notCancelled.push({ col, booking: key, status: b.status }); // has a reason but isn't cancelled: skip, look at it by hand
          continue;
        }
        if (row || seenKeys.has(key)) { summary.alreadyDone++; continue; }
        seenKeys.add(key);
        const cancelledBy = inferCancelledBy(b.cancellationReason);
        summary.byCancelledBy[cancelledBy] = (summary.byCancelledBy[cancelledBy] || 0) + 1;
        summary.toCreate++;
        if (WRITE) {
          batch.create(db.collection("cancellationRequests").doc(rowID), {
            cancellationRequestID: rowID,
            type: "direct",
            bookingID: key,
            userID: b.userID || null,
            reason: b.cancellationReason,
            status: "approved",
            cancelledBy,
            requestedAt: b.updatedAt || b.createdAt || null,
            processedBy: null,
            processedAt: b.updatedAt || b.createdAt || null, // approximate: the booking's last update
            rejectReason: null,
            migratedFrom: `${col}.cancellationReason`,
          });
          n++; await commitIfFull();
        }
      } else {
        // Remove the field only when the row exists and holds the same text.
        const approved = [...rows.values()].find((r) => r.bookingID === key && r.status === "approved" && r.reason === b.cancellationReason);
        if (row?.reason === b.cancellationReason || approved) {
          summary.cleaned++;
          if (WRITE) { batch.update(doc.ref, { cancellationReason: FieldValue.delete() }); n++; await commitIfFull(); }
        } else {
          summary.skippedNoRow.push({ col, booking: key });
        }
      }
    }
  }
  await commitIfFull(true);

  const show = JSON.parse(JSON.stringify(summary));
  for (const k of ["notCancelled", "skippedNoRow"]) show[k] = show[k].length ? { count: show[k].length, sample: show[k].slice(0, 15) } : 0;
  console.log(JSON.stringify(show, null, 2));
  if (!WRITE) console.log("\nDry run only. Re-run with --write to apply.");
  process.exit(0);
})().catch((err) => { console.error("Migration failed:", err); process.exit(1); });