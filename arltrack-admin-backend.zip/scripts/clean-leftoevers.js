// Removes leftover columns that are PROVEN to live somewhere else. Run from arltrack-admin-backend/
//
//   node scripts/clean-leftovers.js                                  dry run: report + what would be removed
//   node scripts/clean-leftovers.js --write                          applies the default rules
//   node scripts/clean-leftovers.js --customer-verified              dry run incl. the held rules
//   node scripts/clean-leftovers.js --customer-verified --write      applies default + held rules
//   node scripts/clean-leftovers.js --rollback=<backup.json> --write undoes one run
//
// Run it AFTER scripts/migrate-deposit-flat.js and scripts/cleanup-to-models.js. It never touches what those
// scripts handle (paymentEntries / transactionLogs columns, payments.proofUrl / payNow / referenceNumber / driverFee).
//
// DEFAULT rules (admin-side only):
//   bookings.rentalFee, serviceFee, extraFee, gatewayFee, depositFee, driverFee, totalFee
//        removed only when the booking's payment doc holds the same value
//   payments.paymongoTransactions
//        removed only when the payment already has paymentEntries rows (hydration rebuilds the array from them)
//   bookings.deviceCheckedAt / deviceCheckedBy / deviceCheckNote
//        removed (the device-check step is gone; nothing reads or writes them)
//   refundRequests.contextLabel
//        removed (it was only text for audit / notification lines and always comes from the call now)
//   refundRequests.approvalLockedAt
//        removed when it is null or the 2-minute lock has expired (a live lock is never touched)
//   refundRequests.outcome "deposit_forfeited"
//        set to "nothing_owed" (only when returnDeposit is false, which is how the kept deposit is told apart now)
//   payments.refundedAt -> refundRequests.refundedAt
//        copied onto that payment's Refunded refund request(s) that have none (default rule, additive).
//        The payment's own refundedAt is removed with the HELD rules, once a refund request carries the value.
// REPORT ONLY: refundRequests with outcome "no_payment" (no longer written; a missing refund doc plus a missing
//   payment now means the same). They are listed in the audit, not deleted.
// HELD rules (the customer backend may read these -- grep it first, then pass --customer-verified):
//   refundRequests.parts, manualRefund          removed only when the refund already has paymentEntries rows
//   refundRequests.paymongoRefundID             removed only when it also sits in paymongoRefundIDs AND entries exist
//   payments.paymongoPaymentID, depositPaymongoPaymentID, balancePaymongoPaymentID
//                                               removed only when an entry holds that id as its referenceNumber
//   payments.depositPaymongoFee, balancePaymongoFee, paymongoFeeTotal
//                                               removed only when the entries' transactionFee gives the same number
//   payments.paymongoChannel                    removed only when the payment has an online entry (entry.method)
//   payments.paymongoSessionID                  removed only when the latest deposit / balance entry holds exactly this id as its
//                                               sessionID (hydratePayment derives it back from that row). Pass --customer-verified
//                                               ONLY after the customer webhook finds the payment through paymentEntries.sessionID
//                                               and the customer checkout writes sessionID onto the entry.
//   (the same rules also run on paymentsArchives: an archive keeps its paymentID, and the entries stay in paymentEntries)
//   penalties.confirmedBy / confirmedAt         removed only when equal to createdBy / createdAt
//   penalties.referenceNumber / paymentMethod   removed only when empty
//   refundRequests.onlineAmount, manualAmount   removed only when the refund's "out" rows already give the same sum
//                                               (hydrateRefundRequest derives them). A Pending request has no rows: kept.
//   refundRequests.forfeitWaivedAmount / Reason removed only when forfeitWaived is not true (nothing was waived, so no
//                                               reason is lost). A waived one is kept: its reason is only in the audit log
//                                               for approvals made after this change.
//   refundRequests.customerNotified             removed (the admin no longer reads or writes it)
//   refundRequests.requestedAt                  removed only when equal to createdAt
//   driverAssignments.endedAt / endedBy         removed (one row per booking, nothing reads them). endedAt is the only
//                                               stored completion time of a finished assignment -- the dry run counts them.
//
// NEVER touched, because the admin code still writes or reads them:
//   notesAdmin, rejectReason, approvalLockedAt (while the lock is live), overrideReason,
//   lateMinutes, graceMinutes, rateAtCreation, balanceCollected*, balanceMethod,
//   startedAtSource, anything in archives.
//
// AUDIT (report only, nothing is changed): places where data is NOT merged yet.
//
// Every write run saves scripts/backups/leftovers-<time>.json BEFORE writing; --rollback restores from it.
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

const EMPTY = new Set(["", "—", "-", "n/a", "na", "none", "null"]);
const isEmpty = (v) => v === undefined || v === null || (typeof v === "string" && EMPTY.has(v.trim().toLowerCase()));
const has = (d, k) => Object.prototype.hasOwnProperty.call(d, k);
const num = (v) => (v === undefined || v === null || v === "" ? 0 : Number(v));
const ms = (v) => (v && typeof v.toMillis === "function" ? v.toMillis() : v instanceof Date ? v.getTime() : v);
const same = (a, b) => (a === b) || (ms(a) !== undefined && ms(a) !== null && ms(a) === ms(b));
const chunk = (arr, n) => { const out = []; for (let i = 0; i < arr.length; i += n) out.push(arr.slice(i, i + n)); return out; };
const push = (map, k, v) => { if (k === undefined || k === null || k === "") return; if (!map.has(k)) map.set(k, []); map.get(k).push(v); };

const toJSONSafe = (v) => JSON.parse(JSON.stringify(v, function (k, x) {
  const raw = this[k];
  if (raw instanceof Date) return { __ts: raw.getTime() };
  return raw && typeof raw.toMillis === "function" ? { __ts: raw.toMillis() } : x;
}));
const revive = (v) => JSON.parse(JSON.stringify(v), (k, x) => (x && typeof x === "object" && "__ts" in x ? new Date(x.__ts) : x));

const BOOKING_FEES = ["rentalFee", "serviceFee", "extraFee", "gatewayFee", "depositFee", "driverFee", "totalFee"];
const refundIdOf = (e) => e.refundReqID || (e.refCollection === "refundRequests" ? e.refID : null);   // works before AND after the migrate script

export const main = async ({ db, FieldValue, argv = [], log = console.log, now = new Date(), outDir } = {}) => {
  const arg = (k) => (argv.find((a) => a.startsWith(`--${k}=`)) || "").slice(k.length + 3);
  const WRITE = argv.includes("--write");
  const CUSTOMER_OK = argv.includes("--customer-verified");
  const rollbackFile = arg("rollback");
  const dir = outDir || path.join(path.dirname(fileURLToPath(import.meta.url)), "backups");
  const commit = async (ops) => { for (const part of chunk(ops, 400)) { const b = db.batch(); part.forEach((op) => op(b)); await b.commit(); } };

  // ── rollback ──
  if (rollbackFile) {
    const saved = JSON.parse(fs.readFileSync(rollbackFile, "utf8"));
    log(`ROLLBACK of ${path.basename(rollbackFile)} (${saved.docs.length} rows) -- ${WRITE ? "WRITE" : "DRY RUN"}`);
    if (WRITE) {
      await commit(saved.docs.map((x) => (b) => {
        const patch = revive(x.removed);
        (x.added || []).forEach((k) => { patch[k] = FieldValue.delete(); });   // fields a rule added: take them off again
        b.update(db.collection(x.collection).doc(x.id), patch);
      }));
    }
    return { rolledBack: saved.docs.length };
  }

  const load = async (name) => (await db.collection(name).get()).docs.map((d) => ({ id: d.id, ref: d.ref, d: d.data() }));
  const [bookings, payments, entries, refunds, penalties, assignments, cancellations, payArchives] = await Promise.all(
    ["bookings", "payments", "paymentEntries", "refundRequests", "penalties", "driverAssignments", "cancellationRequests", "paymentsArchives"].map(load));

  const entriesByPayment = new Map(); const entriesByRefund = new Map();
  entries.forEach((e) => { push(entriesByPayment, e.d.paymentID, e); push(entriesByRefund, refundIdOf(e.d), e); });
  const paymentByBooking = new Map(); payments.forEach((p) => push(paymentByBooking, p.d.bookingID, p));

  const stats = {}; const kept = []; const backup = []; const ops = [];
  const plan = (col, row, fields, why) => {
    if (!fields.length) return;
    const removed = {}; fields.forEach((k) => { removed[k] = row.d[k]; });
    const s = (stats[col] = stats[col] || { rows: 0, fields: {} });
    s.rows += 1; fields.forEach((k) => { s.fields[k] = (s.fields[k] || 0) + 1; });
    backup.push({ collection: col, id: row.id, removed: toJSONSafe(removed), why });
    const patch = {}; fields.forEach((k) => { patch[k] = FieldValue.delete(); });
    ops.push((b) => b.update(row.ref, patch));
  };
  // Sets fields on a row. `old` = the values being replaced (put back by a rollback); `added` = fields that did not exist before
  // (a rollback deletes them again).
  const change = (col, row, patch, why) => {
    const old = {}; const added = [];
    for (const k of Object.keys(patch)) { if (has(row.d, k)) old[k] = row.d[k]; else added.push(k); }
    const s = (stats[col] = stats[col] || { rows: 0, fields: {} });
    s.rows += 1; Object.keys(patch).forEach((k) => { s.fields[`${k}(set)`] = (s.fields[`${k}(set)`] || 0) + 1; });
    backup.push({ collection: col, id: row.id, removed: toJSONSafe(old), added, why });
    ops.push((b) => b.update(row.ref, patch));
  };
  const keep = (col, id, field, reason) => kept.push(`${col}/${id}: ${field} kept -- ${reason}`);

  // ── default rules ──
  for (const b of bookings) {
    const fields = BOOKING_FEES.filter((k) => has(b.d, k));
    if (!fields.length) continue;
    const pay = (paymentByBooking.get(b.id) || [])[0];
    if (!pay) { fields.forEach((k) => keep("bookings", b.id, k, "no payment doc for this booking")); continue; }
    const ok = [];
    for (const k of fields) {
      const other = k === "driverFee" ? (pay.d.driversFee ?? pay.d.driverFee) : pay.d[k];
      if (num(b.d[k]) === num(other)) ok.push(k); else keep("bookings", b.id, k, `payment ${pay.id} holds ${JSON.stringify(other)} instead of ${JSON.stringify(b.d[k])}`);
    }
    plan("bookings", b, ok, "fee value is on the payment doc");
  }
  for (const p of payments) {
    if (!has(p.d, "paymongoTransactions")) continue;
    if ((entriesByPayment.get(p.id) || []).length) plan("payments", p, ["paymongoTransactions"], "paymentEntries rows exist");
    else keep("payments", p.id, "paymongoTransactions", "no paymentEntries rows for this payment");
  }

  // ── model-alignment rules (device check, contextLabel, lock, outcome, refundedAt) ──
  for (const b of bookings) plan("bookings", b, ["deviceCheckedAt", "deviceCheckedBy", "deviceCheckNote"].filter((k) => has(b.d, k)), "device check was removed");
  const LOCK_MS = 2 * 60 * 1000;
  for (const r of refunds) {
    const fields = [];
    if (has(r.d, "contextLabel")) fields.push("contextLabel");
    if (has(r.d, "approvalLockedAt")) {
      const t = ms(r.d.approvalLockedAt);
      if (isEmpty(r.d.approvalLockedAt) || (typeof t === "number" && now.getTime() - t > LOCK_MS)) fields.push("approvalLockedAt");
      else keep("refundRequests", r.id, "approvalLockedAt", "the lock is still live");
    }
    plan("refundRequests", r, fields, "no longer stored / lock released");
    if (r.d.outcome === "deposit_forfeited") {
      if (r.d.returnDeposit === false) change("refundRequests", r, { outcome: "nothing_owed" }, "deposit kept = nothing_owed + returnDeposit false");
      else keep("refundRequests", r.id, "outcome", "deposit_forfeited but returnDeposit is not false -- decide by hand");
    }
  }
  // payments.refundedAt now lives on the refund request
  const refundsByPayment = new Map(); refunds.forEach((r) => { push(refundsByPayment, r.d.paymentID, r); });
  for (const p of payments) {
    if (!has(p.d, "refundedAt") || isEmpty(p.d.refundedAt)) continue;
    const targets = (refundsByPayment.get(p.d.paymentID || p.id) || []).filter((r) => r.d.status === "Refunded");
    if (!targets.length) { keep("payments", p.id, "refundedAt", "no Refunded refund request for this payment to carry it"); continue; }
    for (const r of targets) if (isEmpty(r.d.refundedAt)) { change("refundRequests", r, { refundedAt: p.d.refundedAt }, "moved from payments.refundedAt"); r.d.refundedAt = p.d.refundedAt; }
  }

  // ── held rules ──
  const held = [];
  const paymentLike = [["payments", payments], ["paymentsArchives", payArchives]];
  for (const [pCol, list] of paymentLike) for (const p of list) {
    const rows = (entriesByPayment.get(pCol === "payments" ? p.id : (p.d.paymentID || p.d.originalId)) || []).filter((e) => e.d.direction !== "out" && e.d.phase !== "penalty");
    const online = rows.filter((e) => e.d.source === "online");
    const fee = (phase) => online.filter((e) => e.d.phase === phase && e.d.status === "success").reduce((a, e) => a + num(e.d.transactionFee), 0);
    const total = online.filter((e) => e.d.status === "success").reduce((a, e) => a + num(e.d.transactionFee), 0);
    const fields = [];
    const test = (k, ok, why) => { if (!has(p.d, k) || isEmpty(p.d[k])) { if (has(p.d, k)) fields.push(k); return; } if (ok) fields.push(k); else keep(pCol, p.id, k, why); };
    for (const k of ["paymongoPaymentID", "depositPaymongoPaymentID", "balancePaymongoPaymentID"])
      test(k, rows.some((e) => e.d.referenceNumber === p.d[k]), "no entry has this id as its referenceNumber");
    test("depositPaymongoFee", Math.abs(fee("deposit") - num(p.d.depositPaymongoFee)) < 0.01, `entries say ${fee("deposit")}, payment says ${p.d.depositPaymongoFee}`);
    test("balancePaymongoFee", Math.abs(fee("balance") - num(p.d.balancePaymongoFee)) < 0.01, `entries say ${fee("balance")}, payment says ${p.d.balancePaymongoFee}`);
    test("paymongoFeeTotal", Math.abs(total - num(p.d.paymongoFeeTotal)) < 0.01, `entries sum to ${total.toFixed(2)}, payment says ${p.d.paymongoFeeTotal}`);
    test("paymongoChannel", online.length > 0, "no online entry for this payment");
    // Same pick as hydratePayment(): the latest deposit / balance row that has a sessionID.
    const latestSession = rows.filter((e) => !isEmpty(e.d.sessionID))
      .sort((a, b) => (Number(ms(b.d.settledAt || b.d.createdAt)) || 0) - (Number(ms(a.d.settledAt || a.d.createdAt)) || 0))[0];
    test("paymongoSessionID", !!latestSession && latestSession.d.sessionID === p.d.paymongoSessionID,
      "no deposit / balance entry holds this session id as its latest sessionID");
    if (pCol === "payments" && has(p.d, "refundedAt") && !isEmpty(p.d.refundedAt)
        && (refundsByPayment.get(p.d.paymentID || p.id) || []).some((r) => r.d.status === "Refunded" && !isEmpty(r.d.refundedAt))) fields.push("refundedAt");
    held.push([pCol, p, fields, "value lives in paymentEntries / on the refund request"]);
  }
  for (const r of refunds) {
    const rows = entriesByRefund.get(r.id) || [];
    const fields = [];
    for (const k of ["parts", "manualRefund"]) if (has(r.d, k)) { if (rows.length) fields.push(k); else keep("refundRequests", r.id, k, "no paymentEntries rows for this refund"); }
    if (has(r.d, "paymongoRefundID")) {
      if (rows.length && Array.isArray(r.d.paymongoRefundIDs) && r.d.paymongoRefundIDs.includes(r.d.paymongoRefundID)) fields.push("paymongoRefundID");
      else keep("refundRequests", r.id, "paymongoRefundID", "not in paymongoRefundIDs, or no entries");
    }
    // Fields the admin no longer stores (see hydrateRefundRequest): proven derivable before they are removed.
    const outRows = rows.filter((e) => e.d.direction === "out");
    const sumOf = (list) => list.reduce((a, e) => a + num(e.d.amount), 0);
    if (has(r.d, "onlineAmount")) {
      const derived = sumOf(outRows.filter((e) => e.d.source === "online" && e.d.status !== "unrefundable" && e.d.status !== "failed"));
      if (outRows.length && Math.abs(derived - num(r.d.onlineAmount)) < 0.01) fields.push("onlineAmount");
      else keep("refundRequests", r.id, "onlineAmount", outRows.length ? `rows sum to ${derived}, request says ${r.d.onlineAmount}` : "no paymentEntries rows for this refund");
    }
    if (has(r.d, "manualAmount")) {
      const derived = sumOf(outRows.filter((e) => e.d.source === "in_person"));
      if (outRows.length && Math.abs(derived - num(r.d.manualAmount)) < 0.01) fields.push("manualAmount");
      else keep("refundRequests", r.id, "manualAmount", outRows.length ? `rows sum to ${derived}, request says ${r.d.manualAmount}` : "no paymentEntries rows for this refund");
    }
    for (const k of ["forfeitWaivedAmount", "forfeitWaivedReason"]) if (has(r.d, k)) {
      if (r.d.forfeitWaived !== true) fields.push(k); else keep("refundRequests", r.id, k, "the forfeit WAS waived: the reason would be lost");
    }
    if (has(r.d, "customerNotified")) fields.push("customerNotified");
    if (has(r.d, "requestedAt")) {
      if (same(r.d.requestedAt, r.d.createdAt)) fields.push("requestedAt"); else keep("refundRequests", r.id, "requestedAt", "differs from createdAt");
    }
    held.push(["refundRequests", r, fields, "value lives in paymentEntries / is derived"]);
  }
  for (const a of assignments) {
    const fields = ["endedAt", "endedBy"].filter((k) => has(a.d, k));
    held.push(["driverAssignments", a, fields, "one row per booking; nothing reads the ended-at / ended-by fields"]);
  }
  for (const p of penalties) {
    const fields = [];
    if (has(p.d, "confirmedBy") && same(p.d.confirmedBy, p.d.createdBy)) fields.push("confirmedBy");
    if (has(p.d, "confirmedAt") && same(p.d.confirmedAt, p.d.createdAt)) fields.push("confirmedAt");
    if (has(p.d, "referenceNumber") && isEmpty(p.d.referenceNumber)) fields.push("referenceNumber");
    if (has(p.d, "paymentMethod") && isEmpty(p.d.paymentMethod)) fields.push("paymentMethod");
    held.push(["penalties", p, fields, "duplicate or empty"]);
  }
  const heldCounts = {};
  for (const [col, row, fields, why] of held) {
    if (!fields.length) continue;
    heldCounts[col] = (heldCounts[col] || 0) + 1;
    if (CUSTOMER_OK) plan(col, row, fields, why);
  }

  // ── audit (report only) ──
  const audit = [];
  const phaseIn = (pid, phase) => (entriesByPayment.get(pid) || []).filter((e) => e.d.direction === "in" && e.d.phase === phase);
  for (const p of payments) {
    const rows = entriesByPayment.get(p.id) || [];
    if (!rows.length) { audit.push(`payments/${p.id}: no paymentEntries rows (status ${p.d.status})`); continue; }
    if ((p.d.balanceCollected || p.d.balanceCollectedAmount || p.d.balanceMethod) && !phaseIn(p.id, "balance").length)
      audit.push(`payments/${p.id}: balance recorded only on the payment doc (no balance entry)`);
    if (p.d.paymongoFeeTotal != null) {
      const sum = rows.reduce((a, e) => a + (e.d.direction === "in" ? num(e.d.transactionFee) : 0), 0);
      if (Math.abs(sum - num(p.d.paymongoFeeTotal)) > 0.01) audit.push(`payments/${p.id}: paymongoFeeTotal ${p.d.paymongoFeeTotal} vs entry fees ${sum.toFixed(2)}`);
    }
    for (const k of ["paymongoPaymentID", "depositPaymongoPaymentID", "balancePaymongoPaymentID"]) {
      if (p.d[k] && !rows.some((e) => e.d.referenceNumber === p.d[k])) audit.push(`payments/${p.id}: ${k} ${p.d[k]} appears on no entry`);
    }
    if (!isEmpty(p.d.paymongoSessionID) && !rows.some((e) => e.d.phase !== "penalty" && e.d.sessionID === p.d.paymongoSessionID))
      audit.push(`payments/${p.id}: paymongoSessionID ${p.d.paymongoSessionID} appears on no deposit / balance entry`);
  }
  for (const r of refunds) if (r.d.outcome === "no_payment") audit.push(`refundRequests/${r.id}: outcome "no_payment" (no longer written; left alone -- the booking's cancellation row already marks it resolved)`);
  const assigned = new Set(assignments.map((a) => a.d.bookingID)); const cancelled = new Set(cancellations.map((c) => c.d.bookingID));
  for (const b of bookings) {
    if (b.d.driverID && !assigned.has(b.id)) audit.push(`bookings/${b.id}: driverID set but no driverAssignments row`);
    if (b.d.cancellationReason && !cancelled.has(b.id)) audit.push(`bookings/${b.id}: cancellationReason set but no cancellationRequests row`);
    for (const k of ["paymentMethod", "paymongoIntentId", "paidAt", "paymentStatus"]) if (has(b.d, k)) audit.push(`bookings/${b.id}: ${k} still on the booking (left alone)`);
  }

  // ── report ──
  log(`CLEAN LEFTOVERS -- ${WRITE ? "WRITE" : "DRY RUN (nothing will be written)"}${CUSTOMER_OK ? " -- held rules ON" : ""}\n`);
  log(`Would remove${WRITE ? " (removing)" : ""}:`);
  const names = Object.keys(stats);
  if (!names.length) log("  nothing");
  names.forEach((c) => log(`  ${c.padEnd(16)} ${String(stats[c].rows).padStart(4)} rows   ${JSON.stringify(stats[c].fields)}`));
  if (!CUSTOMER_OK && Object.keys(heldCounts).length) {
    log(`\nHeld (customer backend may read these; add --customer-verified after checking):`);
    Object.entries(heldCounts).forEach(([c, n]) => log(`  ${c.padEnd(16)} ${String(n).padStart(4)} rows`));
    log("  check with, in the customer repo:");
    log("    grep -rnE \"\\.(parts|manualRefund|paymongoRefundID)\\b\" controllers services utils");
    log("    grep -rnE \"confirmedBy|confirmedAt\" controllers services utils");
    log("    grep -rnE \"paymongoSessionID\" controllers services utils   (the webhook must look the payment up by paymentEntries.sessionID)");
  }
  if (kept.length) { log(`\nKept (${kept.length}) -- value not proven elsewhere:`); kept.slice(0, 40).forEach((s) => log(`  ${s}`)); if (kept.length > 40) log(`  ... and ${kept.length - 40} more`); }
  log(`\nAUDIT -- not merged, nothing changed (${audit.length}):`);
  if (!audit.length) log("  all clear");
  audit.slice(0, 60).forEach((s) => log(`  ${s}`)); if (audit.length > 60) log(`  ... and ${audit.length - 60} more`);

  const report = { stats, kept, audit, rows: ops.length };
  if (WRITE && ops.length) {
    fs.mkdirSync(dir, { recursive: true });
    const file = path.join(dir, `leftovers-${now.toISOString().replace(/[:.]/g, "-")}.json`);
    fs.writeFileSync(file, JSON.stringify({ at: now.toISOString(), docs: backup }, null, 1));   // BEFORE any write
    await commit(ops);
    report.file = file;
    log(`\nDone. ${ops.length} rows updated. Backup: ${file}`);
    log(`Undo with: node scripts/clean-leftovers.js --rollback=${file} --write`);
  } else if (!WRITE) {
    log("\n(dry run -- add --write to apply)");
  }
  return report;
};

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  await import("dotenv/config");
  const { default: admin } = await import("firebase-admin");
  const { db } = await import("../config/firebaseConnection/firebase.js");
  try { await main({ db, FieldValue: admin.firestore.FieldValue, argv: process.argv.slice(2) }); process.exit(0); }
  catch (err) { console.error("Failed:", err); process.exit(1); }
}