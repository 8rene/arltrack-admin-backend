// Removes leftover columns that are PROVEN to live somewhere else. Run from arltrack-admin-backend/
//
//   node scripts/clean-leftovers.js                                  dry run: report + what would be removed
//   node scripts/clean-leftovers.js --write                          applies the default rules
//   node scripts/clean-leftovers.js --customer-verified              dry run incl. the held rules
//   node scripts/clean-leftovers.js --customer-verified --write      applies default + held rules
//   node scripts/clean-leftovers.js --rollback=<backup.json> --write undoes one run
//
// Run it AFTER scripts/migrate-entry-columns.js (both phases). It never touches what that script handles
// (paymentEntries / transactionLogs columns, payments.proofUrl / payNow / referenceNumber / driverFee).
//
// DEFAULT rules (admin-side only):
//   bookings.rentalFee, serviceFee, extraFee, gatewayFee, depositFee, driverFee, totalFee
//        removed only when the booking's payment doc holds the same value
//   payments.paymongoTransactions
//        removed only when the payment already has paymentEntries rows (hydration rebuilds the array from them)
// HELD rules (the customer backend may read these -- grep it first, then pass --customer-verified):
//   refundRequests.parts, manualRefund          removed only when the refund already has paymentEntries rows
//   refundRequests.paymongoRefundID             removed only when it also sits in paymongoRefundIDs AND entries exist
//   payments.paymongoPaymentID, depositPaymongoPaymentID, balancePaymongoPaymentID
//                                               removed only when an entry holds that id as its referenceNumber
//   payments.depositPaymongoFee, balancePaymongoFee, paymongoFeeTotal
//                                               removed only when the entries' transactionFee gives the same number
//   payments.paymongoChannel                    removed only when the payment has an online entry (entry.method)
//   (the same rules also run on paymentsArchives: an archive keeps its paymentID, and the entries stay in paymentEntries)
//   penalties.confirmedBy / confirmedAt         removed only when equal to createdBy / createdAt
//   penalties.referenceNumber / paymentMethod   removed only when empty
//
// NEVER touched, because the admin code still writes or reads them:
//   notesAdmin, endedBy, rejectReason, approvalLockedAt (a live lock), forfeitWaivedReason, overrideReason,
//   lateMinutes, graceMinutes, rateAtCreation, onlineAmount, manualAmount, balanceCollected*, balanceMethod,
//   startedAtSource, anything in archives.
//
// AUDIT (report only, nothing is changed): places where data is NOT merged yet.
//
// Every write run saves scripts/backups/leftovers-<time>.json BEFORE writing; --rollback restores from it.
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

const EMPTY = new Set(["", "—", "-", "n/a", "na", "none", "null"]);
const isEmpty = (v) => v === undefined || v === null || (typeof v === "string" && EMPTY.has(v.trim().toLowerCase()));
const has = (d, k) => Object.prototype.hasOwnProperty.call(d, k);
const num = (v) => (v === undefined || v === null || v === "" ? 0 : Number(v));
const ms = (v) => (v && typeof v.toMillis === "function" ? v.toMillis() : v instanceof Date ? v.getTime() : v);
const same = (a, b) => (a === b) || (ms(a) !== undefined && ms(a) !== null && ms(a) === ms(b));
const chunk = (arr, n) => { const out = []; for (let i = 0; i < arr.length; i += n) out.push(arr.slice(i, i + n)); return out; };
const push = (map, k, v) => { if (k === undefined || k === null || k === "") return; if (!map.has(k)) map.set(k, []); map.get(k).push(v); };

const toJSONSafe = (v) => JSON.parse(JSON.stringify(v, function (k, x) {
  const raw = this[k];
  if (raw instanceof Date) return { __ts: raw.getTime() };
  return raw && typeof raw.toMillis === "function" ? { __ts: raw.toMillis() } : x;
}));
const revive = (v) => JSON.parse(JSON.stringify(v), (k, x) => (x && typeof x === "object" && "__ts" in x ? new Date(x.__ts) : x));

const BOOKING_FEES = ["rentalFee", "serviceFee", "extraFee", "gatewayFee", "depositFee", "driverFee", "totalFee"];
const refundIdOf = (e) => e.refundReqID || (e.refCollection === "refundRequests" ? e.refID : null);   // works before AND after the migrate script

export const main = async ({ db, FieldValue, argv = [], log = console.log, now = new Date(), outDir } = {}) => {
  const arg = (k) => (argv.find((a) => a.startsWith(`--${k}=`)) || "").slice(k.length + 3);
  const WRITE = argv.includes("--write");
  const CUSTOMER_OK = argv.includes("--customer-verified");
  const rollbackFile = arg("rollback");
  const dir = outDir || path.join(path.dirname(fileURLToPath(import.meta.url)), "backups");
  const commit = async (ops) => { for (const part of chunk(ops, 400)) { const b = db.batch(); part.forEach((op) => op(b)); await b.commit(); } };

  // ── rollback ──
  if (rollbackFile) {
    const saved = JSON.parse(fs.readFileSync(rollbackFile, "utf8"));
    log(`ROLLBACK of ${path.basename(rollbackFile)} (${saved.docs.length} rows) -- ${WRITE ? "WRITE" : "DRY RUN"}`);
    if (WRITE) {
      await commit(saved.docs.map((x) => (b) => b.update(db.collection(x.collection).doc(x.id), revive(x.removed))));
    }
    return { rolledBack: saved.docs.length };
  }

  const load = async (name) => (await db.collection(name).get()).docs.map((d) => ({ id: d.id, ref: d.ref, d: d.data() }));
  const [bookings, payments, entries, refunds, penalties, assignments, cancellations, payArchives] = await Promise.all(
    ["bookings", "payments", "paymentEntries", "refundRequests", "penalties", "driverAssignments", "cancellationRequests", "paymentsArchives"].map(load));

  const entriesByPayment = new Map(); const entriesByRefund = new Map();
  entries.forEach((e) => { push(entriesByPayment, e.d.paymentID, e); push(entriesByRefund, refundIdOf(e.d), e); });
  const paymentByBooking = new Map(); payments.forEach((p) => push(paymentByBooking, p.d.bookingID, p));

  const stats = {}; const kept = []; const backup = []; const ops = [];
  const plan = (col, row, fields, why) => {
    if (!fields.length) return;
    const removed = {}; fields.forEach((k) => { removed[k] = row.d[k]; });
    const s = (stats[col] = stats[col] || { rows: 0, fields: {} });
    s.rows += 1; fields.forEach((k) => { s.fields[k] = (s.fields[k] || 0) + 1; });
    backup.push({ collection: col, id: row.id, removed: toJSONSafe(removed), why });
    const patch = {}; fields.forEach((k) => { patch[k] = FieldValue.delete(); });
    ops.push((b) => b.update(row.ref, patch));
  };
  const keep = (col, id, field, reason) => kept.push(`${col}/${id}: ${field} kept -- ${reason}`);

  // ── default rules ──
  for (const b of bookings) {
    const fields = BOOKING_FEES.filter((k) => has(b.d, k));
    if (!fields.length) continue;
    const pay = (paymentByBooking.get(b.id) || [])[0];
    if (!pay) { fields.forEach((k) => keep("bookings", b.id, k, "no payment doc for this booking")); continue; }
    const ok = [];
    for (const k of fields) {
      const other = k === "driverFee" ? (pay.d.driversFee ?? pay.d.driverFee) : pay.d[k];
      if (num(b.d[k]) === num(other)) ok.push(k); else keep("bookings", b.id, k, `payment ${pay.id} holds ${JSON.stringify(other)} instead of ${JSON.stringify(b.d[k])}`);
    }
    plan("bookings", b, ok, "fee value is on the payment doc");
  }
  for (const p of payments) {
    if (!has(p.d, "paymongoTransactions")) continue;
    if ((entriesByPayment.get(p.id) || []).length) plan("payments", p, ["paymongoTransactions"], "paymentEntries rows exist");
    else keep("payments", p.id, "paymongoTransactions", "no paymentEntries rows for this payment");
  }

  // ── held rules ──
  const held = [];
  const paymentLike = [["payments", payments], ["paymentsArchives", payArchives]];
  for (const [pCol, list] of paymentLike) for (const p of list) {
    const rows = (entriesByPayment.get(pCol === "payments" ? p.id : (p.d.paymentID || p.d.originalId)) || []).filter((e) => e.d.direction !== "out" && e.d.phase !== "penalty");
    const online = rows.filter((e) => e.d.source === "online");
    const fee = (phase) => online.filter((e) => e.d.phase === phase && e.d.status === "success").reduce((a, e) => a + num(e.d.transactionFee), 0);
    const total = online.filter((e) => e.d.status === "success").reduce((a, e) => a + num(e.d.transactionFee), 0);
    const fields = [];
    const test = (k, ok, why) => { if (!has(p.d, k) || isEmpty(p.d[k])) { if (has(p.d, k)) fields.push(k); return; } if (ok) fields.push(k); else keep(pCol, p.id, k, why); };
    for (const k of ["paymongoPaymentID", "depositPaymongoPaymentID", "balancePaymongoPaymentID"])
      test(k, rows.some((e) => e.d.referenceNumber === p.d[k]), "no entry has this id as its referenceNumber");
    test("depositPaymongoFee", Math.abs(fee("deposit") - num(p.d.depositPaymongoFee)) < 0.01, `entries say ${fee("deposit")}, payment says ${p.d.depositPaymongoFee}`);
    test("balancePaymongoFee", Math.abs(fee("balance") - num(p.d.balancePaymongoFee)) < 0.01, `entries say ${fee("balance")}, payment says ${p.d.balancePaymongoFee}`);
    test("paymongoFeeTotal", Math.abs(total - num(p.d.paymongoFeeTotal)) < 0.01, `entries sum to ${total.toFixed(2)}, payment says ${p.d.paymongoFeeTotal}`);
    test("paymongoChannel", online.length > 0, "no online entry for this payment");
    held.push([pCol, p, fields, "value lives in paymentEntries"]);
  }
  for (const r of refunds) {
    const rows = entriesByRefund.get(r.id) || [];
    const fields = [];
    for (const k of ["parts", "manualRefund"]) if (has(r.d, k)) { if (rows.length) fields.push(k); else keep("refundRequests", r.id, k, "no paymentEntries rows for this refund"); }
    if (has(r.d, "paymongoRefundID")) {
      if (rows.length && Array.isArray(r.d.paymongoRefundIDs) && r.d.paymongoRefundIDs.includes(r.d.paymongoRefundID)) fields.push("paymongoRefundID");
      else keep("refundRequests", r.id, "paymongoRefundID", "not in paymongoRefundIDs, or no entries");
    }
    held.push(["refundRequests", r, fields, "value lives in paymentEntries"]);
  }
  for (const p of penalties) {
    const fields = [];
    if (has(p.d, "confirmedBy") && same(p.d.confirmedBy, p.d.createdBy)) fields.push("confirmedBy");
    if (has(p.d, "confirmedAt") && same(p.d.confirmedAt, p.d.createdAt)) fields.push("confirmedAt");
    if (has(p.d, "referenceNumber") && isEmpty(p.d.referenceNumber)) fields.push("referenceNumber");
    if (has(p.d, "paymentMethod") && isEmpty(p.d.paymentMethod)) fields.push("paymentMethod");
    held.push(["penalties", p, fields, "duplicate or empty"]);
  }
  const heldCounts = {};
  for (const [col, row, fields, why] of held) {
    if (!fields.length) continue;
    heldCounts[col] = (heldCounts[col] || 0) + 1;
    if (CUSTOMER_OK) plan(col, row, fields, why);
  }

  // ── audit (report only) ──
  const audit = [];
  const phaseIn = (pid, phase) => (entriesByPayment.get(pid) || []).filter((e) => e.d.direction === "in" && e.d.phase === phase);
  for (const p of payments) {
    const rows = entriesByPayment.get(p.id) || [];
    if (!rows.length) { audit.push(`payments/${p.id}: no paymentEntries rows (status ${p.d.status})`); continue; }
    if ((p.d.balanceCollected || p.d.balanceCollectedAmount || p.d.balanceMethod) && !phaseIn(p.id, "balance").length)
      audit.push(`payments/${p.id}: balance recorded only on the payment doc (no balance entry)`);
    if (p.d.paymongoFeeTotal != null) {
      const sum = rows.reduce((a, e) => a + (e.d.direction === "in" ? num(e.d.transactionFee) : 0), 0);
      if (Math.abs(sum - num(p.d.paymongoFeeTotal)) > 0.01) audit.push(`payments/${p.id}: paymongoFeeTotal ${p.d.paymongoFeeTotal} vs entry fees ${sum.toFixed(2)}`);
    }
    for (const k of ["paymongoPaymentID", "depositPaymongoPaymentID", "balancePaymongoPaymentID"]) {
      if (p.d[k] && !rows.some((e) => e.d.referenceNumber === p.d[k])) audit.push(`payments/${p.id}: ${k} ${p.d[k]} appears on no entry`);
    }
  }
  const assigned = new Set(assignments.map((a) => a.d.bookingID)); const cancelled = new Set(cancellations.map((c) => c.d.bookingID));
  for (const b of bookings) {
    if (b.d.driverID && !assigned.has(b.id)) audit.push(`bookings/${b.id}: driverID set but no driverAssignments row`);
    if (b.d.cancellationReason && !cancelled.has(b.id)) audit.push(`bookings/${b.id}: cancellationReason set but no cancellationRequests row`);
    for (const k of ["paymentMethod", "paymongoIntentId", "paidAt", "paymentStatus"]) if (has(b.d, k)) audit.push(`bookings/${b.id}: ${k} still on the booking (left alone)`);
  }

  // ── report ──
  log(`CLEAN LEFTOVERS -- ${WRITE ? "WRITE" : "DRY RUN (nothing will be written)"}${CUSTOMER_OK ? " -- held rules ON" : ""}\n`);
  log(`Would remove${WRITE ? " (removing)" : ""}:`);
  const names = Object.keys(stats);
  if (!names.length) log("  nothing");
  names.forEach((c) => log(`  ${c.padEnd(16)} ${String(stats[c].rows).padStart(4)} rows   ${JSON.stringify(stats[c].fields)}`));
  if (!CUSTOMER_OK && Object.keys(heldCounts).length) {
    log(`\nHeld (customer backend may read these; add --customer-verified after checking):`);
    Object.entries(heldCounts).forEach(([c, n]) => log(`  ${c.padEnd(16)} ${String(n).padStart(4)} rows`));
    log("  check with, in the customer repo:");
    log("    grep -rnE \"\\.(parts|manualRefund|paymongoRefundID)\\b\" controllers services utils");
    log("    grep -rnE \"confirmedBy|confirmedAt\" controllers services utils");
  }
  if (kept.length) { log(`\nKept (${kept.length}) -- value not proven elsewhere:`); kept.slice(0, 40).forEach((s) => log(`  ${s}`)); if (kept.length > 40) log(`  ... and ${kept.length - 40} more`); }
  log(`\nAUDIT -- not merged, nothing changed (${audit.length}):`);
  if (!audit.length) log("  all clear");
  audit.slice(0, 60).forEach((s) => log(`  ${s}`)); if (audit.length > 60) log(`  ... and ${audit.length - 60} more`);

  const report = { stats, kept, audit, rows: ops.length };
  if (WRITE && ops.length) {
    fs.mkdirSync(dir, { recursive: true });
    const file = path.join(dir, `leftovers-${now.toISOString().replace(/[:.]/g, "-")}.json`);
    fs.writeFileSync(file, JSON.stringify({ at: now.toISOString(), docs: backup }, null, 1));   // BEFORE any write
    await commit(ops);
    report.file = file;
    log(`\nDone. ${ops.length} rows updated. Backup: ${file}`);
    log(`Undo with: node scripts/clean-leftovers.js --rollback=${file} --write`);
  } else if (!WRITE) {
    log("\n(dry run -- add --write to apply)");
  }
  return report;
};

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  await import("dotenv/config");
  const { default: admin } = await import("firebase-admin");
  const { db } = await import("../config/firebaseConnection/firebase.js");
  try { await main({ db, FieldValue: admin.firestore.FieldValue, argv: process.argv.slice(2) }); process.exit(0); }
  catch (err) { console.error("Failed:", err); process.exit(1); }
}