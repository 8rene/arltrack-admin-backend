// Brings the data in line with the normalized models. Run from arltrack-admin-backend/
//
//   node scripts/cleanup-to-models.js                      DRY RUN: prints + saves a report, writes nothing
//   node scripts/cleanup-to-models.js --write              applies it (saves a backup of every touched document first)
//   node scripts/cleanup-to-models.js --only=paymentEntries,transactionLogs     limit to some collections
//   node scripts/cleanup-to-models.js --drop-nonempty      ALSO drop paymentEntries.flags / parentEntryID that still hold a value
//   node scripts/cleanup-to-models.js --backfill-deposit   ALSO copy depositFee -> securityDeposit on older payments (and mark
//                                                          the paid upcoming / ongoing ones depositStatus "Held")
//   node scripts/cleanup-to-models.js --rollback=scripts/backups/<file>.json --write     undo one run
//
// What it does (every rule is per document and only acts when the value is empty, a duplicate of a column
// that already holds it, or provably backed by another row. Anything else is LISTED under "needs your decision"):
//
//   paymentEntries   removes migratedFrom, refID, refCollection, and the empty proofUrl / note / parentEntryID / flags.
//                    Fills who / when: in-person hand-back rows get processedBy / processedAt from their refund request;
//                    a success row without settledAt takes it from the payment's paidAt / balancePaidAt; an online
//                    success row without a PayMongo id takes it from the payment's pay_... id; "N/A" / "—" -> null.
//   transactionLogs  removes refundRequestID (= refundReqID), refID / refCollection (= the FK it duplicates),
//                    transactionID (= doc id). paymentMethod -> method code (GCash -> gcash, "" -> null,
//                    "PayMongo" -> the linked entry's method). referenceNumber sentinels -> null. A Payment log with
//                    no paymentEntryID gets it when exactly one settled entry matches (payment + amount).
//   payments         removes empty proofUrl / referenceNumber, and driverFee / totalFee / depositFee when they equal
//                    driversFee / amount / securityDeposit. Writes the "<paymentID>_discountrefund" out-row for a
//                    payment whose discount refund was handed back (refundIssued), moving refundIssuedBy / At onto it.
//   penalties        removes confirmedBy / confirmedAt when equal to createdBy / createdAt, and empty paymentMethod /
//                    referenceNumber / paidAt. A filled one is removed only when its payment entry exists (or, for a
//                    deposit-covered penalty, once payments.depositSettledAt exists -- run migrate-deposit-flat.js first).
//   bookings         removes cancellationReason when the cancellationRequests row holds the same text, driverID /
//                    driverAssignedAt / driverAssignedBy when a driverAssignments row holds the same driver, and the stray
//                    payment columns (depositFee, driverFee, gatewayFee, totalFee, extraFee, paymentMethod, paidAt,
//                    paymentStatus) when the payment document holds the same value.
//
// NOT touched here (use scripts/clean-leftovers.js --customer-verified for these): payments.paymongo* / balance* /
// paidAt columns, refundRequests.parts / manualRefund. migrate-deposit-flat.js handles the nested payments.deposit.
//
// Order: export Firestore -> migrate-deposit-flat.js -> this script (dry run, read it, --write) -> clean-leftovers.js.
// Safe to re-run: a second run finds nothing to do.
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { normalizeMethod, nullIfSentinel } from "../services/paymentEntries/paymentEntries.mapper.js";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const COLLECTIONS = ["bookings", "payments", "paymentEntries", "refundRequests", "cancellationRequests", "driverAssignments", "penalties", "transactionLogs"];

// ───────────── helpers ─────────────
const has = (v) => v !== undefined && v !== null && v !== "" && !(Array.isArray(v) && v.length === 0);
const num = (v) => { const n = Number(v); return Number.isFinite(n) ? n : 0; };
const lc = (v) => String(v ?? "").trim().toLowerCase();
// A Firestore Timestamp, a Date, or the tagged JSON form the export script writes -> epoch millis (null if not a time).
const ms = (v) => {
  if (!v) return null;
  if (typeof v.toMillis === "function") return v.toMillis();
  if (v instanceof Date) return v.getTime();
  if (v.__type === "timestamp") return v.seconds * 1000 + Math.floor((v.nanoseconds || 0) / 1e6);
  if (typeof v._seconds === "number") return v._seconds * 1000 + Math.floor((v._nanoseconds || 0) / 1e6);
  return null;
};
const sameTime = (a, b) => ms(a) !== null && ms(a) === ms(b);
const group = (rows, keyFn) => { const m = new Map(); for (const r of rows) { const k = keyFn(r); if (k == null || k === "") continue; if (!m.has(k)) m.set(k, []); m.get(k).push(r); } return m; };

// ───────────── the plan (pure: no Firestore) ─────────────
export const buildPlan = (data, opts = {}) => {
  const { dropNonEmpty = false, backfillDeposit = false, only = null } = opts;
  const on = (c) => !only || only.includes(c);
  const D = (c) => data[c] || [];
  const out = { updates: new Map(), creates: [], report: {}, review: {} };

  const upd = (c, id, rule) => {
    const k = `${c}/${id}`;
    if (!out.updates.has(k)) out.updates.set(k, { collection: c, id, set: {}, del: new Set(), rules: new Set() });
    const u = out.updates.get(k); u.rules.add(rule); return u;
  };
  const bump = (bucket, rule, id) => { const r = (out[bucket][rule] ||= { count: 0, sample: [] }); r.count++; if (r.sample.length < 5) r.sample.push(id); };
  const hit = (rule, id) => bump("report", rule, id);
  const flag = (rule, id, note) => bump("review", rule, note ? `${id} (${note})` : id);
  const drop = (c, doc, fields, rule) => {
    const present = fields.filter((f) => f in doc.data);
    if (!present.length) return false;
    const u = upd(c, doc.id, rule); present.forEach((f) => u.del.add(f)); hit(`${c}: ${rule}`, doc.id); return true;
  };
  const setTo = (c, doc, patch, rule) => { const u = upd(c, doc.id, rule); Object.assign(u.set, patch); hit(`${c}: ${rule}`, doc.id); };

  const payByKey = new Map();
  for (const p of D("payments")) { payByKey.set(p.id, p); if (p.data.paymentID) payByKey.set(p.data.paymentID, p); }
  const entriesByPay = group(D("paymentEntries"), (e) => e.data.paymentID);
  const entriesByPen = group(D("paymentEntries"), (e) => e.data.penaltyID);
  const entriesByRefund = group(D("paymentEntries"), (e) => e.data.refundReqID);
  const entryByID = new Map(D("paymentEntries").map((e) => [e.id, e]));
  const refundByID = new Map(D("refundRequests").map((r) => [r.id, r]));
  const crByBooking = group(D("cancellationRequests"), (r) => r.data.bookingID || r.id);
  const daByBooking = group(D("driverAssignments"), (r) => r.data.bookingID);
  const bookingByKey = new Map(); for (const b of D("bookings")) { bookingByKey.set(b.id, b); if (b.data.bookingID) bookingByKey.set(b.data.bookingID, b); }
  const processedRefundByBooking = new Map();   // bookingID -> the latest Approved / Refunded refund request that has a processor
  for (const r of D("refundRequests")) {
    if (!["approved", "refunded"].includes(lc(r.data.status)) || !has(r.data.processedBy)) continue;
    const prev = processedRefundByBooking.get(r.data.bookingID);
    if (!prev || (ms(r.data.processedAt) || 0) > (ms(prev.data.processedAt) || 0)) processedRefundByBooking.set(r.data.bookingID, r);
  }

  // ── paymentEntries ──
  if (on("paymentEntries")) for (const e of D("paymentEntries")) {
    const d = e.data;
    drop("paymentEntries", e, ["migratedFrom"], "remove migratedFrom");
    for (const f of ["proofUrl", "note"]) if (f in d) { if (!has(d[f])) drop("paymentEntries", e, [f], `remove empty ${f}`); else flag(`paymentEntries.${f} holds a value`, e.id); }
    if ("parentEntryID" in d) {
      if (!has(d.parentEntryID) || dropNonEmpty) drop("paymentEntries", e, ["parentEntryID"], has(d.parentEntryID) ? "remove parentEntryID (--drop-nonempty)" : "remove empty parentEntryID");
      else flag("parentEntryID still set (the link is derivable from paymentID + phase + refundReqID)", e.id, d.parentEntryID);
    }
    if ("flags" in d) {
      if (!has(d.flags) || dropNonEmpty) drop("paymentEntries", e, ["flags"], has(d.flags) ? "remove flags (--drop-nonempty)" : "remove empty flags");
      else flag("flags non-empty (no code reads them; run with --drop-nonempty to drop)", e.id, [].concat(d.flags).join(","));
    }
    if ("refID" in d || "refCollection" in d) {
      const fk = { payments: d.paymentID, refundRequests: d.refundReqID, penalties: d.penaltyID }[d.refCollection];
      if ((!has(d.refID) && !has(d.refCollection)) || (has(d.refID) && fk === d.refID)) drop("paymentEntries", e, ["refID", "refCollection"], "remove refID / refCollection (duplicate of the row's own FK)");
      else flag("refID / refCollection differ from the row's own FK", e.id, `${d.refCollection}:${d.refID}`);
    }

    // who / when
    if (d.source === "in_person" && !has(d.processedBy)) {
      const rf = d.direction === "out" ? refundByID.get(d.refundReqID) : null;
      if (rf && ["approved", "refunded"].includes(lc(rf.data.status)) && has(rf.data.processedBy)) {
        const patch = { processedBy: rf.data.processedBy };
        if (!has(d.processedAt) && has(rf.data.processedAt)) patch.processedAt = rf.data.processedAt;
        if (!has(d.settledAt) && d.status === "success" && has(rf.data.processedAt)) patch.settledAt = rf.data.processedAt;
        setTo("paymentEntries", e, patch, "fill processedBy / processedAt from the refund request");
      } else flag("in-person row without processedBy and no processed refund request to copy it from", e.id);
    }
    if (d.direction === "in" && d.status === "success" && !has(d.settledAt)) {
      const p = payByKey.get(d.paymentID);
      const cand = d.phase === "deposit" ? p?.data.paidAt : d.phase === "balance" ? p?.data.balancePaidAt : null;
      if (has(cand)) setTo("paymentEntries", e, { settledAt: cand }, "fill settledAt from the payment's paidAt / balancePaidAt");
      else if (has(d.processedAt)) setTo("paymentEntries", e, { settledAt: d.processedAt }, "fill settledAt from processedAt");
      else flag("success row without settledAt and nothing to copy it from", e.id);
    }
    if (d.source === "online" && d.direction === "in" && d.status === "success" && !has(nullIfSentinel(d.referenceNumber))) {
      const p = payByKey.get(d.paymentID);
      const id = nullIfSentinel(d.phase === "balance" ? p?.data.balancePaymongoPaymentID : (p?.data.depositPaymongoPaymentID || p?.data.paymongoPaymentID));
      if (id) setTo("paymentEntries", e, { referenceNumber: id }, "fill the PayMongo payment id from the payment");
      else flag("online success row has no PayMongo payment id anywhere", e.id);
    }
    if (d.referenceNumber != null && d.referenceNumber !== "" && nullIfSentinel(d.referenceNumber) === null) setTo("paymentEntries", e, { referenceNumber: null }, "referenceNumber sentinel -> null");
    else if (d.referenceNumber === "") setTo("paymentEntries", e, { referenceNumber: null }, "referenceNumber sentinel -> null");
    if (d.source === "online" && d.direction === "out" && has(d.processedBy)) flag("online refund row carries processedBy (model says null for online). Left as is = \"who approved the refund\"", e.id);
  }

  // ── transactionLogs ──
  if (on("transactionLogs")) for (const t of D("transactionLogs")) {
    const d = t.data;
    if ("refundRequestID" in d) {
      if (!has(d.refundRequestID) || d.refundRequestID === d.refundReqID) drop("transactionLogs", t, ["refundRequestID"], "remove refundRequestID (duplicate of refundReqID)");
      else if (!has(d.refundReqID)) { setTo("transactionLogs", t, { refundReqID: d.refundRequestID }, "move refundRequestID -> refundReqID"); drop("transactionLogs", t, ["refundRequestID"], "remove refundRequestID (duplicate of refundReqID)"); }
      else flag("refundRequestID differs from refundReqID", t.id);
    }
    if ("refID" in d || "refCollection" in d) {
      const col = d.refCollection;
      if (col === "maintenance") flag("log points at maintenance (type Expense): not a money log in the model -- see below", t.id);
      else {
        const fkName = col === "paymentEntries" ? "paymentEntryID" : col === "refundRequests" ? "refundReqID" : null;
        if (!has(d.refID) && !has(col)) drop("transactionLogs", t, ["refID", "refCollection"], "remove refID / refCollection (empty)");
        else if (fkName && d[fkName] === d.refID) drop("transactionLogs", t, ["refID", "refCollection"], "remove refID / refCollection (duplicate of the FK column)");
        else if (fkName && !has(d[fkName]) && has(d.refID)) { setTo("transactionLogs", t, { [fkName]: d.refID }, `move refID -> ${fkName}`); drop("transactionLogs", t, ["refID", "refCollection"], "remove refID / refCollection (duplicate of the FK column)"); }
        else flag("refID / refCollection could not be matched to an FK column", t.id, `${col}:${d.refID}`);
      }
    }
    if ("transactionID" in d && d.transactionID === t.id) drop("transactionLogs", t, ["transactionID"], "remove transactionID (= doc id)");

    // method code
    if (d.type !== "Expense" && "paymentMethod" in d) {
      const cur = d.paymentMethod;
      const { method, unmapped } = normalizeMethod(cur);
      let target = method;
      if (!method && !unmapped && has(cur) === false) target = null;                                  // "" / "—" -> null
      if (unmapped || (lc(cur) === "paymongo")) {                                                     // a channel-less label: ask the entry
        const rows = has(d.paymentEntryID) ? [entryByID.get(d.paymentEntryID)].filter(Boolean)
          : has(d.refundReqID) ? (entriesByRefund.get(d.refundReqID) || []) : [];
        const methods = [...new Set(rows.map((r) => r.data.method).filter(Boolean))];
        target = methods.length === 1 ? methods[0] : null;
        if (target === null) flag(`paymentMethod "${cur}" has no single method code (online refund, channel unknown): set to null`, t.id);
      }
      if (target !== cur) setTo("transactionLogs", t, { paymentMethod: target }, "paymentMethod -> method code");
    }
    if (has(d.referenceNumber) ? nullIfSentinel(d.referenceNumber) === null : d.referenceNumber === "") setTo("transactionLogs", t, { referenceNumber: null }, "referenceNumber sentinel -> null");

    // Payment log with no paymentEntryID: link it only when exactly one settled entry matches.
    if (d.type === "Payment" && !has(d.paymentEntryID) && !has(d.penaltyID)) {
      const cands = (entriesByPay.get(d.paymentID) || []).filter((r) => r.data.direction === "in" && r.data.status === "success" && num(r.data.amount) === num(d.amount));
      if (cands.length === 1) setTo("transactionLogs", t, { paymentEntryID: cands[0].id }, "link paymentEntryID (one matching settled entry)");
      else flag("Payment log without paymentEntryID and not exactly one matching entry", t.id, `${cands.length} candidates`);
    }
    if (d.type === "Expense") flag("Expense log: the model says company costs are NOT in this ledger (maintenance.totalCost is their only copy)", t.id);
    if (has(d.refundReqID) && !refundByID.has(d.refundReqID)) flag("refund log whose refund request is not in refundRequests (archived or deleted?)", t.id, d.refundReqID);
  }

  // ── payments ──
  if (on("payments")) for (const p of D("payments")) {
    const d = p.data;
    for (const f of ["proofUrl", "referenceNumber"]) if (f in d) { if (!has(d[f])) drop("payments", p, [f], `remove empty ${f}`); else flag(`payments.${f} holds a value`, p.id); }
    if ("driverFee" in d) { if (num(d.driverFee) === num(d.driversFee)) drop("payments", p, ["driverFee"], "remove driverFee (= driversFee)"); else flag("payments.driverFee differs from driversFee", p.id); }
    if ("totalFee" in d) { if (num(d.totalFee) === num(d.amount)) drop("payments", p, ["totalFee"], "remove totalFee (= amount)"); else flag("payments.totalFee differs from amount", p.id); }
    if ("depositFee" in d) {
      if (num(d.depositFee) === num(d.securityDeposit)) drop("payments", p, ["depositFee"], "remove depositFee (= securityDeposit)");
      else if (num(d.securityDeposit) === 0 && num(d.depositFee) > 0 && !has(d.depositStatus) && !(d.deposit && typeof d.deposit === "object")) {
        // An older payment that stores the deposit ONLY as depositFee: getDepositView() sees no deposit at all, so
        // settling the booking would not return it. The paid + upcoming / ongoing ones are the ones that still matter.
        const bk = bookingByKey.get(d.bookingID); const live = ["upcoming", "ongoing"].includes(lc(bk?.data.status)) && ["paid", "approved"].includes(lc(d.status));
        if (backfillDeposit) {
          setTo("payments", p, { securityDeposit: num(d.depositFee), ...(live ? { depositStatus: "Held" } : {}) }, live ? "depositFee -> securityDeposit + depositStatus Held (paid, upcoming / ongoing)" : "depositFee -> securityDeposit (booking not live)");
          drop("payments", p, ["depositFee"], "remove depositFee (= securityDeposit)");
        } else flag(live ? "LIVE booking keeps its deposit only in depositFee: the deposit is not recognized at settlement (use --backfill-deposit)" : "payment keeps its deposit only in depositFee, booking not live (use --backfill-deposit)", p.id, `${d.depositFee}, booking ${bk?.data.status}`);
      } else flag("payments.depositFee differs from securityDeposit", p.id, `${d.depositFee} vs ${d.securityDeposit}`);
    }

    const paymentID = d.paymentID || p.id;
    const rowID = `${paymentID}_discountrefund`;
    if (d.refundIssued === true && !entryByID.has(rowID)) {
      if (num(d.refundDue) > 0) {
        const at = has(d.refundIssuedAt) ? d.refundIssuedAt : null;
        out.creates.push({ collection: "paymentEntries", id: rowID, data: {
          paymentEntryID: rowID, paymentID, bookingID: d.bookingID ?? null, userID: d.userID ?? null, refundReqID: null, penaltyID: null,
          direction: "out", phase: "deposit", source: "in_person", method: "cash", amount: num(d.refundDue), status: "success",
          referenceNumber: null, sessionID: null, transactionFee: null,
          processedBy: has(d.refundIssuedBy) ? d.refundIssuedBy : null, processedAt: at, settledAt: at,
          groupID: null, transactionErrorNote: null, createdAt: at, updatedAt: at,
        } });
        hit("payments: write the _discountrefund row", p.id);
        if (!has(d.refundIssuedBy) && !at) flag("discount refund row written without who / when (the payment never recorded them)", p.id);
        drop("payments", p, ["refundIssuedBy", "refundIssuedAt"], "move refundIssuedBy / At onto the _discountrefund row");
      } else flag("refundIssued = true but refundDue = 0: no hand-back amount to record, legacy refundIssuedBy / At kept", p.id);
    }
    if ("lastReceiptSentAt" in d) flag("payments.lastReceiptSentAt is in no model (receipt-email timestamp)", p.id);
  }

  // ── penalties ──
  if (on("penalties")) for (const n of D("penalties")) {
    const d = n.data;
    if ("confirmedBy" in d && d.confirmedBy === d.createdBy) drop("penalties", n, ["confirmedBy"], "remove confirmedBy (= createdBy)");
    if ("confirmedAt" in d && sameTime(d.confirmedAt, d.createdAt)) drop("penalties", n, ["confirmedAt"], "remove confirmedAt (= createdAt)");
    else if ("confirmedAt" in d) flag("confirmedAt differs from createdAt: kept", n.id);
    const rows = entriesByPen.get(n.data.penaltyID || n.id) || [];
    const pay = payByKey.get(d.paymentID);
    const depositCovered = lc(d.paymentMethod).startsWith("deposit");
    for (const f of ["paymentMethod", "referenceNumber", "paidAt"]) {
      if (!(f in d)) continue;
      if (!has(d[f])) { drop("penalties", n, [f], `remove empty ${f}`); continue; }
      const backed = depositCovered ? has(pay?.data.depositSettledAt) : rows.length > 0;
      if (backed && !(depositCovered && rows.length > 0 && f === "paymentMethod")) drop("penalties", n, [f], `remove ${f} (the payment row / deposit settlement holds it)`);
      else flag(depositCovered ? `penalties.${f} kept: waiting for payments.depositSettledAt (run migrate-deposit-flat.js first)` : `penalties.${f} kept: no paymentEntries row backs it`, n.id);
    }
  }

  // ── cancellationRequests / driverAssignments ──
  if (on("cancellationRequests")) for (const r of D("cancellationRequests")) {
    const d = r.data;
    drop("cancellationRequests", r, ["migratedFrom"], "remove migratedFrom");
    if (d.type === "direct" && !has(d.processedBy)) {
      const rf = processedRefundByBooking.get(d.bookingID);
      if (rf) setTo("cancellationRequests", r, { processedBy: rf.data.processedBy, ...(has(rf.data.processedAt) ? { processedAt: rf.data.processedAt } : {}) }, "fill processedBy / processedAt from the booking's processed refund request");
      else if (["staff", "admin"].includes(d.cancelledBy)) flag(`direct cancellation by ${d.cancelledBy} with no recorded actor (only the audit log has it)`, r.id);
      else if (sameTime(d.processedAt, d.requestedAt)) flag("direct row's processedAt is only the booking's last update (approximate); processedBy stays null for customer / system cancellations", r.id);
    }
  }
  if (on("driverAssignments")) for (const r of D("driverAssignments")) drop("driverAssignments", r, ["migratedFrom"], "remove migratedFrom");

  // ── bookings ──
  if (on("bookings")) for (const b of D("bookings")) {
    const d = b.data; const key = d.bookingID || b.id;
    if ("cancellationReason" in d) {
      const row = (crByBooking.get(key) || []).find((r) => r.data.status === "approved" && r.data.reason === d.cancellationReason);
      if (row) drop("bookings", b, ["cancellationReason"], "remove cancellationReason (the cancellationRequests row holds it)"); else flag("bookings.cancellationReason has no matching cancellationRequests row", b.id);
    }
    if (["driverID", "driverAssignedAt", "driverAssignedBy"].some((f) => f in d)) {
      const row = (daByBooking.get(key) || []).find((r) => r.data.driverID === d.driverID);
      if (row) drop("bookings", b, ["driverID", "driverAssignedAt", "driverAssignedBy"], "remove driverID / driverAssignedAt / By (a driverAssignments row holds them)"); else flag("bookings.driverID has no matching driverAssignments row", b.id);
    }
    const pay = D("payments").find((p) => p.data.bookingID === key);
    const same = { depositFee: () => num(d.depositFee) === num(pay.data.securityDeposit), driverFee: () => num(d.driverFee) === num(pay.data.driversFee),
      gatewayFee: () => num(d.gatewayFee) === num(pay.data.gatewayFee), totalFee: () => num(d.totalFee) === num(pay.data.amount), extraFee: () => num(d.extraFee) === num(pay.data.extraFee),
      paymentMethod: () => lc(d.paymentMethod) === lc(pay.data.paymentMethod) || lc(d.paymentMethod) === lc(pay.data.methodOfPayment),
      paymentStatus: () => lc(d.paymentStatus) === lc(pay.data.status), paidAt: () => has(pay.data.paidAt) && sameTime(d.paidAt, pay.data.paidAt) };
    for (const [f, eq] of Object.entries(same)) {
      if (!(f in d)) continue;
      if (pay && eq()) drop("bookings", b, [f], `remove stray ${f} (the payment document holds the same value)`); else flag(`bookings.${f} is not backed by the payment document`, b.id);
    }
    if ("paymongoIntentId" in d) flag("bookings.paymongoIntentId is in no model (an old PayMongo intent id): an OLD customer backend wrote this booking", b.id);
  }
  return out;
};

// ───────────── running it against Firestore ─────────────
const stamp = (d) => d.toISOString().replace(/[:.]/g, "-");
const chunk = (arr, n) => { const o = []; for (let i = 0; i < arr.length; i += n) o.push(arr.slice(i, i + n)); return o; };

const run = async () => {
  await import("dotenv/config");
  const admin = (await import("firebase-admin")).default;
  const { db } = await import("../config/firebaseConnection/firebase.js");
  const { Timestamp } = admin.firestore;
  const enc = (v) => {
    if (v === undefined) return null;
    if (v instanceof Timestamp) return { __ts: [v.seconds, v.nanoseconds] };
    if (Array.isArray(v)) return v.map(enc);
    if (v && typeof v === "object") return Object.fromEntries(Object.entries(v).map(([k, x]) => [k, enc(x)]));
    return v;
  };
  const dec = (v) => {
    if (Array.isArray(v)) return v.map(dec);
    if (v && typeof v === "object") return v.__ts ? new Timestamp(v.__ts[0], v.__ts[1]) : Object.fromEntries(Object.entries(v).map(([k, x]) => [k, dec(x)]));
    return v;
  };
  const args = process.argv.slice(2);
  const WRITE = args.includes("--write");
  const rb = args.find((a) => a.startsWith("--rollback="));
  const writeChunked = async (ops) => { for (const part of chunk(ops, 400)) { const batch = db.batch(); part.forEach((f) => f(batch)); await batch.commit(); } };

  if (rb) {
    const file = rb.slice(11);
    const backup = JSON.parse(fs.readFileSync(file, "utf8"));
    console.log(`ROLLBACK ${file}: ${backup.updated.length} documents restored, ${backup.created.length} rows deleted -- ${WRITE ? "WRITE" : "DRY RUN"}`);
    if (!WRITE) { console.log("Dry run only. Add --write to apply."); return; }
    await writeChunked([
      ...backup.updated.map((u) => (b) => b.set(db.collection(u.collection).doc(u.id), dec(u.before))),
      ...backup.created.map((c) => (b) => b.delete(db.collection(c.collection).doc(c.id))),
    ]);
    console.log("Rolled back."); return;
  }

  const onlyArg = args.find((a) => a.startsWith("--only="));
  const only = onlyArg ? onlyArg.slice(7).split(",").map((s) => s.trim()).filter(Boolean) : null;
  const data = {};
  for (const c of COLLECTIONS) data[c] = (await db.collection(c).get()).docs.map((d) => ({ id: d.id, data: d.data() }));
  const plan = buildPlan(data, { dropNonEmpty: args.includes("--drop-nonempty"), backfillDeposit: args.includes("--backfill-deposit"), only });

  const show = (title, bucket) => {
    console.log(`\n${title}`);
    const keys = Object.keys(bucket).sort();
    if (!keys.length) console.log("  (nothing)");
    for (const k of keys) console.log(`  ${String(bucket[k].count).padStart(4)}  ${k}   e.g. ${bucket[k].sample.slice(0, 3).join(", ")}`);
  };
  console.log(`CLEANUP TO MODELS -- ${WRITE ? "WRITE" : "DRY RUN (nothing will be written)"}`);
  show("WILL CHANGE (documents per rule):", plan.report);
  show("NEEDS YOUR DECISION (not touched):", plan.review);
  console.log(`\n${plan.updates.size} documents updated, ${plan.creates.length} rows created.`);

  fs.mkdirSync(path.join(HERE, "reports"), { recursive: true });
  const reportFile = path.join(HERE, "reports", `cleanup-to-models-${stamp(new Date())}.json`);
  fs.writeFileSync(reportFile, JSON.stringify({ report: plan.report, review: plan.review, updated: plan.updates.size, created: plan.creates.length }, null, 2));
  console.log(`Report saved: ${path.relative(process.cwd(), reportFile)}`);
  if (!WRITE) { console.log("\nDry run only. Re-run with --write to apply."); return; }

  // backup first
  const before = new Map(); for (const c of COLLECTIONS) for (const r of data[c]) before.set(`${c}/${r.id}`, r.data);
  const backup = { at: new Date().toISOString(),
    updated: [...plan.updates.values()].map((u) => ({ collection: u.collection, id: u.id, before: enc(before.get(`${u.collection}/${u.id}`)) })),
    created: plan.creates.map((c) => ({ collection: c.collection, id: c.id })) };
  fs.mkdirSync(path.join(HERE, "backups"), { recursive: true });
  const backupFile = path.join(HERE, "backups", `cleanup-to-models-${stamp(new Date())}.json`);
  fs.writeFileSync(backupFile, JSON.stringify(backup));
  console.log(`Backup saved: ${path.relative(process.cwd(), backupFile)}`);

  const { FieldValue } = admin.firestore;
  await writeChunked([
    ...[...plan.updates.values()].map((u) => (b) => {
      const patch = { ...u.set }; for (const f of u.del) patch[f] = FieldValue.delete();
      b.update(db.collection(u.collection).doc(u.id), patch);
    }),
    ...plan.creates.map((c) => (b) => b.create(db.collection(c.collection).doc(c.id), { ...c.data,
      createdAt: c.data.createdAt || FieldValue.serverTimestamp(), updatedAt: c.data.updatedAt || FieldValue.serverTimestamp() })),
  ]);
  console.log(`Done. Undo with: node scripts/cleanup-to-models.js --rollback=${path.relative(process.cwd(), backupFile)} --write`);
};

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  run().then(() => process.exit(0)).catch((e) => { console.error(e); process.exit(1); });
}