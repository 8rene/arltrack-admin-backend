// One-off: moves paymentEntries / transactionLogs (and the dead payment fields) to the cleaned-up columns.
//
//   paymentEntries
//     refID + refCollection  -> refundReqID / penaltyID   ("payments" rows already have paymentID, so nothing to keep)
//     note                   -> transactionErrorNote      (kept only on failed / unrefundable rows, null otherwise)
//     removed                -> parentEntryID, migratedFrom, proofUrl, flags
//   transactionLogs (+ transactionLogArchives)
//     refID + refCollection  -> refundReqID / paymentEntryID / maintenanceID
//     refundRequestID        -> refundReqID, then removed (it was only a deprecated alias)
//     transactionID          -> removed (a stray field on 4 old docs)
//     paymentMethod          -> method code (gcash | maya | qrph | cash | bank_transfer) or ""
//     referenceNumber        -> "" when it was a placeholder ("—", "N/A", "-" ...)
//   payments / paymentsArchives
//     proofUrl               -> removed (PayMongo is the proof)
//     driverFee              -> removed, only when driversFee is also on the doc (it was a typo duplicate)
//   refundRequests (OPT-IN: --drop-refund-leftovers)
//     parts / manualRefund / unrefundable / unrefundableAmount are removed ONLY from a request whose "out"
//     rows already cover every one of them. onlineAmount, manualAmount, approvalLockedAt and
//     paymongoRefundIDs are LIVE fields the refund service still writes -- they are never touched.
//
//   node scripts/migrate-entry-columns.js                        DRY RUN. Prints + saves a report. Writes nothing.
//   node scripts/migrate-entry-columns.js --write                applies it (backs every changed doc up first)
//   node scripts/migrate-entry-columns.js --write --drop-refund-leftovers
//   add --only=entries,logs,payments,refunds                      to run just some steps
//   UNDO:  node scripts/migrate-entry-columns.js --rollback=scripts/backups/entry-columns-<stamp> --write
//          (puts every backed-up document back exactly as it was)
//
// ORDER MATTERS. The customer backend reads and writes these same collections and deploys separately:
//   1. deploy the cleaned admin + customer code (they write / query refundReqID, penaltyID, paymentEntryID ...)
//   2. create the Firestore indexes (see the bottom of models/paymentEntries/paymentEntry.model.js)
//   3. run this script
// Running it BEFORE the customer backend is updated breaks the refund webhook (it still queries refID), and
// old customer code would write the removed columns straight back.
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { normalizeMethod, nullIfSentinel } from "../services/paymentEntries/paymentEntries.mapper.js";

const HERE = path.dirname(fileURLToPath(import.meta.url));

const has = (o, k) => Object.prototype.hasOwnProperty.call(o, k);
const sameJSON = (a, b) => JSON.stringify(a ?? null) === JSON.stringify(b ?? null);

const ENTRY_DROP = ["refID", "refCollection", "parentEntryID", "migratedFrom", "proofUrl", "flags", "note"];
const LOG_DROP = ["refID", "refCollection", "refundRequestID", "transactionID"];
const REFUND_LEFTOVERS = ["parts", "manualRefund", "unrefundable", "unrefundableAmount"];

// ── pure transforms (exported so they can be tested without a database) ─────────────────────────────
/** One paymentEntries document -> { set, del, unknownRef }. set = fields to write, del = fields to delete. */
export const transformEntry = (d) => {
  const set = {}; const del = [];
  const rc = d.refCollection || null;
  let unknownRef = null;
  if (rc && !["payments", "penalties", "refundRequests"].includes(rc)) unknownRef = `${rc}:${d.refID}`;

  const refundReqID = has(d, "refundReqID") ? d.refundReqID : (rc === "refundRequests" ? d.refID || null : null);
  const penaltyID = has(d, "penaltyID") ? d.penaltyID : (rc === "penalties" ? d.refID || null : null);
  if (!has(d, "refundReqID") || d.refundReqID !== refundReqID) set.refundReqID = refundReqID;
  if (!has(d, "penaltyID") || d.penaltyID !== penaltyID) set.penaltyID = penaltyID;
  if ((d.paymentID === undefined || d.paymentID === null || d.paymentID === "") && rc === "payments" && d.refID) set.paymentID = d.refID;

  const text = has(d, "transactionErrorNote") ? d.transactionErrorNote : d.note;
  const note = ["failed", "unrefundable"].includes(d.status) && text ? String(text) : null;
  if (!has(d, "transactionErrorNote") || d.transactionErrorNote !== note) set.transactionErrorNote = note;

  for (const k of ENTRY_DROP) {
    if (k === "refID" || k === "refCollection") { if (unknownRef) continue; }   // never drop a link we could not move
    if (has(d, k)) del.push(k);
  }
  return { set, del, unknownRef };
};

/** One transactionLogs / transactionLogArchives document -> { set, del, unknownRef, methodLost }. */
export const transformLog = (d) => {
  const set = {}; const del = [];
  const rc = d.refCollection || null;
  const known = [null, "refundRequests", "paymentEntries", "maintenance"];
  const unknownRef = (!known.includes(rc) || (!rc && d.refID)) ? `${rc}:${d.refID}` : null;

  const refundReqID = d.refundReqID || (rc === "refundRequests" ? d.refID : null) || d.refundRequestID || null;
  const paymentEntryID = d.paymentEntryID || (rc === "paymentEntries" ? d.refID : null) || null;
  const maintenanceID = d.maintenanceID || (rc === "maintenance" ? d.refID : null) || null;
  if (!has(d, "refundReqID") || d.refundReqID !== refundReqID) set.refundReqID = refundReqID;
  if (!has(d, "paymentEntryID") || d.paymentEntryID !== paymentEntryID) set.paymentEntryID = paymentEntryID;
  if (!has(d, "maintenanceID") || d.maintenanceID !== maintenanceID) set.maintenanceID = maintenanceID;

  const m = normalizeMethod(d.paymentMethod);
  const method = m.method || "";
  if (d.paymentMethod !== method) set.paymentMethod = method;
  const methodLost = m.unmapped ? m.unmapped : null;          // text that matched nothing and was blanked

  const ref = nullIfSentinel(d.referenceNumber) || "";
  if (d.referenceNumber !== ref) set.referenceNumber = ref;

  for (const k of LOG_DROP) {
    if (k === "refID" || k === "refCollection") { if (unknownRef) continue; }
    if (has(d, k)) del.push(k);
  }
  return { set, del, unknownRef, methodLost };
};

/** payments / paymentsArchives document -> { set, del }. */
export const transformPayment = (d, { archive = false } = {}) => {
  const del = [];
  if (has(d, "proofUrl")) del.push("proofUrl");
  if (!archive && has(d, "driverFee") && has(d, "driversFee")) del.push("driverFee");
  return { set: {}, del };
};

// ── backup serialisation (Timestamps / Dates survive the round trip) ────────────────────────────────
function stringifyTyped(obj) {
  return JSON.stringify(obj, function (key, value) {
    const raw = this[key];
    if (raw instanceof Date) return { __date: raw.toISOString() };
    if (raw && typeof raw === "object" && typeof raw.toDate === "function") {
      const s = raw._seconds ?? raw.seconds; const n = raw._nanoseconds ?? raw.nanoseconds ?? 0;
      if (s !== undefined) return { __ts: [s, n] };
    }
    return value;
  }, 1);
}
const reviveTyped = (text, Timestamp) => JSON.parse(text, (k, v) => {
  if (v && typeof v === "object" && v.__date) return new Date(v.__date);
  if (v && typeof v === "object" && Array.isArray(v.__ts)) return Timestamp ? new Timestamp(v.__ts[0], v.__ts[1]) : new Date(v.__ts[0] * 1000);
  return v;
});

const stamp = (d) => d.toISOString().replace(/[:.]/g, "-");

// ── the run ─────────────────────────────────────────────────────────────────────────────────────────
export const migrate = async ({ db, FieldValue, Timestamp, argv = [], log = console.log, now = new Date(), outDir = path.join(HERE) } = {}) => {
  const arg = (n) => { const a = argv.find((x) => x.startsWith(`--${n}=`)); return a ? a.slice(n.length + 3) : null; };
  const WRITE = argv.includes("--write");
  const DROP_REFUND = argv.includes("--drop-refund-leftovers");
  const only = arg("only") ? arg("only").split(",").map((s) => s.trim()).filter(Boolean) : null;
  const want = (s) => !only || only.includes(s);
  const rollbackDir = arg("rollback");

  const makeBatcher = () => {
    let batch = db.batch(); let n = 0;
    return {
      add: async (fn) => { fn(batch); n += 1; if (n >= 400) { await batch.commit(); batch = db.batch(); n = 0; } },
      flush: async () => { if (n) await batch.commit(); batch = db.batch(); n = 0; },
    };
  };

  // ── rollback ──
  if (rollbackDir) {
    const dir = path.resolve(rollbackDir);
    if (!fs.existsSync(dir)) throw new Error(`Backup folder not found: ${dir}`);
    let restored = 0;
    const b = makeBatcher();
    for (const f of fs.readdirSync(dir).filter((x) => x.endsWith(".json"))) {
      const col = f.replace(/\.json$/, "");
      const docs = reviveTyped(fs.readFileSync(path.join(dir, f), "utf8"), Timestamp);
      for (const [id, data] of Object.entries(docs)) {
        restored += 1;
        if (WRITE) await b.add((bt) => bt.set(db.collection(col).doc(id), data));
      }
    }
    if (WRITE) await b.flush();
    log(`${WRITE ? "Restored" : "Would restore"} ${restored} documents from ${dir}.`);
    return { rolledBack: WRITE, restored };
  }

  const load = async (name) => (await db.collection(name).get()).docs.map((d) => ({ id: d.id, ref: d.ref, data: d.data() }));
  const report = {
    mode: WRITE ? "write" : "dry-run", at: now.toISOString(),
    entries: { scanned: 0, changed: 0, droppedFields: {}, unknownRef: [] },
    logs: { scanned: 0, changed: 0, droppedFields: {}, unknownRef: [], methodBlanked: {}, archivesScanned: 0 },
    payments: { scanned: 0, changed: 0, droppedFields: {} },
    refunds: { scanned: 0, withLeftovers: 0, droppable: 0, notCovered: [] },
    changes: [],
  };
  const inc = (o, k) => { o[k] = (o[k] || 0) + 1; };
  const plans = [];   // { col, id, ref, original, set, del }
  const plan = (col, doc, t) => {
    if (!Object.keys(t.set).length && !t.del.length) return false;
    plans.push({ col, id: doc.id, ref: doc.ref, original: doc.data, set: t.set, del: t.del });
    return true;
  };

  // ── paymentEntries ──
  const entryDocs = want("entries") || want("refunds") ? await load("paymentEntries") : [];
  const refundRowsByRequest = new Map();   // refundReqID -> rows (as they WILL be)
  for (const e of entryDocs) {
    const t = transformEntry(e.data);
    const rid = t.set.refundReqID !== undefined ? t.set.refundReqID : e.data.refundReqID;
    if (rid) (refundRowsByRequest.get(rid) || refundRowsByRequest.set(rid, []).get(rid)).push({ id: e.id, ...e.data });
    if (!want("entries")) continue;
    report.entries.scanned += 1;
    if (t.unknownRef) report.entries.unknownRef.push({ id: e.id, ref: t.unknownRef });
    if (plan("paymentEntries", e, t)) { report.entries.changed += 1; t.del.forEach((k) => inc(report.entries.droppedFields, k)); }
  }

  // ── transactionLogs + archives ──
  if (want("logs")) {
    for (const col of ["transactionLogs", "transactionLogArchives"]) {
      const docs = await load(col);
      for (const d of docs) {
        const t = transformLog(d.data);
        if (col === "transactionLogs") report.logs.scanned += 1; else report.logs.archivesScanned += 1;
        if (t.unknownRef) report.logs.unknownRef.push({ col, id: d.id, ref: t.unknownRef });
        if (t.methodLost) inc(report.logs.methodBlanked, t.methodLost);
        if (plan(col, d, t)) { report.logs.changed += 1; t.del.forEach((k) => inc(report.logs.droppedFields, k)); }
      }
    }
  }

  // ── payments + archives ──
  if (want("payments")) {
    for (const col of ["payments", "paymentsArchives"]) {
      for (const d of await load(col)) {
        report.payments.scanned += 1;
        const t = transformPayment(d.data, { archive: col === "paymentsArchives" });
        if (plan(col, d, t)) { report.payments.changed += 1; t.del.forEach((k) => inc(report.payments.droppedFields, k)); }
      }
    }
  }

  // ── refund requests: stale parts[] / manualRefund / unrefundable[] (opt-in, only when the rows cover them) ──
  if (want("refunds")) {
    for (const r of await load("refundRequests")) {
      report.refunds.scanned += 1;
      const left = REFUND_LEFTOVERS.filter((k) => has(r.data, k));
      if (!left.length) continue;
      report.refunds.withLeftovers += 1;
      const id = r.data.refundRequestID || r.id;
      const rows = refundRowsByRequest.get(id) || [];
      const refOf = new Set(rows.map((x) => x.referenceNumber).filter(Boolean));
      const gaps = [];
      for (const p of Array.isArray(r.data.parts) ? r.data.parts : []) {
        const ref = nullIfSentinel(p && p.paymongoRefundID);
        if (ref && !refOf.has(ref)) gaps.push(`part ${ref}`);
      }
      if (r.data.manualRefund && Number(r.data.manualRefund.amount) > 0 && !rows.some((x) => x.id === `${id}_manual`)) gaps.push("manual hand-back");
      const needUnref = Array.isArray(r.data.unrefundable) ? r.data.unrefundable.length : 0;
      if (needUnref > rows.filter((x) => x.status === "unrefundable").length) gaps.push("unrefundable");
      if (gaps.length) { report.refunds.notCovered.push({ id, missing: gaps }); continue; }
      report.refunds.droppable += 1;
      if (DROP_REFUND) plan("refundRequests", r, { set: {}, del: left });
    }
  }

  for (const p of plans) {
    report.changes.push({ col: p.col, id: p.id, set: Object.keys(p.set), del: p.del });
  }

  // ── write ──
  let backupDir = null;
  if (WRITE && plans.length) {
    backupDir = path.join(outDir, "backups", `entry-columns-${stamp(now)}`);
    fs.mkdirSync(backupDir, { recursive: true });
    const byCol = {};
    for (const p of plans) (byCol[p.col] = byCol[p.col] || {})[p.id] = p.original;
    for (const [col, docs] of Object.entries(byCol)) fs.writeFileSync(path.join(backupDir, `${col}.json`), stringifyTyped(docs));
    const b = makeBatcher();
    for (const p of plans) {
      const patch = { ...p.set };
      for (const k of p.del) patch[k] = FieldValue.delete();
      await b.add((bt) => bt.update(p.ref, patch));
    }
    await b.flush();
    report.backupDir = backupDir;
  }

  const reportDir = path.join(outDir, "reports");
  fs.mkdirSync(reportDir, { recursive: true });
  const file = path.join(reportDir, `entry-columns-${WRITE ? "write" : "dryrun"}-${stamp(now)}.json`);
  fs.writeFileSync(file, JSON.stringify(report, null, 1));
  report.file = file;

  log(`\nEntry-column migration (${report.mode})`);
  log(`  paymentEntries      ${report.entries.changed} of ${report.entries.scanned} would change   dropped: ${JSON.stringify(report.entries.droppedFields)}`);
  log(`  transactionLogs     ${report.logs.changed} of ${report.logs.scanned} (+${report.logs.archivesScanned} archived scanned)   dropped: ${JSON.stringify(report.logs.droppedFields)}`);
  log(`  payments            ${report.payments.changed} of ${report.payments.scanned}   dropped: ${JSON.stringify(report.payments.droppedFields)}`);
  log(`  refundRequests      ${report.refunds.withLeftovers} carry old parts/manualRefund; ${report.refunds.droppable} fully covered by rows${DROP_REFUND ? " (dropped)" : " (use --drop-refund-leftovers to remove)"}; ${report.refunds.notCovered.length} NOT covered (left alone)`);
  if (report.entries.unknownRef.length) log(`  !! ${report.entries.unknownRef.length} entries point at an unknown collection and were left linked: ${JSON.stringify(report.entries.unknownRef.slice(0, 5))}`);
  if (report.logs.unknownRef.length) log(`  !! ${report.logs.unknownRef.length} logs point at an unknown record and were left linked: ${JSON.stringify(report.logs.unknownRef.slice(0, 5))}`);
  if (Object.keys(report.logs.methodBlanked).length) log(`  logs whose paymentMethod text matched no method and became "": ${JSON.stringify(report.logs.methodBlanked)}`);
  log(`  report: ${file}`);
  if (WRITE) log(backupDir ? `  backup: ${backupDir}\n  undo:   node scripts/migrate-entry-columns.js --rollback=${backupDir} --write` : "  nothing to change.");
  else log("  (dry run: nothing was written. Add --write to apply.)");
  return report;
};

// ── run directly ──
if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  await import("dotenv/config");
  const { db } = await import("../config/firebaseConnection/firebase.js");
  const admin = (await import("firebase-admin")).default;
  try {
    await migrate({ db, FieldValue: admin.firestore.FieldValue, Timestamp: admin.firestore.Timestamp, argv: process.argv.slice(2) });
    process.exit(0);
  } catch (err) {
    console.error("\nMigration failed:", err);
    process.exit(1);
  }
}
