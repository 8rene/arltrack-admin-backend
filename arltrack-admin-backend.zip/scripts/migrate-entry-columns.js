// Moves existing data to the cleaned-up columns.   Run from arltrack-admin-backend/
//
//   node scripts/migrate-entry-columns.js                          dry run of phase "add"
//   node scripts/migrate-entry-columns.js --write                  phase "add": fills the NEW columns (old ones stay)
//   --- deploy the admin + customer code that reads the new columns ---
//   node scripts/migrate-entry-columns.js --phase=cleanup          dry run of phase "cleanup"
//   node scripts/migrate-entry-columns.js --phase=cleanup --write  removes the OLD columns
//   node scripts/migrate-entry-columns.js --rollback=<backup.json> --write   undoes one run
//
// Why two phases: the code that is live today still queries refID / refCollection. Phase "add" only ADDS
// the new columns, so old and new code both work. Remove the old columns (phase "cleanup") only after
// both backends run the new code. Cleanup skips (and reports) any row whose new column is not filled yet.
//
// paymentEntries     add:    refundReqID, penaltyID, transactionErrorNote
//                    remove: refID, refCollection, parentEntryID, flags, migratedFrom, proofUrl, note
// transactionLogs    add:    refundReqID, paymentEntryID, penaltyID               (same for transactionLogArchives)
//                    remove: refID, refCollection, refundRequestID, transactionID
//                    delete: every type "Expense" row (cleanup phase). The ledger is money-only now; the cost
//                            lives on maintenance.totalCost. Full copies go in the backup file.
// payments           remove: proofUrl, payNow, referenceNumber (only if empty / "—"), driverFee (only if 0 / empty)
// paymentsArchives   remove: proofUrl, referenceNumber (only if empty / "—")
//
// Every write run saves a backup file (scripts/backups/entry-columns-<time>.json) listing exactly what it
// added / removed per row, which --rollback uses. Safe to re-run.
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

const EMPTY = new Set(["", "—", "-", "n/a", "na", "none", "null"]);
const isEmpty = (v) => v === undefined || v === null || (typeof v === "string" && EMPTY.has(v.trim().toLowerCase())) || v === 0;
const has = (d, k) => Object.prototype.hasOwnProperty.call(d, k);

// add(d) -> { column: value }  (only columns the row does not have yet are written)
// remove -> [field, whenRemovable(d)]   (guard: field is only removed when this is true)
const PLAN = {
  paymentEntries: {
    add: (d) => ({
      refundReqID: d.refCollection === "refundRequests" ? (d.refID || null) : null,
      penaltyID: d.refCollection === "penalties" ? (d.refID || null) : null,
      transactionErrorNote: isEmpty(d.note) ? null : String(d.note),
    }),
    remove: [["refID"], ["refCollection"], ["parentEntryID"], ["flags"], ["migratedFrom"], ["proofUrl"], ["note"]],
  },
  transactionLogs: {
    add: (d) => ({
      refundReqID: d.refCollection === "refundRequests" ? (d.refID || null) : (d.refundRequestID || null),
      paymentEntryID: d.refCollection === "paymentEntries" ? (d.refID || null) : null,
      penaltyID: null,        // old penalty payment logs carried no link, so nothing to backfill
    }),
    remove: [["refID"], ["refCollection"], ["refundRequestID"], ["transactionID"]],
  },
  payments: {
    add: () => ({}),
    remove: [["proofUrl"], ["payNow"], ["referenceNumber", (d) => isEmpty(d.referenceNumber)], ["driverFee", (d) => isEmpty(d.driverFee)]],
  },
  paymentsArchives: {
    add: () => ({}),
    remove: [["proofUrl", (d) => isEmpty(d.proofUrl)], ["referenceNumber", (d) => isEmpty(d.referenceNumber)]],
  },
};
PLAN.transactionLogArchives = PLAN.transactionLogs;

// Does the row still lack a new column its old one would have filled? (cleanup must not drop the only copy)
const notAddedYet = (name, d, wanted) => Object.entries(wanted).some(([k, v]) => v !== null && d[k] !== v);

// Firestore Timestamps / Dates -> {__ts: millis} so a deleted row can be written back exactly.
const toJSONSafe = (v) => JSON.parse(JSON.stringify(v, function (k, x) {
  const raw = this[k];                                   // JSON.stringify already turned a Date into a string in x
  if (raw instanceof Date) return { __ts: raw.getTime() };
  return raw && typeof raw.toMillis === "function" ? { __ts: raw.toMillis() } : x;
}));
const revive = (v) => JSON.parse(JSON.stringify(v), (k, x) => (x && typeof x === "object" && "__ts" in x ? new Date(x.__ts) : x));

const chunk = (arr, n) => { const out = []; for (let i = 0; i < arr.length; i += n) out.push(arr.slice(i, i + n)); return out; };

export const main = async ({ db, FieldValue, argv = [], log = console.log, now = new Date(), outDir } = {}) => {
  const arg = (k) => (argv.find((a) => a.startsWith(`--${k}=`)) || "").slice(k.length + 3);
  const WRITE = argv.includes("--write");
  const phase = arg("phase") || "add";
  const rollbackFile = arg("rollback");
  const dir = outDir || path.join(path.dirname(fileURLToPath(import.meta.url)), "backups");
  const commit = async (ops) => {
    for (const part of chunk(ops, 400)) { const b = db.batch(); part.forEach((op) => op(b)); await b.commit(); }
  };

  // ── rollback ──
  if (rollbackFile) {
    const saved = JSON.parse(fs.readFileSync(rollbackFile, "utf8"));
    log(`ROLLBACK of ${path.basename(rollbackFile)} (${saved.phase}, ${saved.docs.length} rows) -- ${WRITE ? "WRITE" : "DRY RUN"}`);
    if (WRITE) {
      await commit(saved.docs.map((x) => (b) => {
        const ref = db.collection(x.collection).doc(x.id);
        const patch = {};
        (x.added || []).forEach((k) => { patch[k] = FieldValue.delete(); });
        Object.entries(x.removed || {}).forEach(([k, v]) => { patch[k] = v; });
        if (x.deleted) b.set(ref, revive(x.deleted));            // a row the cleanup removed: put it back whole
        else b.update(ref, patch);
      }));
    }
    return { rolledBack: saved.docs.length };
  }

  if (!["add", "cleanup"].includes(phase)) throw new Error(`--phase must be add or cleanup (got "${phase}")`);
  log(`MIGRATE entry columns, phase "${phase}" -- ${WRITE ? "WRITE" : "DRY RUN (nothing will be written)"}\n`);
  const report = { phase, collections: {}, skipped: [] };
  const backup = [];
  const ops = [];

  for (const [name, plan] of Object.entries(PLAN)) {
    const snap = await db.collection(name).get();
    const stat = { scanned: snap.size, changed: 0, fieldCounts: {} };
    for (const doc of snap.docs) {
      const d = doc.data();
      const patch = {}; const entry = { collection: name, id: doc.id };
      const isExpense = name.startsWith("transactionLog") && d.type === "Expense";
      if (isExpense) {
        if (phase === "cleanup") {
          entry.deleted = toJSONSafe(d); stat.fieldCounts.expenseRowsDeleted = (stat.fieldCounts.expenseRowsDeleted || 0) + 1;
          stat.changed += 1; backup.push(entry); ops.push((b) => b.delete(doc.ref));
        }
        continue;
      }
      if (phase === "add") {
        const wanted = plan.add(d);
        for (const [k, v] of Object.entries(wanted)) {
          if (!has(d, k)) { patch[k] = v; stat.fieldCounts[k] = (stat.fieldCounts[k] || 0) + 1; }
        }
        if (Object.keys(patch).length) entry.added = Object.keys(patch);
      } else {
        const wanted = plan.add(d);
        const blocked = (name === "paymentEntries" || name.startsWith("transactionLog")) && notAddedYet(name, d, wanted);
        if (blocked) { report.skipped.push(`${name}/${doc.id}: new columns not filled yet (run phase "add" first)`); continue; }
        entry.removed = {};
        for (const [k, guard] of plan.remove) {
          if (!has(d, k)) continue;
          if (guard && !guard(d)) { report.skipped.push(`${name}/${doc.id}: ${k} has a real value (${JSON.stringify(d[k])}) -- kept`); continue; }
          entry.removed[k] = d[k]; patch[k] = FieldValue.delete(); stat.fieldCounts[k] = (stat.fieldCounts[k] || 0) + 1;
        }
        if (!Object.keys(entry.removed).length) continue;
      }
      if (!Object.keys(patch).length) continue;
      stat.changed += 1; backup.push(entry);
      ops.push((b) => b.update(doc.ref, patch));
    }
    report.collections[name] = stat;
    log(`${name.padEnd(22)} scanned ${String(stat.scanned).padStart(4)}   rows to change ${String(stat.changed).padStart(4)}   ${JSON.stringify(stat.fieldCounts)}`);
  }
  if (report.skipped.length) { log(`\nSkipped ${report.skipped.length}:`); report.skipped.slice(0, 20).forEach((s) => log(`  ${s}`)); }

  if (WRITE && ops.length) {
    fs.mkdirSync(dir, { recursive: true });
    const file = path.join(dir, `entry-columns-${now.toISOString().replace(/[:.]/g, "-")}.json`);
    fs.writeFileSync(file, JSON.stringify({ phase, at: now.toISOString(), docs: backup }, null, 1));   // BEFORE any write
    await commit(ops);
    report.file = file;
    log(`\nDone. ${ops.length} rows updated. Backup: ${file}`);
    log(`Undo with: node scripts/migrate-entry-columns.js --rollback=${file} --write`);
  } else if (!WRITE) {
    log("\n(dry run -- add --write to apply)");
  }
  return report;
};

// ── run directly ──
if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  await import("dotenv/config");
  const { default: admin } = await import("firebase-admin");
  const { db } = await import("../config/firebaseConnection/firebase.js");
  try { await main({ db, FieldValue: admin.firestore.FieldValue, argv: process.argv.slice(2) }); process.exit(0); }
  catch (err) { console.error("Failed:", err); process.exit(1); }
}
