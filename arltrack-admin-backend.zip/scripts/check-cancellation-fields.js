// READ-ONLY check. Writes nothing.
// Put in arltrack-admin-backend/scripts/ and run from arltrack-admin-backend/:
//   node scripts/check-cancellation-fields.js
//
// Answers: "do any bookings actually carry cancellation-request data?"
// A schema document only lists fields that CAN exist. Firestore only stores a
// field on a document if something wrote it, so a field can be in the schema
// and on zero documents.

import "dotenv/config";
import admin from "firebase-admin";

if (process.env.FIREBASE_SERVICE_ACCOUNT) {
  const sa = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT.replace(/\r?\n/g, ""));
  sa.private_key = sa.private_key.replace(/\\n/g, "\n");
  admin.initializeApp({ credential: admin.credential.cert(sa) });
} else {
  admin.initializeApp({ credential: admin.credential.applicationDefault() });
}
const db = admin.firestore();

const CANCEL_FIELDS = [
  "cancellationRequestStatus", "cancellationRequestReason", "cancellationRequestedAt",
  "cancellationRejectReason", "statusBeforeCancellationRequest",
];

const scan = async (collectionName) => {
  const snap = await db.collection(collectionName).get();
  const out = {
    collection: collectionName,
    total: snap.size,
    byStatus: {},
    fieldPresent: Object.fromEntries(CANCEL_FIELDS.map((f) => [f, 0])), // key exists, even if empty/null
    fieldHasValue: Object.fromEntries(CANCEL_FIELDS.map((f) => [f, 0])), // key exists AND non-empty
    statusIsCancellationRequest: 0,
    cancelledWithReason: 0,
    withDriverID: 0,
    examples: [],
  };
  snap.forEach((doc) => {
    const d = doc.data();
    const st = String(d.status || "(none)");
    out.byStatus[st] = (out.byStatus[st] || 0) + 1;
    let any = false;
    for (const f of CANCEL_FIELDS) {
      if (f in d) { out.fieldPresent[f]++; any = true; }
      if (d[f] !== undefined && d[f] !== null && d[f] !== "") { out.fieldHasValue[f]++; }
    }
    if (st.toLowerCase() === "cancellation_request") { out.statusIsCancellationRequest++; any = true; }
    if (st.toLowerCase() === "cancelled" && d.cancellationReason) out.cancelledWithReason++;
    if (d.driverID) out.withDriverID++;
    if (any && out.examples.length < 10) {
      out.examples.push({
        docID: doc.id,
        bookingID: d.bookingID || null,
        status: d.status || null,
        cancellationRequestStatus: d.cancellationRequestStatus ?? null,
      });
    }
  });
  return out;
};

const main = async () => {
  for (const c of ["bookings", "bookingArchives"]) {
    try {
      console.log(JSON.stringify(await scan(c), null, 2), "\n");
    } catch (e) {
      console.log(`${c}: could not read (${e.message})\n`);
    }
  }
};
main().then(() => process.exit(0)).catch((e) => { console.error(e); process.exit(1); });