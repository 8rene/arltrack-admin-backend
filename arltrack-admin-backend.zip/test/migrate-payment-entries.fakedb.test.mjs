// Run:  node --test tests/migrate-payment-entries.fakedb.test.mjs      (from arltrack-admin-backend/)
import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { makeFakeDb } from "./fakeFirestore.mjs";
import { main } from "../scripts/migrate-payment-entries.js";
import { makeEntriesDb } from "../services/paymentEntries/paymentEntries.core.js";
import { hydratePayment, hydratePenalty } from "../services/paymentEntries/paymentEntries.mapper.js";

const D = (s) => new Date(s);
const seed = () => ({
  payments: {
    payA: { paymentID: "payA", bookingID: "bkA", userID: "u1", amount: 4000, securityDeposit: 500, methodOfPayment: "Full", status: "paid", paidAt: D("2026-09-01"), createdAt: D("2026-08-30"), paymentMethod: "PayMongo", referenceNumber: "N/A", depositPaymongoPaymentID: "pay_A", depositPaymongoFee: 60, paymongoChannel: "gcash", paymongoSessionID: "cs_A", checkoutUrl: "http://pay/A", balanceStatus: "not_applicable", proofUrl: "" },
    payB: { paymentID: "payB", bookingID: "bkB", userID: "u2", amount: 5000, securityDeposit: 1000, methodOfPayment: "Partial", status: "paid", paidAt: D("2026-09-02"), createdAt: D("2026-09-01"), paymentMethod: "PayMongo", referenceNumber: "—", depositPaymongoPaymentID: "pay_B", paymongoChannel: "paymaya", balanceStatus: "not_due", balanceCollected: true, balanceCollectedAmount: 2000, balanceMethod: "Cash", balanceCollectedBy: "staff9", balanceCollectedAt: D("2026-09-09"), deposit: { amount: 1000, status: "Held", settlement: { status: "OwedByCustomer" } }, paymongoTransactions: [] },
    payC: { paymentID: "payC", bookingID: "bkC", userID: "u3", amount: 3000, methodOfPayment: "Full", status: "paid", paidAt: D("2026-09-03"), createdAt: D("2026-09-02"), paymentMethod: "PayMongo", referenceNumber: "N/A", paymongoChannel: "gcash", balanceStatus: "not_applicable" },
    payD: { paymentID: "payD", bookingID: "bkD", userID: "u4", amount: 3000, methodOfPayment: "Full", status: "pending", paymentMethod: "", referenceNumber: "N/A", createdAt: D("2026-09-04"), balanceStatus: "not_applicable" },
    payE: { paymentID: "payE", bookingID: "bkE", userID: "u5", amount: 2500, methodOfPayment: "Full", status: "Approved", paymentMethod: "Cash", referenceNumber: "OR-5", confirmedBy: "staff1", confirmedAt: D("2026-09-05"), createdAt: D("2026-09-04"), balanceStatus: "not_applicable" },
  },
  paymentsArchives: {
    arch1: { paymentsArchivesID: "arch1", originalId: "payX", paymentID: "payX", bookingID: "bkX", userID: "u6", amount: 2000, methodOfPayment: "Full", status: "paid", paidAt: D("2026-07-01"), createdAt: D("2026-06-30"), paymentMethod: "PayMongo", depositPaymongoPaymentID: "pay_X", paymongoChannel: "qrph", balanceStatus: "not_applicable" },
  },
  penalties: {
    penOK:  { penaltyID: "penOK", bookingID: "bkA", paymentID: "payA", userID: "u1", amount: 500, paidAmount: 500, paymentMethod: "InStore", referenceNumber: "OR-77", paidAt: D("2026-09-10"), status: "Confirmed" },
    penDep: { penaltyID: "penDep", bookingID: "bkA", paymentID: "payA", userID: "u1", amount: 300, paidAmount: 300, paymentMethod: "Deposit", referenceNumber: "", paidAt: D("2026-09-11"), status: "Confirmed" },
    penInv: { penaltyID: "penInv", bookingID: "bkB", paymentID: "payB", userID: "u2", amount: 900, paidAmount: 900, paymentMethod: "GCash", referenceNumber: "G-1", paidAt: D("2026-09-12"), status: "Confirmed" },
    penNo:  { penaltyID: "penNo", bookingID: "bkC", paymentID: "payC", userID: "u3", amount: 200, paidAmount: 0, paymentMethod: "", referenceNumber: "", paidAt: null, status: "Confirmed" },
  },
  penaltyArchives: {
    parch: { penaltyArchivesId: "parch", originalId: "penX", penaltyID: "penX", bookingID: "bkX", paymentID: "payX", userID: "u6", amount: 100, paidAmount: 100, paymentMethod: "Maya", referenceNumber: "M-2", paidAt: D("2026-07-05"), status: "Confirmed" },
  },
  transactionLogs: {
    payA_deposit: { transactionLogsID: "payA_deposit", paymentID: "payA", type: "Payment", amount: 4000, referenceNumber: "—", refID: null },
    payB_balance: { transactionLogsID: "payB_balance", paymentID: "payB", type: "Payment", amount: 2000, referenceNumber: "", refID: null },
    refLog:       { transactionLogsID: "refLog", paymentID: "payA", type: "Refund", amount: 100, referenceNumber: "re_1", refundRequestID: "rr1", refID: null },
    maint:        { transactionLogsID: "maint", type: "Expense", amount: 900, refID: "m1", refCollection: "maintenance", referenceNumber: "INV-1" },
  },
});

const run = async (fake, args, dir) => {
  const lines = [];
  const out = await main({ db: fake.db, FieldValue: fake.FieldValue, argv: args, log: (s) => lines.push(String(s)), now: new Date("2026-10-07T00:00:00Z"), outDir: dir });
  return { out, lines: lines.join("\n") };
};
const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), "pe-"));

test("dry run writes nothing but reports what it would do", async () => {
  const fake = makeFakeDb(seed()); const dir = tmp();
  const { out } = await run(fake, [], dir);
  assert.equal(fake.count("paymentEntries"), 0);
  assert.equal(fake.raw("payments").get("payA").referenceNumber, "N/A");           // untouched
  assert.equal(out.entries.created, 8);                                           // 5 live payment rows, 1 archived payment, 2 penalties (live + archived)
  assert.equal(fs.existsSync(path.join(dir, "backups")), false);                  // no backup needed for a dry run
  assert.equal(fs.readdirSync(path.join(dir, "reports")).length, 1);
});

test("--write creates exactly the expected rows and flags the right things", async () => {
  const fake = makeFakeDb(seed()); const dir = tmp();
  const { out } = await run(fake, ["--write"], dir);
  const ids = [...fake.raw("paymentEntries").keys()].sort();
  assert.deepEqual(ids, ["payA_deposit", "payB_balance", "payB_deposit", "payC_deposit", "payE_deposit", "payX_deposit", "penOK_legacy", "penX_legacy"]);
  assert.equal(fake.raw("paymentEntries").has("payD_deposit"), false);            // never started -> no row
  assert.equal(out.skipped["payments:deposit:not_started"], 1);
  assert.deepEqual(out.flagged.missing_payment_id, ["payC"]);                      // paid online, no pay_ id
  assert.deepEqual(out.review.depositInvolved.sort(), ["penInv"]);                 // deposit-settled booking -> review, not guessed
  assert.equal(out.review.depositOffset, 1);                                       // "Deposit" penalty -> no money moved
  assert.equal(fake.raw("paymentEntries").has("penDep_legacy"), false);
  const B = fake.raw("paymentEntries").get("payB_balance");
  assert.equal(B.source, "in_person"); assert.equal(B.method, "cash"); assert.equal(B.amount, 2000); assert.equal(B.processedBy, "staff9");
  const X = fake.raw("paymentEntries").get("payX_deposit");                        // archived payment uses its originalId
  assert.equal(X.paymentID, "payX"); assert.equal(X.migratedFrom, "paymentsArchives.legacy"); assert.equal(X.method, "qrph");
  assert.equal(fake.raw("paymentEntries").get("penOK_legacy").refCollection, "penalties");
  for (const row of fake.raw("paymentEntries").values()) for (const [k, v] of Object.entries(row)) assert.notEqual(v, undefined, `${row.paymentEntryID}.${k}`);
});

test("logs get refID/refCollection, sentinels become null, nothing else on the log changes", async () => {
  const fake = makeFakeDb(seed());
  await run(fake, ["--write"], tmp());
  const L = fake.raw("transactionLogs");
  assert.equal(L.get("payA_deposit").refID, "payA_deposit"); assert.equal(L.get("payA_deposit").refCollection, "paymentEntries");
  assert.equal(L.get("payA_deposit").referenceNumber, null); assert.equal(L.get("payB_balance").referenceNumber, null);
  assert.equal(L.get("refLog").refID, "rr1"); assert.equal(L.get("refLog").refCollection, "refundRequests"); assert.equal(L.get("refLog").refundRequestID, "rr1");
  assert.equal(L.get("maint").refCollection, "maintenance"); assert.equal(L.get("maint").referenceNumber, "INV-1");  // untouched
  assert.equal(fake.raw("payments").get("payA").referenceNumber, null);
  assert.equal(fake.raw("payments").get("payE").referenceNumber, "OR-5");                                               // real value kept
});

test("a second run changes nothing (idempotent)", async () => {
  const fake = makeFakeDb(seed());
  await run(fake, ["--write"], tmp());
  const before = JSON.stringify([...fake.raw("paymentEntries")]);
  const { out } = await run(fake, ["--write"], tmp());
  assert.equal(out.entries.created, 0); assert.equal(out.entries.skippedExisting, 8);
  assert.equal(JSON.stringify([...fake.raw("paymentEntries")]), before);
});

test("--limit and --only narrow the run", async () => {
  const fake = makeFakeDb(seed());
  const { out } = await run(fake, ["--write", "--only=payments", "--limit=1"], tmp());
  assert.equal(out.entries.created, 1);
  assert.equal(fake.raw("payments").get("payA").referenceNumber, "N/A");           // sentinels step not selected
});

test("rollback deletes what phase 1 created and restores what it changed", async () => {
  const fake = makeFakeDb(seed()); const dir = tmp();
  const { out } = await run(fake, ["--write"], dir);
  await run(fake, [`--rollback=${out.file}`, "--write"], dir);
  assert.equal(fake.count("paymentEntries"), 0);
  assert.equal(fake.raw("payments").get("payA").referenceNumber, "N/A");
  assert.equal(fake.raw("transactionLogs").get("payA_deposit").referenceNumber, "—");
  assert.equal(fake.raw("transactionLogs").get("payA_deposit").refID, null);
});

test("cleanup refuses to write without the confirmation flag", async () => {
  const fake = makeFakeDb(seed());
  await run(fake, ["--write"], tmp());
  const { out } = await run(fake, ["--cleanup", "--write"], tmp());
  assert.equal(out.refused, true);
  assert.equal(fake.raw("payments").get("payA").depositPaymongoPaymentID, "pay_A");
});

test("cleanup removes moved fields, keeps the protected ones, and hydrate gives them all back", async () => {
  const fake = makeFakeDb(seed());
  await run(fake, ["--write"], tmp());
  const original = structuredClone(fake.raw("payments").get("payA"));
  const dry = await run(fake, ["--cleanup"], tmp());
  assert.equal(fake.raw("payments").get("payA").depositPaymongoPaymentID, "pay_A");    // dry run: untouched
  assert.ok(dry.out.payments.cleaned >= 1);
  const { out } = await run(fake, ["--cleanup", "--write", "--confirm-readers-switched"], tmp());
  const A = fake.raw("payments").get("payA");
  for (const f of ["depositPaymongoPaymentID", "depositPaymongoFee", "paymongoChannel", "paidAt"]) assert.equal(A[f], undefined, f);
  for (const f of ["paymentMethod", "paymongoSessionID", "checkoutUrl", "status", "amount", "securityDeposit", "methodOfPayment"]) assert.equal(A[f], original[f], `${f} must stay`);
  // payC has no pay_ id and payD has no rows: nothing to lose, but also nothing unsafe removed
  assert.equal(fake.raw("payments").get("payD").referenceNumber, null);
  const svc = makeEntriesDb(fake.db);
  const [h] = await svc.hydratePayments([{ id: "payA", ...A }]);
  assert.equal(h.depositPaymongoPaymentID, "pay_A"); assert.equal(h.depositPaymongoFee, 60);
  assert.equal(h.paymongoChannel, "gcash"); assert.deepEqual(h.paidAt, original.paidAt);
  // penalties: converted ones lose the three fields; review / deposit-covered ones keep them
  assert.equal(fake.raw("penalties").get("penOK").paymentMethod, undefined);
  assert.equal(fake.raw("penalties").get("penInv").paymentMethod, "GCash");
  assert.equal(fake.raw("penalties").get("penDep").paymentMethod, "Deposit");
  const [hp] = await svc.hydratePenalties([{ id: "penOK", ...fake.raw("penalties").get("penOK") }]);
  assert.equal(hp.paymentMethod, "InStore"); assert.equal(hp.referenceNumber, "OR-77"); assert.equal(hp.paidAmount, 500);
  assert.ok(out.payments.fieldsRemoved > 0);
});

test("syncPaymentEntries: creates rows, never downgrades success on a late event, force allows a manual change", async () => {
  const fake = makeFakeDb(seed()); const svc = makeEntriesDb(fake.db);
  assert.deepEqual(await svc.syncPaymentEntries("payA"), { written: 1 });
  assert.equal(fake.raw("paymentEntries").get("payA_deposit").status, "success");
  await fake.db.collection("payments").doc("payA").update({ status: "pending" });
  assert.deepEqual(await svc.syncPaymentEntries("payA"), { written: 0 });                  // late pending event ignored
  assert.equal(fake.raw("paymentEntries").get("payA_deposit").status, "success");
  assert.deepEqual(await svc.syncPaymentEntries("payA", { force: true }), { written: 1 }); // staff changed it on purpose
  assert.equal(fake.raw("paymentEntries").get("payA_deposit").status, "pending");
  assert.deepEqual(await svc.syncPaymentEntries("does-not-exist"), { written: 0 });
  assert.deepEqual(await svc.syncPaymentEntries(null), { written: 0 });
});

test("syncPaymentEntries never throws, even when the database does", async () => {
  const broken = { collection: () => { throw new Error("boom"); } };
  const r = await makeEntriesDb(broken).syncPaymentEntries("x");
  assert.equal(r.written, 0); assert.equal(r.error, "boom");
});

test("batched reads and the booking cleanup refs", async () => {
  const fake = makeFakeDb(seed()); const svc = makeEntriesDb(fake.db);
  await run(fake, ["--write"], tmp());
  const m = await svc.getEntriesForPaymentIDs(["payA", "payB", "nope"]);
  assert.equal(m.get("payA").length, 2);                                   // its deposit row + the penalty row paid against it
  assert.deepEqual(m.get("payA").map((e) => e.phase).sort(), ["deposit", "penalty"]);
  assert.equal(m.get("payB").length, 2); assert.equal(m.get("nope").length, 0);
  const pm = await svc.getEntriesForPenaltyIDs(["penOK"]);
  assert.equal(pm.get("penOK").length, 1);
  assert.equal((await svc.getEntryRefsForBooking("bkB")).length, 2);
  assert.equal((await svc.getEntryRefsForBooking(null)).length, 0);
});

// ── the read-only checker ──
import { main as check } from "../scripts/check-payment-fields.js";
test("check script: finds the data problems before the migration, and verifies entries after it", async () => {
  const fake = makeFakeDb(seed()); const lines = [];
  const before = await check({ db: fake.db, log: (s) => lines.push(s) });
  assert.deepEqual(before.problems.missingPaymentID, ["payC"]);
  assert.deepEqual(before.problems.penaltyDepositInvolved, ["penInv"]);
  assert.equal(before.problems.sentinelReference, 4);                // payA, payB, payC, payD (payE has a real receipt number)
  assert.equal(fake.count("paymentEntries"), 0);
  await run(fake, ["--write"], tmp());
  const after = await check({ db: fake.db, log: () => {} });
  assert.equal(after.verify.missing.length, 0); assert.equal(after.verify.different.length, 0); assert.equal(after.verify.orphans.length, 0);
  // break one on purpose
  await fake.db.collection("paymentEntries").doc("payA_deposit").update({ amount: 1 });
  const broken = await check({ db: fake.db, log: () => {} });
  assert.equal(broken.verify.different.length, 1);
  // checker never writes
  assert.equal(fake.raw("payments").get("payA").status, "paid");
});
