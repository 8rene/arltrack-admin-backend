// Run:  node --test tests/refunds.test.mjs      (from arltrack-admin-backend/)
import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { createRequire } from "node:module";
import { fileURLToPath } from "node:url";
import { computeRefundPlan, PAYMENT_ID_MISSING_NOTE } from "../services/payments/paymentBreakdown.js";
import { buildRefundEntries, mergeRefundEntry, hydrateRefundRequest } from "../services/paymentEntries/paymentEntries.mapper.js";
import { makeEntriesDb } from "../services/paymentEntries/paymentEntries.core.js";
import { makeFakeDb } from "./fakeFirestore.mjs";
import { main as migrate } from "../scripts/migrate-payment-entries.js";
import { main as check } from "../scripts/check-payment-fields.js";

const D = (s) => new Date(s);
const NOW = new Date("2026-10-01T00:00:00Z");
// Partial: 5000 total, 1000 security deposit -> deposit 3000, balance 2000.
const base = { paymentID: "p1", bookingID: "b1", userID: "u1", amount: 5000, securityDeposit: 1000, methodOfPayment: "Partial", status: "paid", balanceStatus: "not_due" };

// ── the plan ──
test("plan: online money WITH a payment id is a PayMongo part", () => {
  const p = computeRefundPlan({ ...base, depositPaymongoPaymentID: "pay_d", paymongoChannel: "gcash" });
  assert.equal(p.total, 3000); assert.deepEqual(p.parts.map((x) => [x.kind, x.amount]), [["deposit", 3000]]);
  assert.equal(p.manualAmount, 0); assert.equal(p.unrefundableAmount, 0);
});
test("plan: online money with NO payment id is reported, NEVER a hand-back", () => {
  const p = computeRefundPlan({ ...base, paymongoChannel: "gcash", paymongoSessionID: "cs_1" });
  assert.equal(p.total, 0); assert.equal(p.manualAmount, 0); assert.equal(p.parts.length, 0);
  assert.equal(p.unrefundableAmount, 3000); assert.deepEqual(p.unrefundable, [{ kind: "deposit", amount: 3000, reason: "payment_id_missing" }]);
});
test("plan: cash taken by staff is still handed back", () => {
  const p = computeRefundPlan({ ...base, paymentMethod: "Cash", confirmedBy: "s1" });
  assert.equal(p.manualAmount, 3000); assert.equal(p.unrefundableAmount, 0); assert.equal(p.total, 3000);
});
test("plan: balance paid online with no id is unrefundable; the deposit part still refunds", () => {
  const p = computeRefundPlan({ ...base, depositPaymongoPaymentID: "pay_d", balanceStatus: "paid" });
  assert.equal(p.total, 3000); assert.equal(p.unrefundableAmount, 2000);
  assert.deepEqual(p.unrefundable.map((u) => u.kind), ["balance"]);
});
test("plan: balance collected in person is a hand-back, with the forfeit coming off the deposit", () => {
  const p = computeRefundPlan({ ...base, depositPaymongoPaymentID: "pay_d", balanceCollected: true, balanceCollectedAmount: 2000 }, { forfeit: 1000 });
  assert.equal(p.total, 4000); assert.equal(p.parts[0].amount, 2000); assert.equal(p.manualAmount, 2000);
});
test("plan: total is always parts + manual (what the customer is actually promised)", () => {
  for (const extra of [{ depositPaymongoPaymentID: "x" }, { paymongoChannel: "gcash" }, { paymentMethod: "Cash", confirmedBy: "s" }, { depositPaymongoPaymentID: "x", balanceStatus: "paid" }, { depositPaymongoPaymentID: "x", balanceCollected: true, balanceCollectedAmount: 2000, discountAmount: 300 }]) {
    const p = computeRefundPlan({ ...base, ...extra });
    assert.equal(p.total, p.parts.reduce((s, x) => s + x.amount, 0) + p.manualAmount, JSON.stringify(extra));
    assert.equal(p.total + p.unrefundableAmount, p.grossPaid - p.forfeit);
  }
});
test("plan: a refunded / unpaid payment yields nothing", () => {
  assert.equal(computeRefundPlan({ ...base, status: "refunded" }).total, 0);
  const pending = computeRefundPlan({ ...base, status: "pending" });
  assert.equal(pending.total, 0); assert.equal(pending.unrefundableAmount, 0);
});

// ── refund rows ──
const approved = {
  refundRequestID: "rr1", paymentID: "p1", bookingID: "b1", userID: "u1", status: "Approved", processedBy: "admin1", processedAt: D("2026-09-20"), createdAt: D("2026-09-19"), updatedAt: D("2026-09-20"),
  parts: [{ kind: "deposit", paymongoPaymentID: "pay_d", amount: 3000, paymongoRefundID: "re_1", status: "pending" }],
  manualRefund: { amount: 2000, issued: false, issuedBy: null, issuedAt: null, method: null },
  unrefundable: [{ kind: "balance", amount: 500, reason: "payment_id_missing" }], unrefundableAmount: 500,
};
test("refund rows: online part, in-person hand-back and unrefundable each get a row", () => {
  const { entries } = buildRefundEntries(approved, "rr1", { now: NOW, payment: { balanceCollected: true } });
  assert.deepEqual(entries.map((e) => e.paymentEntryID), ["rr1_part1", "rr1_manual", "rr1_unrefundable1"]);
  const [part, manual, unref] = entries;
  assert.equal(part.direction, "out"); assert.equal(part.source, "online"); assert.equal(part.referenceNumber, "re_1"); assert.equal(part.parentEntryID, "p1_deposit"); assert.equal(part.status, "pending");
  assert.equal(manual.source, "in_person"); assert.equal(manual.phase, "balance"); assert.equal(manual.status, "pending"); assert.equal(manual.parentEntryID, null);
  assert.equal(unref.status, "unrefundable"); assert.equal(unref.note, PAYMENT_ID_MISSING_NOTE); assert.deepEqual(unref.flags, ["payment_id_missing"]); assert.equal(unref.parentEntryID, "p1_balance");
  for (const e of entries) for (const [k, v] of Object.entries(e)) assert.notEqual(v, undefined, `${e.paymentEntryID}.${k}`);
});
test("refund rows: results move the rows, a hand-back becomes success with who/when/method", () => {
  const done = { ...approved, status: "Refunded", parts: [{ ...approved.parts[0], status: "succeeded" }], manualRefund: { amount: 2000, issued: true, issuedBy: "s7", issuedAt: D("2026-09-22"), method: "Cash" } };
  const { entries } = buildRefundEntries(done, "rr1", { now: NOW });
  assert.equal(entries[0].status, "success"); assert.equal(entries[1].status, "success");
  assert.equal(entries[1].processedBy, "s7"); assert.equal(entries[1].method, "cash"); assert.deepEqual(entries[1].settledAt, D("2026-09-22"));
});
test("refund rows: a failed part keeps its error; a Pending / Rejected request has no rows", () => {
  const failed = { ...approved, status: "Failed", manualRefund: null, unrefundable: [], parts: [approved.parts[0], { kind: "balance", amount: 2000, paymongoRefundID: null, status: "failed", error: "insufficient balance" }] };
  const { entries } = buildRefundEntries(failed, "rr1", { now: NOW });
  assert.equal(entries[1].status, "failed"); assert.equal(entries[1].note, "insufficient balance"); assert.equal(entries[1].referenceNumber, null);
  assert.equal(buildRefundEntries({ refundRequestID: "r", status: "Pending", parts: [], manualRefund: null }, "r").entries.length, 0);
  assert.equal(buildRefundEntries({ refundRequestID: "r", status: "Rejected" }, "r").entries.length, 0);
});
test("refund rows: an old request with only paymongoRefundID is one part", () => {
  const legacy = { refundRequestID: "old", paymentID: "p1", status: "Refunded", paymongoRefundID: "re_old", amount: 4000, onlineAmount: 4000, updatedAt: D("2026-05-01") };
  const { entries } = buildRefundEntries(legacy, "old", { now: NOW });
  assert.equal(entries.length, 1); assert.equal(entries[0].amount, 4000); assert.equal(entries[0].status, "success"); assert.equal(entries[0].referenceNumber, "re_old");
});
test("refund merge: success is never undone, settledAt is stamped once and kept", () => {
  const built = buildRefundEntries({ ...approved, parts: [{ ...approved.parts[0], status: "succeeded" }] }, "rr1", { now: NOW }).entries[0];
  const first = mergeRefundEntry(null, { ...built, settledAt: null }, { now: NOW });
  assert.deepEqual(first.settledAt, NOW);
  assert.equal(mergeRefundEntry({ status: "success", settledAt: NOW }, { ...built, status: "pending" }), null);
  const later = mergeRefundEntry({ status: "success", settledAt: NOW }, { ...built, status: "success", settledAt: D("2030-01-01") }, { now: D("2031-01-01") });
  assert.deepEqual(later.settledAt, NOW);
});
test("refund hydrate: parts / manualRefund / unrefundable come back from the rows", () => {
  const rows = buildRefundEntries({ ...approved, status: "Refunded", parts: [{ ...approved.parts[0], status: "succeeded" }], manualRefund: { amount: 2000, issued: true, issuedBy: "s7", issuedAt: D("2026-09-22"), method: "Cash" } }, "rr1", { now: NOW }).entries;
  const stripped = { ...approved }; for (const k of ["parts", "manualRefund", "unrefundable", "unrefundableAmount", "paymongoRefundID", "paymongoRefundIDs"]) delete stripped[k];
  const h = hydrateRefundRequest(stripped, rows);
  assert.deepEqual(h.parts.map((p) => [p.kind, p.amount, p.paymongoRefundID, p.status]), [["deposit", 3000, "re_1", "succeeded"]]);
  assert.deepEqual(h.paymongoRefundIDs, ["re_1"]); assert.equal(h.paymongoRefundID, "re_1");
  assert.deepEqual([h.manualRefund.amount, h.manualRefund.issued, h.manualRefund.method], [2000, true, "Cash"]);
  assert.equal(h.unrefundableAmount, 500); assert.equal(h.unrefundable[0].kind, "balance");
  assert.equal(hydrateRefundRequest(approved, rows).parts, approved.parts);   // a request that still has them is unchanged
});

// ── database: sync + migration ──
test("syncRefundEntries mirrors a request, follows webhook results, never throws", async () => {
  const fake = makeFakeDb({ refundRequests: { rr1: approved }, payments: { p1: { ...base } } });
  const svc = makeEntriesDb(fake.db);
  assert.deepEqual(await svc.syncRefundEntries("rr1"), { written: 3 });
  assert.equal(fake.raw("paymentEntries").get("rr1_part1").status, "pending");
  await fake.db.collection("refundRequests").doc("rr1").update({ parts: [{ ...approved.parts[0], status: "succeeded" }] });   // the webhook
  assert.deepEqual(await svc.syncRefundEntries("rr1"), { written: 3 });
  const row = fake.raw("paymentEntries").get("rr1_part1");
  assert.equal(row.status, "success"); assert.ok(row.settledAt);
  await fake.db.collection("refundRequests").doc("rr1").update({ parts: [{ ...approved.parts[0], status: "pending" }] });     // a stale event
  await svc.syncRefundEntries("rr1");
  assert.equal(fake.raw("paymentEntries").get("rr1_part1").status, "success");
  assert.deepEqual(await svc.syncRefundEntries("nope"), { written: 0 });
  assert.equal((await makeEntriesDb({ collection() { throw new Error("x"); } }).syncRefundEntries("rr1")).written, 0);
});

const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), "pe-r-"));
const seed = () => ({
  payments: { p1: { ...base, depositPaymongoPaymentID: "pay_d", paymongoChannel: "gcash", paidAt: D("2026-09-01"), createdAt: D("2026-08-30") } },
  refundRequests: {
    rr1: approved,
    rrPending: { refundRequestID: "rrPending", paymentID: "p1", status: "Pending", parts: [], manualRefund: null, createdAt: D("2026-09-25") },
    rrOld: { refundRequestID: "rrOld", paymentID: "p1", status: "Refunded", paymongoRefundID: "re_old", amount: 4000, onlineAmount: 4000, updatedAt: D("2026-05-01") },
  },
  refundArchives: { a1: { refundArchivesId: "a1", originalId: "rrX", refundRequestID: "rrX", paymentID: "p1", status: "Refunded", parts: [{ kind: "deposit", amount: 100, paymongoRefundID: "re_x", status: "succeeded" }], processedAt: D("2026-01-01"), updatedAt: D("2026-01-02") } },
});
let tick = 0;   // each run gets its own timestamp, like real runs do, so reports don't overwrite each other
const run = (fake, args, dir) => migrate({ db: fake.db, FieldValue: fake.FieldValue, argv: args, log: () => {}, now: new Date(NOW.getTime() + (++tick) * 1000), outDir: dir });

test("migration builds refund rows (live + archived), skips Pending, is idempotent, rolls back, and the checker verifies them", async () => {
  const fake = makeFakeDb(seed()); const dir = tmp();
  const dry = await run(fake, [], dir);
  assert.equal(fake.count("paymentEntries"), 0);
  assert.equal(dry.refunds.scanned, 4); assert.equal(dry.refunds.withRows, 3);        // the Pending one has none
  const out = await run(fake, ["--write"], dir);
  const ids = [...fake.raw("paymentEntries").keys()].filter((i) => /^rr|^rrX|^rrOld/.test(i)).sort();
  assert.deepEqual(ids, ["rr1_manual", "rr1_part1", "rr1_unrefundable1", "rrOld_part1", "rrX_part1"]);
  assert.equal(out.entries.byDirection.out, 5);
  assert.deepEqual(out.flagged.payment_id_missing, ["p1"]);
  assert.deepEqual(out.refunds.pendingHandBacks, ["rr1"]);
  assert.equal(fake.raw("paymentEntries").get("rrX_part1").migratedFrom, "refundArchives.legacy");
  const again = await run(fake, ["--write"], dir);
  assert.equal(again.entries.created, 0);
  const chk = await check({ db: fake.db, log: () => {} });
  assert.equal(chk.verify.refundMissing.length, 0); assert.equal(chk.verify.refundDifferent.length, 0);
  assert.deepEqual(chk.problems.refundUnrefundable, ["rr1"]);
  await fake.db.collection("paymentEntries").doc("rr1_part1").update({ amount: 1 });
  assert.equal((await check({ db: fake.db, log: () => {} })).verify.refundDifferent.length, 1);
  await run(fake, [`--rollback=${out.file}`, "--write"], dir);
  assert.equal([...fake.raw("paymentEntries").keys()].filter((i) => i.startsWith("rr")).length, 0);
});

// ── the customer (CommonJS) copy must agree ──
const HERE = path.dirname(fileURLToPath(import.meta.url));
const CUSTOMER = process.env.CUSTOMER_BACKEND || path.join(HERE, "..", "..", "arltrack-customer-backend");
const skip = fs.existsSync(path.join(CUSTOMER, "utils", "payments", "paymentEntries.mapper.js")) ? false : "customer backend not found";
test("customer copy: same refund plan and same refund rows as the admin copy", { skip }, () => {
  const req = createRequire(import.meta.url);
  const cb = req(path.join(CUSTOMER, "utils/payments/paymentBreakdown.util.js"));
  const cm = req(path.join(CUSTOMER, "utils/payments/paymentEntries.mapper.js"));
  const scenarios = [{ depositPaymongoPaymentID: "x", paymongoChannel: "gcash" }, { paymongoChannel: "gcash" }, { paymentMethod: "Cash", confirmedBy: "s" }, { depositPaymongoPaymentID: "x", balanceStatus: "paid" }, { depositPaymongoPaymentID: "x", balanceCollected: true, balanceCollectedAmount: 2000, discountAmount: 300 }];
  for (const s of scenarios) for (const forfeit of [0, 1000]) assert.deepEqual(cb.computeRefundPlan({ ...base, ...s }, { forfeit }), computeRefundPlan({ ...base, ...s }, { forfeit }), JSON.stringify(s));
  assert.deepEqual(cm.buildRefundEntries(approved, "rr1", { now: NOW }), buildRefundEntries(approved, "rr1", { now: NOW }));
});
