// Run:  node --test tests/paymentEntries.mapper.test.mjs      (from arltrack-admin-backend/)
import test from "node:test";
import assert from "node:assert/strict";
import {
  buildPaymentEntries, buildLegacyPenaltyEntry, buildPenaltyPaymentEntry,
  mergeEntry, hydratePayment, hydratePenalty, nullIfSentinel, normalizeMethod,
} from "../services/paymentEntries/paymentEntries.mapper.js";

const NOW = new Date("2026-10-01T00:00:00Z");
const T = (s) => new Date(s);

// Partial: 5000 total, 1000 security deposit -> deposit 1000 + floor(4000/2) = 3000, balance 2000.
const partial = (extra = {}) => ({
  paymentID: "pay1", bookingID: "bk1", userID: "u1", amount: 5000, securityDeposit: 1000,
  methodOfPayment: "Partial", paymentMethod: "PayMongo", referenceNumber: "N/A",
  status: "paid", paidAt: T("2026-09-01"), createdAt: T("2026-08-30"),
  depositPaymongoPaymentID: "pay_dep", depositPaymongoFee: 75, paymongoChannel: "gcash",
  balanceStatus: "not_due", currentPhase: "deposit", ...extra,
});
const full = (extra = {}) => ({
  paymentID: "pay2", bookingID: "bk2", userID: "u2", amount: 4000, securityDeposit: 500,
  methodOfPayment: "Full", status: "paid", paidAt: T("2026-09-01"), createdAt: T("2026-08-30"),
  depositPaymongoPaymentID: "pay_full", paymongoChannel: "paymaya", balanceStatus: "not_applicable", ...extra,
});
const build = (p, id = p.paymentID) => buildPaymentEntries(p, id, { now: NOW });
const by = (r, phase) => r.entries.find((e) => e.phase === phase);

test("sentinels become null, real values survive", () => {
  for (const s of ["N/A", "n/a", "—", "", "  ", null, undefined]) assert.equal(nullIfSentinel(s), null);
  assert.equal(nullIfSentinel(" 12345 "), "12345");
});

test("card is not a method any more: it surfaces as unmapped instead of being silently accepted", () => {
  assert.deepEqual(normalizeMethod("card"), { method: null, unmapped: "card" });
});

test("method labels normalize; non-methods are not 'unmapped'", () => {
  assert.equal(normalizeMethod("paymaya").method, "maya");
  assert.equal(normalizeMethod("Bank Transfer").method, "bank_transfer");
  assert.equal(normalizeMethod("InStore").method, "cash");
  assert.deepEqual(normalizeMethod("PayMongo"), { method: null, unmapped: null });
  assert.deepEqual(normalizeMethod("Bitcoin"), { method: null, unmapped: "Bitcoin" });
});

test("Full, online, paid: one deposit row, no balance row", () => {
  const r = build(full());
  assert.equal(r.entries.length, 1);
  const d = by(r, "deposit");
  assert.equal(d.paymentEntryID, "pay2_deposit");
  assert.equal(d.source, "online"); assert.equal(d.method, "maya"); assert.equal(d.status, "success");
  assert.equal(d.amount, 4000); assert.equal(d.referenceNumber, "pay_full");
  assert.deepEqual(d.flags, []);
  assert.equal(r.skipped.find((s) => s.phase === "balance").reason, "no_balance_phase");
});

test("Partial: deposit paid online, balance not due -> deposit row only, balance skipped", () => {
  const r = build(partial());
  assert.equal(r.entries.length, 1);
  assert.equal(by(r, "deposit").amount, 3000);
  assert.equal(r.skipped.find((s) => s.phase === "balance").reason, "not_due");
});

test("Partial: balance paid online -> second row with its own pay_ id and fee", () => {
  const r = build(partial({ balanceStatus: "paid", balancePaymongoPaymentID: "pay_bal", balancePaymongoFee: 50, balancePaidAt: T("2026-09-05"), currentPhase: "balance", paymongoSessionID: "cs_1" }));
  const b = by(r, "balance");
  assert.equal(b.amount, 2000); assert.equal(b.referenceNumber, "pay_bal"); assert.equal(b.transactionFee, 50);
  assert.equal(b.sessionID, "cs_1"); assert.equal(by(r, "deposit").sessionID, null);   // session belongs to the balance phase
  assert.deepEqual(b.flags, []);
});

test("Partial: balance collected in person, with a recorded amount and '—' staff", () => {
  const r = build(partial({ balanceCollected: true, balanceCollectedAmount: 1800, balanceMethod: "Cash", balanceCollectedBy: "—", balanceCollectedAt: T("2026-09-06"), discountAmount: 200 }));
  const b = by(r, "balance");
  assert.equal(b.source, "in_person"); assert.equal(b.method, "cash"); assert.equal(b.amount, 1800);
  assert.equal(b.processedBy, null);          // "—" -> null
  assert.deepEqual(b.flags, []);              // amount was recorded, so no review needed
});

test("balance collected without a recorded amount + a discount -> flagged for review", () => {
  const r = build(partial({ balanceCollected: true, balanceMethod: "GCash", discountAmount: 300 }));
  assert.deepEqual(by(r, "balance").flags.sort(), ["amount_inferred", "discount_review"]);
});

test("online success with no payment id is flagged (the 'Payment ID does not exist' case)", () => {
  const r = build(full({ depositPaymongoPaymentID: undefined, paymongoPaymentID: undefined }));
  assert.ok(by(r, "deposit").flags.includes("missing_payment_id"));
  const r2 = build(partial({ balanceStatus: "paid", balancePaidAt: T("2026-09-05") }));
  assert.ok(by(r2, "balance").flags.includes("missing_payment_id"));
});

test("cash deposit confirmed by staff: in person, reference 'N/A' -> null", () => {
  const r = build({ paymentID: "p3", bookingID: "b3", userID: "u3", amount: 3000, methodOfPayment: "Full", status: "Approved", paymentMethod: "Cash", referenceNumber: "N/A", confirmedBy: "staff1", confirmedAt: T("2026-09-02"), createdAt: T("2026-09-01") });
  const d = by(r, "deposit");
  assert.equal(d.source, "in_person"); assert.equal(d.method, "cash"); assert.equal(d.referenceNumber, null);
  assert.equal(d.processedBy, "staff1"); assert.equal(d.status, "success"); assert.deepEqual(d.flags, []);
});

test("a deposit nobody started paying is not a row", () => {
  const r = build({ paymentID: "p4", amount: 3000, methodOfPayment: "Full", status: "pending", paymentMethod: "", referenceNumber: "N/A" });
  assert.equal(r.entries.length, 0);
  assert.equal(r.skipped[0].reason, "not_started");
});

test("pending with an open checkout session -> pending online row", () => {
  const r = build({ paymentID: "p5", amount: 3000, methodOfPayment: "Full", status: "pending", paymongoSessionID: "cs_9", paymongoChannel: "gcash", currentPhase: "deposit" });
  const d = by(r, "deposit");
  assert.equal(d.status, "pending"); assert.equal(d.sessionID, "cs_9"); assert.equal(d.source, "online");
});

test("balance amount comes from what the checkout really charged (old array) when known", () => {
  const r = build(partial({ balanceStatus: "pending", discountAmount: 500, paymongoTransactions: [{ phase: "balance", amount: 1500 }] }));
  const b = by(r, "balance");
  assert.equal(b.amount, 1500); assert.ok(!b.flags.includes("discount_review"));
});

test("balance paid online with a discount and no recorded charge -> discount_review", () => {
  const r = build(partial({ balanceStatus: "paid", balancePaymongoPaymentID: "pay_b", discountAmount: 500 }));
  assert.ok(by(r, "balance").flags.includes("discount_review"));
});

test("refunded legacy payment: row is success + refunded_legacy", () => {
  const d = by(build(full({ status: "refunded" })), "deposit");
  assert.equal(d.status, "success"); assert.ok(d.flags.includes("refunded_legacy"));
});

test("failed and cancelled map correctly", () => {
  assert.equal(by(build(partial({ status: "failed", depositPaymongoPaymentID: undefined })), "deposit").status, "failed");
  assert.equal(by(build(partial({ balanceStatus: "cancelled" })), "balance").status, "cancelled");
});

test("every entry is Firestore-safe: no undefined anywhere", () => {
  const cases = [full(), partial(), partial({ balanceStatus: "pending" }), partial({ balanceCollected: true, balanceMethod: "Cash" })];
  for (const c of cases) for (const e of build(c).entries) for (const [k, v] of Object.entries(e)) assert.notEqual(v, undefined, `${e.paymentEntryID}.${k}`);
});

test("deterministic: building twice gives identical ids and values", () => {
  assert.deepEqual(build(partial()), build(partial()));
});

// ── penalties ──
const pen = (extra = {}) => ({ penaltyID: "pen1", bookingID: "bk1", paymentID: "pay1", userID: "u1", amount: 500, paidAmount: 500, paymentMethod: "InStore", referenceNumber: "OR-77", paidAt: T("2026-09-10"), status: "Confirmed", ...extra });

test("penalty paid in store -> one legacy_aggregate row", () => {
  const { entry } = buildLegacyPenaltyEntry(pen(), "pen1", { deposit: {} }, { now: NOW });
  assert.equal(entry.paymentEntryID, "pen1_legacy"); assert.equal(entry.phase, "penalty");
  assert.equal(entry.refCollection, "penalties"); assert.equal(entry.method, "cash"); assert.equal(entry.source, "in_person");
  assert.equal(entry.amount, 500); assert.equal(entry.referenceNumber, "OR-77"); assert.ok(entry.flags.includes("legacy_aggregate"));
});
test("penalty covered by the deposit -> no row (no money moved)", () => {
  assert.deepEqual(buildLegacyPenaltyEntry(pen({ paymentMethod: "Deposit" }), "pen1", null, { now: NOW }), { review: "deposit_offset" });
});
test("penalty on a booking whose deposit was settled -> review, never guessed", () => {
  const payment = { deposit: { settlement: { status: "OwedByCustomer" } } };
  assert.deepEqual(buildLegacyPenaltyEntry(pen(), "pen1", payment, { now: NOW }), { review: "deposit_involved" });
  assert.deepEqual(buildLegacyPenaltyEntry(pen({ paymentMethod: "DepositPartial" }), "pen1", null, { now: NOW }), { review: "deposit_involved" });
});
test("unpaid penalty -> nothing", () => {
  assert.deepEqual(buildLegacyPenaltyEntry(pen({ paidAmount: 0 }), "pen1", null, { now: NOW }), {});
});
test("voided penalty that had money is flagged", () => {
  const { entry } = buildLegacyPenaltyEntry(pen({ status: "Voided" }), "pen1", null, { now: NOW });
  assert.ok(entry.flags.includes("penalty_voided"));
});
test("a new penalty payment row", () => {
  const e = buildPenaltyPaymentEntry({ penalty: pen(), penaltyID: "pen1", amount: 300, method: "GCash", referenceNumber: "", processedBy: "sup1", groupID: "g1", now: NOW });
  assert.equal(e.method, "gcash"); assert.equal(e.referenceNumber, null); assert.equal(e.groupID, "g1"); assert.equal(e.processedBy, "sup1");
  for (const [k, v] of Object.entries(e)) assert.notEqual(v, undefined, k);
});

// ── merge rules ──
test("mergeEntry: new row is written whole; success is never downgraded; createdAt is kept", () => {
  const built = build(full()).entries[0];
  assert.equal(mergeEntry(null, built), built);
  assert.equal(mergeEntry({ status: "success" }, { ...built, status: "pending" }), null);
  const forced = mergeEntry({ status: "success" }, { ...built, status: "failed" }, { force: true });
  assert.equal(forced.status, "failed");
  const patch = mergeEntry({ status: "pending" }, built);
  assert.ok(!("createdAt" in patch) && !("paymentEntryID" in patch) && !("migratedFrom" in patch));
});

// ── the compat guarantee ──
test("hydratePayment restores every moved field, so the legacy ones can be removed", () => {
  const original = partial({
    balanceStatus: "paid", balancePaymongoPaymentID: "pay_bal", balancePaymongoFee: 50, balancePaidAt: T("2026-09-05"),
    paymongoPaymentID: "pay_bal", paymongoSessionID: "cs_1", currentPhase: "balance", proofUrl: "http://x/y.png",
  });
  const rows = build(original).entries;
  const stripped = { ...original };
  for (const k of ["depositPaymongoPaymentID", "balancePaymongoPaymentID", "depositPaymongoFee", "balancePaymongoFee", "paymongoChannel", "proofUrl", "paidAt", "balancePaidAt", "paymongoSessionID", "paymongoPaymentID"]) delete stripped[k];
  const h = hydratePayment(stripped, rows);
  for (const k of ["depositPaymongoPaymentID", "balancePaymongoPaymentID", "depositPaymongoFee", "balancePaymongoFee", "paymongoChannel", "proofUrl", "paidAt", "balancePaidAt", "paymongoSessionID", "paymongoPaymentID"]) {
    assert.deepEqual(h[k], original[k], k);
  }
  // and re-deriving from the hydrated doc gives the same rows (round trip)
  const again = build(h).entries.map(({ updatedAt, ...r }) => r);
  assert.deepEqual(again, rows.map(({ updatedAt, ...r }) => r));
});

test("hydratePayment restores in-person fields", () => {
  const original = { paymentID: "p9", bookingID: "b9", amount: 5000, securityDeposit: 1000, methodOfPayment: "Partial", status: "Approved", paymentMethod: "Cash", referenceNumber: "OR-1", confirmedBy: "s1", confirmedAt: T("2026-09-02"), paidAt: T("2026-09-02"), balanceCollected: true, balanceCollectedAmount: 2000, balanceMethod: "Cash", balanceCollectedBy: "s2", balanceCollectedAt: T("2026-09-07"), createdAt: T("2026-09-01") };
  const rows = build(original).entries;
  const stripped = { ...original };
  for (const k of ["confirmedBy", "confirmedAt", "balanceMethod", "balanceCollectedBy", "balanceCollectedAt"]) delete stripped[k];
  const h = hydratePayment(stripped, rows);
  for (const k of ["confirmedBy", "confirmedAt", "balanceMethod", "balanceCollectedBy", "balanceCollectedAt"]) assert.deepEqual(h[k], original[k], k);
});

test("hydratePayment never overwrites a value the payment already has", () => {
  const rows = build(full()).entries;
  assert.equal(hydratePayment({ ...full(), proofUrl: "keep-me" }, rows).proofUrl, "keep-me");
});

test("hydratePenalty: from rows, or 'Deposit' when paid with no rows", () => {
  const rows = [{ ...buildLegacyPenaltyEntry(pen(), "pen1", null, { now: NOW }).entry }];
  const h = hydratePenalty({ ...pen(), paymentMethod: "", referenceNumber: "", paidAt: null }, rows);
  assert.equal(h.paymentMethod, "InStore"); assert.equal(h.referenceNumber, "OR-77");
  assert.equal(hydratePenalty({ ...pen(), paymentMethod: "", paidAt: null }, []).paymentMethod, "Deposit");
});
