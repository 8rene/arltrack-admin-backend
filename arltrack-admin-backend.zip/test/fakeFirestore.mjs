// Minimal in-memory Firestore: just what the paymentEntries code uses.
export const makeFakeDb = (seed = {}) => {
  const cols = new Map();
  const getCol = (n) => { if (!cols.has(n)) cols.set(n, new Map()); return cols.get(n); };
  for (const [name, rows] of Object.entries(seed)) for (const [id, d] of Object.entries(rows)) getCol(name).set(id, structuredClone(d));

  const DEL = Symbol("delete");
  const FieldValue = { delete: () => DEL };
  let auto = 0;

  const applyUpdate = (name, id, patch) => {
    const m = getCol(name);
    if (!m.has(id)) throw new Error(`NOT_FOUND: ${name}/${id}`);
    const cur = { ...m.get(id) };
    for (const [k, v] of Object.entries(patch)) { if (v === DEL) delete cur[k]; else cur[k] = v instanceof Date ? new Date(v) : structuredClone(v); }
    m.set(id, cur);
  };
  const snapOf = (name, id, ref) => { const m = getCol(name); return { id, exists: m.has(id), ref, data: () => (m.has(id) ? structuredClone(m.get(id)) : undefined) }; };
  const mkRef = (name, id) => {
    const ref = { id, path: `${name}/${id}`, _name: name };
    ref.get = async () => snapOf(name, id, ref);
    ref.set = async (d) => { getCol(name).set(id, structuredClone(d)); };
    ref.update = async (p) => applyUpdate(name, id, p);
    ref.delete = async () => { getCol(name).delete(id); };
    return ref;
  };
  const query = (name, filters, max = null) => ({
    where: (f, op, v) => query(name, [...filters, [f, op, v]], max),
    limit: (n) => query(name, filters, n),
    get: async () => {
      let docs = [...getCol(name).entries()]
        .filter(([, d]) => filters.every(([f, op, v]) => (op === "==" ? d[f] === v : op === "in" ? v.includes(d[f]) : false)))
        .map(([id]) => snapOf(name, id, mkRef(name, id)));
      if (max !== null) docs = docs.slice(0, max);
      return { docs, empty: docs.length === 0, size: docs.length };
    },
  });
  const db = {
    collection: (name) => ({ doc: (id) => mkRef(name, id || `auto${++auto}`), ...query(name, []) }),
    getAll: async (...refs) => Promise.all(refs.map((r) => r.get())),
    batch: () => {
      const ops = [];
      return {
        set: (ref, d) => ops.push(() => ref.set(d)),
        update: (ref, p) => ops.push(() => ref.update(p)),
        delete: (ref) => ops.push(() => ref.delete()),
        commit: async () => { for (const op of ops) await op(); },
      };
    },
  };
  return { db, FieldValue, raw: (name) => getCol(name), count: (name) => getCol(name).size };
};
