// Proves the generated customer (CommonJS) copy builds EXACTLY the same rows as the admin (ESM) one,
// using the customer's own paymentBreakdown copy. Skipped if the customer repo isn't next to this one.
//   CUSTOMER_BACKEND=/path/to/arltrack-customer-backend node --test tests/customerMirror.parity.test.mjs
import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { createRequire } from "node:module";
import { fileURLToPath } from "node:url";
import * as admin from "../services/paymentEntries/paymentEntries.mapper.js";
import { makeFakeDb } from "./fakeFirestore.mjs";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const CUSTOMER = process.env.CUSTOMER_BACKEND || path.join(HERE, "..", "..", "arltrack-customer-backend");
const have = fs.existsSync(path.join(CUSTOMER, "utils", "payments", "paymentEntries.mapper.js"));
const skip = have ? false : "customer backend not found next to admin (set CUSTOMER_BACKEND)";
const req = createRequire(import.meta.url);

const D = (s) => new Date(s); const NOW = new Date("2026-10-01T00:00:00Z");
const docs = [
  { paymentID: "a", bookingID: "b", userID: "u", amount: 4000, securityDeposit: 500, methodOfPayment: "Full", status: "paid", paidAt: D("2026-09-01"), createdAt: D("2026-08-30"), depositPaymongoPaymentID: "pay_a", paymongoChannel: "paymaya", depositPaymongoFee: 60, balanceStatus: "not_applicable" },
  { paymentID: "b", bookingID: "b", userID: "u", amount: 5000, securityDeposit: 1000, methodOfPayment: "Partial", status: "paid", createdAt: D("2026-08-30"), depositPaymongoPaymentID: "pay_d", paymongoChannel: "gcash", balanceStatus: "paid", balancePaymongoPaymentID: "pay_b", balancePaidAt: D("2026-09-05"), discountAmount: 300, currentPhase: "balance", paymongoSessionID: "cs_1" },
  { paymentID: "c", amount: 5000, securityDeposit: 1000, methodOfPayment: "Partial", status: "Approved", paymentMethod: "GCash", referenceNumber: "N/A", confirmedBy: "s1", confirmedAt: D("2026-09-02"), balanceCollected: true, balanceCollectedAmount: 2000, balanceMethod: "Cash", balanceCollectedBy: "—", balanceCollectedAt: D("2026-09-09") },
  { paymentID: "d", amount: 3000, methodOfPayment: "Full", status: "paid", paymongoChannel: "gcash" },
  { paymentID: "e", amount: 3000, methodOfPayment: "Full", status: "pending" },
  { paymentID: "f", amount: 3000, methodOfPayment: "Full", status: "refunded", depositPaymongoPaymentID: "pay_f", paymongoChannel: "qrph" },
];
const pens = [
  { penaltyID: "p1", bookingID: "b", paymentID: "a", userID: "u", amount: 500, paidAmount: 500, paymentMethod: "InStore", referenceNumber: "OR-1", paidAt: D("2026-09-10"), status: "Confirmed" },
  { penaltyID: "p2", amount: 300, paidAmount: 300, paymentMethod: "Deposit" },
];

test("customer copy builds identical payment rows", { skip }, () => {
  const cust = req(path.join(CUSTOMER, "utils/payments/paymentEntries.mapper.js"));
  for (const d of docs) assert.deepEqual(cust.buildPaymentEntries(d, d.paymentID, { now: NOW }), admin.buildPaymentEntries(d, d.paymentID, { now: NOW }), d.paymentID);
});
test("customer copy builds identical penalty rows and review reasons", { skip }, () => {
  const cust = req(path.join(CUSTOMER, "utils/payments/paymentEntries.mapper.js"));
  for (const p of pens) assert.deepEqual(cust.buildLegacyPenaltyEntry(p, p.penaltyID, null, { now: NOW }), admin.buildLegacyPenaltyEntry(p, p.penaltyID, null, { now: NOW }), p.penaltyID);
});
test("customer copy hydrates identically", { skip }, () => {
  const cust = req(path.join(CUSTOMER, "utils/payments/paymentEntries.mapper.js"));
  const rows = admin.buildPaymentEntries(docs[1], "b", { now: NOW }).entries;
  const stripped = { ...docs[1] }; delete stripped.depositPaymongoPaymentID; delete stripped.balancePaidAt;
  assert.deepEqual(cust.hydratePayment(stripped, rows), admin.hydratePayment(stripped, rows));
});
test("customer core syncs against a database and never throws", { skip }, async () => {
  const { makeEntriesDb } = req(path.join(CUSTOMER, "utils/payments/paymentEntries.core.js"));
  const fake = makeFakeDb({ payments: { a: docs[0] } });
  const svc = makeEntriesDb(fake.db);
  assert.deepEqual(await svc.syncPaymentEntries("a"), { written: 1 });
  assert.equal(fake.raw("paymentEntries").get("a_deposit").method, "maya");
  assert.equal((await makeEntriesDb({ collection() { throw new Error("x"); } }).syncPaymentEntries("a")).written, 0);
});
