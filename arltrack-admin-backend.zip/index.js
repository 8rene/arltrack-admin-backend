import "dotenv/config";
import express from "express";
import cors from "cors";
import { registerAuthRoutes }                from "./routes/auth/auth.routes.js";
import { registerDashboardRoutes }           from "./routes/dashboard/dashboard.routes.js";
import { registerBookingRoutes }             from "./routes/booking/booking.routes.js";
import { registerUserRoutes }                from "./routes/user/user.routes.js";
import { registerAuditLogsRoutes }           from "./routes/auditLogs/auditLogs.routes.js";
import { registerSessionLogsRoutes }         from "./routes/sessionLogs/sessionLogs.routes.js";
import { registerGpsRoutes }                 from "./routes/gps/gps.routes.js";
import { registerReportsRoutes }             from "./routes/reports/reports.routes.js"; //
import { registerPaymentsRoutes }          from "./routes/payments/payments.routes.js";//
import { registerTransactionLogsRoutes }     from "./routes/transactionLogs/transactionLogs.routes.js";
import { registerInventoryRoutes }           from "./routes/inventory/inventory.routes.js";
import { registerVehicleDocsRoutes }         from "./routes/vehicleDocumentation/vehicleDocumentation.routes.js";
import { registerFleetRoutes }               from "./routes/fleet/fleet.routes.js"; // ← NEW
import { registerRefundRequestRoutes }       from "./routes/refundRequest/refundRequest.routes.js"; // ← NEW
import { registerLocationRoutes }            from "./routes/location/location.routes.js"; // ← NEW
// bookingWatcher.js removed — nothing in either backend or frontend
// currently sets a booking to "cancellation_request", so this watcher
// was doing nothing. If that feature gets built later, it should be
// direct-write (same pattern as new_user / refund_request), not a
// revived watcher — watchers aren't reliable on this Vercel serverless
// deployment (see conversation notes / commit history for why).
import { registerSessionLogArchiveRoutes }     from "./routes/archives/sessionLogArchiveRoutes.js";
import { registerPaymentsArchiveRoutes }       from "./routes/archives/paymentsArchiveRoutes.js";
import { registerBookingArchiveRoutes }        from "./routes/archives/bookingArchiveRoutes.js";
import { registerTransactionLogArchiveRoutes } from "./routes/archives/transactionLogArchiveRoutes.js";
import { registerRefundArchiveRoutes }         from "./routes/archives/refundArchiveRoutes.js"; // ← NEW
import { registerAuditLogsArchiveRoutes }      from "./routes/archives/auditLogsArchiveRoutes.js";
import { registerReviewsArchiveRoutes }        from "./routes/archives/reviewsArchiveRoutes.js";
import { registerBookingSessionArchiveRoutes } from "./routes/archives/bookingSessionArchiveRoutes.js";
import { registerUserArchiveRoutes }           from "./routes/archives/userArchiveRoutes.js"; // ← NEW
import { registerCronRoutes }                  from "./routes/cron/cron.routes.js";
import { registerMaintenanceRoutes }           from "./routes/maintenance/maintenance.routes.js"; // ← NEW
import { registerCarPartsRoutes }              from "./routes/carParts/carParts.routes.js"; // ← NEW
import { registerReviewsRoutes }               from "./routes/reviews/reviews.routes.js"; // ← NEW
import { registerProfileRequestsRoutes }       from "./routes/profileRequests/profileRequests.routes.js"; // ← NEW
import { registerDriverDispatchRoutes }        from "./routes/driverDispatch/driverDispatch.routes.js"; // ← NEW
import { registerSystemSettingsRoutes }       from "./routes/systemSettings/systemSettings.routes.js"; // ← NEW
import { registerLocationOptionsRoutes }       from "./routes/locationOptions/locationOptions.routes.js"; // ← NEW
import { seedCacheFromFirestore }            from "./services/gps/gps.service.js";

const app = express();

// Fixed production origin + any localhost port — the second part matters
// because `flutter run -d chrome` (no --web-port flag) picks a random
// free port each time, so a fixed array like ['http://localhost:3000']
// only works if that exact port happens to be free. Still safe: this
// only widens things for localhost, nothing else gets in past the
// explicit whitelist below.
const PROD_ORIGINS = ['https://arltrack-admin-frontend.vercel.app'];
const LOCALHOST_ORIGIN = /^http:\/\/localhost:\d+$/;

app.use(cors({
  origin: (origin, callback) => {
    // No Origin header at all (curl, server-to-server, Postman) — allow.
    if (!origin) return callback(null, true);
    if (PROD_ORIGINS.includes(origin) || LOCALHOST_ORIGIN.test(origin)) {
      return callback(null, true);
    }
    return callback(new Error(`Not allowed by CORS: ${origin}`));
  },
  credentials: true
}));
app.use(express.json());

// ── ROUTES ────────────────────────────────────────────────────
registerAuthRoutes(app);
registerDashboardRoutes(app);
registerBookingRoutes(app);
registerUserRoutes(app);
registerAuditLogsRoutes(app);
registerSessionLogsRoutes(app);
registerTransactionLogsRoutes(app);
registerPaymentsRoutes(app);
registerReportsRoutes(app);
registerGpsRoutes(app);
registerLocationRoutes(app);
registerInventoryRoutes(app);
registerVehicleDocsRoutes(app);
registerFleetRoutes(app);              // ← NEW
registerRefundRequestRoutes(app);      // ← NEW
registerSessionLogArchiveRoutes(app);
registerPaymentsArchiveRoutes(app);
registerBookingArchiveRoutes(app);
registerTransactionLogArchiveRoutes(app);
registerRefundArchiveRoutes(app);      // ← NEW
registerAuditLogsArchiveRoutes(app);
registerReviewsArchiveRoutes(app);
registerReviewsRoutes(app); // ← NEW: live Reviews page (list + delete-to-archive)
registerBookingSessionArchiveRoutes(app);  // ← NEW
registerUserArchiveRoutes(app);            // ← NEW
registerCronRoutes(app);              // ← NEW
registerMaintenanceRoutes(app);       // ← NEW
registerCarPartsRoutes(app);          // ← NEW
registerProfileRequestsRoutes(app);   // ← NEW
registerDriverDispatchRoutes(app);    // ← NEW
registerSystemSettingsRoutes(app);   // ← NEW
registerLocationOptionsRoutes(app);   // ← NEW

const PORT = process.env.PORT || 5000;

app.listen(PORT, async () => {
  console.log(`🚀 Server running on port ${PORT}`);
  await seedCacheFromFirestore();
  // both watchers removed — see comment above the imports
});

export default app;