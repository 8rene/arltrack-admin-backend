// ================================
//  CRON — midnight archive flush
//  For every session still active (car currently on trip), compile its
//  full GPS trail so far and upload a permanent copy to Firebase Storage,
//  overwriting the previous night's file.
//
//  The trail is read from Google Sheets (one tab per PHT date — see
//  services/sheets/sheets.service.js via flushBookingHistory in booking.service.js), NOT
//  from a Firestore archive sub-collection. A failed flush just means that
//  session's Storage copy is stale until the next successful run. One
//  session's failure is still isolated so it can't stop the rest of the
//  fleet from being flushed.
// ================================

import { getAllActiveSessions, getSessionsNeedingFinalFlush } from "../services/booking/bookingSession.service.js";
import { flushBookingHistory } from "../services/booking/booking.service.js";
import { db } from "../config/firebaseConnection/firebase.js";
import { createNotification, notifyStaff, resolveNotification } from "../services/notification/notification.service.js";
import { sendLicenseExpiryEmail } from "../services/email/email.service.js";
import { ROLE_IDS } from "../utils/roles/role.util.js";

// ── Driver's license expiry check ─────────────────────────────────
// Piggybacks on this same daily cron, same reasoning as the overdue-booking
// check above: daily granularity is fine for this, no separate schedule
// needed. Scoped to Driver/Supervisor accounts only — customer enforcement
// is out of scope for now (customer app is owned by another dev).
//
// NO auto-lock any more. Locking an expired driver also locked them out of
// the very screen they need to upload a renewed license (a locked account
// can't log in), so they could never fix it themselves. Instead, an expired
// license now: (1) notifies staff + the driver in the bell (and email), (2)
// shows as an Alert on the dashboard, and (3) warns whoever tries to assign
// that driver to a trip (driverDispatch.service.js — "Assign Anyway" to
// override). Nothing here changes the account's status.
const LICENSE_WARNING_DAYS = 14;

const parseExpiry = (val) => {
  if (!val) return null;
  if (typeof val?.toDate === "function") return val.toDate();
  const d = new Date(val);
  return isNaN(d.getTime()) ? null : d;
};

const checkLicenseExpiry = async () => {
  const now = new Date();
  const docsSnap = await db.collection("userDocument").get();

  for (const docSnap of docsSnap.docs) {
    const data = docSnap.data();
    const expiry = parseExpiry(data.driverLicenseExpiry);
    if (!expiry || !data.userID) continue;

    const userRef  = db.collection("user").doc(data.userID);
    const userSnap = await userRef.get();
    if (!userSnap.exists) continue;
    const userData = userSnap.data();

    // Only Driver/Supervisor accounts — see note above.
    if (userData.roleID !== ROLE_IDS.DRIVER && userData.roleID !== ROLE_IDS.SUPERVISOR) continue;

    const refID = data.userID;
    const msLeft = expiry.getTime() - now.getTime();
    const daysLeft = Math.ceil(msLeft / (24 * 60 * 60 * 1000));
    const isExpired = msLeft < 0;
    const isWarning = !isExpired && daysLeft <= LICENSE_WARNING_DAYS;
    const toName = userData.username || userData.email || "Team Member";
    const expiryDateLabel = expiry.toDateString();

    if (isExpired) {
      await resolveNotification("license_expiring", refID).catch(() => {});

      // Check-before-create so the email only fires the first time this
      // account crosses into "expired" (not every night it stays expired).
      const existing = await db.collection("notifications")
        .where("type", "==", "license_expired")
        .where("refID", "==", refID)
        .where("status", "==", "active")
        .limit(1).get();
      const isNewNotif = existing.empty;

      // Staff fan-out (Owner/Admin/Supervisor) so they know a license
      // expired, plus a personal copy to the driver themselves — they should
      // hear it from their own bell too, not just find out when they're
      // warned at assignment.
      await Promise.all([
        notifyStaff({
          type: "license_expired",
          refID,
          refCollection: "user",
          title: "Driver's license expired",
          message: `${toName}'s driver's license expired on ${expiryDateLabel}. A warning will show when assigning them to a trip.`,
        }).catch((err) => console.error("[NOTIF] license_expired staff notify failed:", err.message)),
        createNotification({
          type: "license_expired",
          refID,
          refCollection: "user",
          title: "Your driver's license expired",
          message: `Your driver's license expired on ${expiryDateLabel}. Please submit an updated license from your profile as soon as possible.`,
          userID: refID,
        }).catch((err) => console.error("[NOTIF] license_expired personal notify failed:", err.message)),
      ]);

      if (isNewNotif && userData.email) {
        await sendLicenseExpiryEmail({ toEmail: userData.email, toName, isExpired: true, expiryDate: expiryDateLabel })
          .catch((err) => console.error("[EMAIL] license_expired send failed:", err.message));
      }
    } else if (isWarning) {
      const existing = await db.collection("notifications")
        .where("type", "==", "license_expiring")
        .where("refID", "==", refID)
        .where("status", "==", "active")
        .limit(1).get();
      const isNewNotif = existing.empty;

      await Promise.all([
        notifyStaff({
          type: "license_expiring",
          refID,
          refCollection: "user",
          title: "Driver's license expiring soon",
          message: `${toName}'s driver's license expires in ${daysLeft} day(s) (${expiryDateLabel}).`,
        }).catch((err) => console.error("[NOTIF] license_expiring staff notify failed:", err.message)),
        createNotification({
          type: "license_expiring",
          refID,
          refCollection: "user",
          title: "Your driver's license is expiring soon",
          message: `Your driver's license expires in ${daysLeft} day(s) (${expiryDateLabel}). Please submit an updated license from your profile before it expires.`,
          userID: refID,
        }).catch((err) => console.error("[NOTIF] license_expiring personal notify failed:", err.message)),
      ]);

      if (isNewNotif && userData.email) {
        await sendLicenseExpiryEmail({ toEmail: userData.email, toName, isExpired: false, daysLeft, expiryDate: expiryDateLabel })
          .catch((err) => console.error("[EMAIL] license_expiring send failed:", err.message));
      }
    } else {
      await resolveNotification("license_expiring", refID).catch(() => {});
      await resolveNotification("license_expired", refID).catch(() => {});
    }
  }
};

// ── Pickup/return overdue checks ──────────────────────────────────
// Piggybacks on this same daily cron rather than a separate job —
// daily granularity is fine for these (unlike a "10 minutes before
// pickup" reminder, which would need a much more frequent schedule
// this project's current Vercel Cron plan doesn't support).
const checkOverdueBookings = async () => {
  const now = new Date();
  const snap = await db.collection("bookings")
    .where("status", "in", ["upcoming", "ongoing"])
    .get();

  for (const doc of snap.docs) {
    const booking = doc.data();
    const docID = doc.id;

    // Pickup overdue: still "upcoming" (never picked up) past its startDateTime
    if (booking.status === "upcoming" && booking.startDateTime?.toDate?.() < now) {
      await notifyStaff({
        type: "pickup_overdue",
        refID: docID,
        refCollection: "bookings",
        title: "Pickup overdue",
        message: `Booking ${booking.bookingID || docID} was due for pickup but hasn't started.`,
      }).catch((err) => console.error("[NOTIF] pickup_overdue create failed:", err.message));
    } else {
      await resolveNotification("pickup_overdue", docID).catch(() => {});
    }

    // Return overdue: still "ongoing" past its endDateTime
    if (booking.status === "ongoing" && booking.endDateTime?.toDate?.() < now) {
      await notifyStaff({
        type: "return_overdue",
        refID: docID,
        refCollection: "bookings",
        title: "Return overdue",
        message: `Booking ${booking.bookingID || docID} is past its return time.`,
      }).catch((err) => console.error("[NOTIF] return_overdue create failed:", err.message));
    } else {
      await resolveNotification("return_overdue", docID).catch(() => {});
    }
  }
};

// ── Maintenance overdue check ──────────────────────────────────────
// Same shape as the pickup/return overdue check above: no separate
// "Overdue" status to remember to set on the record — just a date
// that's slipped by while the record is still open (Scheduled, i.e.
// not yet Completed/Cancelled). Runs on the same daily cadence since
// maintenance dates don't need finer granularity.
const checkOverdueMaintenance = async () => {
  const now = new Date();
  // Queries every record, not just Scheduled ones — a record that just
  // got marked Completed/Cancelled still needs this loop to see it so
  // its notification can be resolved. Filtering the query itself to
  // Scheduled (like the booking check above does) would mean a record
  // that flips to Completed silently drops out of the snapshot and
  // never gets its notification resolved.
  const snap = await db.collection("maintenance").get();

  for (const doc of snap.docs) {
    const record = doc.data();
    const docID = doc.id;
    const dueDate = record.maintenanceDate?.toDate?.();
    const stillOpen = record.status === "Scheduled";

    if (stillOpen && dueDate && dueDate < now) {
      await notifyStaff({
        type: "maintenance_overdue",
        refID: docID,
        refCollection: "maintenance",
        title: "Maintenance overdue",
        message: `${record.carID || "A vehicle"}'s scheduled maintenance (${record.description || "service"}) is past due.`,
      }).catch((err) => console.error("[NOTIF] maintenance_overdue create failed:", err.message));
    } else {
      await resolveNotification("maintenance_overdue", docID).catch(() => {});
    }
  }
};

export const runMidnightFlush = async () => {
  await checkOverdueBookings().catch((err) =>
    console.error("[CRON] ❌ Overdue booking check failed:", err.message)
  );

  await checkOverdueMaintenance().catch((err) =>
    console.error("[CRON] ❌ Overdue maintenance check failed:", err.message)
  );

  await checkLicenseExpiry().catch((err) =>
    console.error("[CRON] ❌ License expiry check failed:", err.message)
  );

  console.log("[CRON] ⏰ Midnight archive flush starting...");

  const activeSessions = await getAllActiveSessions().catch((err) => {
    console.error("[CRON] ❌ Failed to load active sessions:", err.message);
    return [];
  });

  let succeeded = 0;
  let failed = 0;

  for (const { data } of activeSessions) {
    try {
      await flushBookingHistory(data.bookingSessionID);
      succeeded++;
    } catch (err) {
      failed++;
      console.error(
        `[CRON] ❌ Failed to flush session ${data.bookingSessionID}:`,
        err.message
      );
      // Deliberately no early return / throw here — one bad session must
      // never stop the rest of the fleet from being archived tonight.
    }
  }

  // Trips that already ended or were flagged stolen but whose FINAL file never got saved (the save at Mark
  // Complete / Stolen failed). Only these are retried -- the flag is cleared by a successful save, so a trip
  // that finished cleanly is never read again.
  const pendingFinal = await getSessionsNeedingFinalFlush().catch((err) => {
    console.error("[CRON] ❌ Failed to load trips awaiting a final save:", err.message);
    return [];
  });
  let retried = 0;
  for (const { data } of pendingFinal) {
    try {
      await flushBookingHistory(data.bookingSessionID);
      retried++;
    } catch (err) {
      failed++;
      console.error(`[CRON] ❌ Retry of final save failed for ${data.bookingSessionID}:`, err.message);
    }
  }

  console.log(
    `[CRON] ✅ Midnight archive flush complete — ${succeeded} succeeded, ${failed} failed, ${activeSessions.length} active session(s) total, ${retried}/${pendingFinal.length} final save(s) retried.`
  );
};