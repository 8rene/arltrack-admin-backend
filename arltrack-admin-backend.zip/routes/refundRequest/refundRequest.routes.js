import { listRefundRequests, approveRefund, rejectRefund, manualRefundIssued } from "../../controllers/refundRequest/refundRequest.controller.js";
import { verifyToken } from "../../middlewares/auth/auth.middleware.js";
import { requireRole, roles } from "../../middlewares/role/role.middleware.js";

// Visible to: Supervisor, Admin, Owner — same access level as Payments
const allowed = [roles.SUPERVISOR, roles.ADMIN, roles.OWNER];

export const registerRefundRequestRoutes = (app) => {
  app.get("/api/refund-requests",              verifyToken, requireRole(allowed), listRefundRequests);
  app.patch("/api/refund-requests/:id/approve", verifyToken, requireRole(allowed), approveRefund);
  app.patch("/api/refund-requests/:id/reject",  verifyToken, requireRole(allowed), rejectRefund);
  // Staff confirm the in-person part of a refund (the balance PayMongo can't return) was handed back.
  app.patch("/api/refund-requests/:id/manual-issued", verifyToken, requireRole(allowed), manualRefundIssued);
  // NOTE: a car's upcoming bookings are now force-refunded/cancelled as one
  // batch, entirely server-side, inside PATCH /api/fleet/cars/:carID/status
  // (fleet.controller.js's changeCarStatus) — there's no standalone
  // "refund this one booking right now" endpoint anymore; firing outside
  // that one gated, OTP-verified batch would bypass the whole point of it.
};