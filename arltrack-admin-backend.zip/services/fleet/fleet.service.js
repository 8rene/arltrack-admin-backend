import { db } from "../../config/firebaseConnection/firebase.js";
import admin from "firebase-admin";
import { getBookingRefundPreview, getStaffRefundOutcome } from "../refundRequest/refundRequest.service.js";
import { getStaffCancelledBookingKeys } from "../cancellationRequests/cancellationRequests.service.js";
import { getPaymentDetailsByBookingID } from "../payments/payments.service.js";

// ─────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────

const timestamp = () => admin.firestore.FieldValue.serverTimestamp();

const sortPricing = (pricing = []) =>
  [...pricing].sort((a, b) => {
    const aIs12 = a.durationType?.toLowerCase().includes("12");
    const bIs12 = b.durationType?.toLowerCase().includes("12");
    if (aIs12 && !bIs12) return 1;
    if (!aIs12 && bIs12) return -1;
    return 0;
  });

// ─────────────────────────────────────────────
// GET all cars (with images + pricing + brand/model names)
// ─────────────────────────────────────────────
export const getAllCars = async () => {
  const [carsSnap, imgSnap, priceSnap, brandSnap, modelSnap] = await Promise.all([
    db.collection("cars").get(),
    db.collection("carImages").get(),
    db.collection("carPricing").get(),
    db.collection("brand").get(),
    db.collection("model").get(),
  ]);

  const imgMap = {};
  imgSnap.docs.forEach(d => {
    const { carID, imageURL, isPrimary } = d.data();
    if (!imgMap[carID] || isPrimary) imgMap[carID] = imageURL;
  });

  const priceMap = {};
  priceSnap.docs.forEach(d => {
    const { carID, price, durationType } = d.data();
    if (!priceMap[carID]) priceMap[carID] = [];
    priceMap[carID].push({ id: d.id, price, durationType });
  });

  const brandMap = Object.fromEntries(brandSnap.docs.map(d => [d.id, d.data().brandName]));
  const modelMap = Object.fromEntries(modelSnap.docs.map(d => [d.id, d.data().modelName]));

  return carsSnap.docs.map(d => ({
    id: d.id,
    ...d.data(),
    imageURL:  imgMap[d.id] || null,
    pricing:   sortPricing(priceMap[d.id] || []),
    brandName: brandMap[d.data().brandID] || "—",
    modelName: modelMap[d.data().modelID] || "—",
  }));
};

// ─────────────────────────────────────────────
// GET single car by ID
// ─────────────────────────────────────────────
export const getCarById = async (carID) => {
  const carDoc = await db.collection("cars").doc(carID).get();
  if (!carDoc.exists) throw new Error("Car not found.");

  const carData = carDoc.data();

  const [imgSnap, priceSnap, brandSnap, modelSnap] = await Promise.all([
    db.collection("carImages").where("carID", "==", carID).get(),
    db.collection("carPricing").where("carID", "==", carID).get(),
    carData.brandID ? db.collection("brand").doc(carData.brandID).get() : Promise.resolve(null),
    carData.modelID ? db.collection("model").doc(carData.modelID).get() : Promise.resolve(null),
  ]);

  const images = imgSnap.docs.map(d => ({ id: d.id, ...d.data() }));
  const pricing = sortPricing(priceSnap.docs.map(d => ({ id: d.id, ...d.data() })));
  const brandName = brandSnap?.exists ? brandSnap.data().brandName : "—";
  const modelName = modelSnap?.exists ? modelSnap.data().modelName : "—";

  return { id: carID, ...carData, images, pricing, brandName, modelName };
};

// ─────────────────────────────────────────────
// ADD car (without image — image handled separately or by frontend)
// ─────────────────────────────────────────────
export const addCar = async (carData) => {
  const { brandID, modelID, pricing = [], ...rest } = carData;

  if (!brandID || !modelID) throw new Error("brandID and modelID are required.");

  const carRef = await db.collection("cars").add({
    ...rest,
    brandID,
    modelID,
    seatingCapacity: Number(rest.seatingCapacity) || 0,
    year: Number(rest.year) || 0,
    createdAt: timestamp(),
    updatedAt: timestamp(),
  });

  // Save pricing tiers
  for (const p of pricing) {
    if (p.durationType && p.price) {
      await db.collection("carPricing").add({
        carID: carRef.id,
        price: Number(p.price),
        durationType: p.durationType,
      });
    }
  }

  return { id: carRef.id };
};

// ─────────────────────────────────────────────
// UPDATE car details
// ─────────────────────────────────────────────
export const updateCar = async (carID, carData) => {
  const carRef = db.collection("cars").doc(carID);
  const carDoc = await carRef.get();
  if (!carDoc.exists) throw new Error("Car not found.");

  const { pricing, ...rest } = carData;

  const updates = { ...rest, updatedAt: timestamp() };

  // Number(undefined) is NaN, and NaN || rest.seatingCapacity falls straight
  // back to that same undefined — which Firestore's update() throws on
  // outright ("Cannot use 'undefined' as a Firestore value"), taking down
  // the whole save even though nothing was actually wrong with the request.
  // This hit any edit where seatingCapacity/year weren't both included in
  // the body. Only coerce them when they were actually sent.
  if (rest.seatingCapacity !== undefined) {
    const n = Number(rest.seatingCapacity);
    updates.seatingCapacity = Number.isFinite(n) ? n : rest.seatingCapacity;
  }
  if (rest.year !== undefined) {
    const n = Number(rest.year);
    updates.year = Number.isFinite(n) ? n : rest.year;
  }

  // Belt-and-suspenders: strip any other undefined values too, so one
  // missing/optional field anywhere in the body can't fail the entire
  // update the same way.
  Object.keys(updates).forEach((key) => {
    if (updates[key] === undefined) delete updates[key];
  });

  await carRef.update(updates);

  return { id: carID };
};

// ─────────────────────────────────────────────
// UPDATE car status only
// ─────────────────────────────────────────────
export const updateCarStatus = async (carID, status, statusReason = null) => {
  const validStatuses = ["Active", "Rented", "Reserved", "Maintenance", "Inactive"];
  if (!validStatuses.includes(status)) throw new Error(`Invalid status. Must be one of: ${validStatuses.join(", ")}`);

  const carRef = db.collection("cars").doc(carID);
  const carDoc = await carRef.get();
  if (!carDoc.exists) throw new Error("Car not found.");

  // Cleared back to null once the car leaves Maintenance/Inactive, same as
  // the frontend's own applyStatusChange() already did client-side — kept
  // here too now that this is the authoritative write path.
  await carRef.update({ status, statusReason, updatedAt: timestamp() });
  return { id: carID, status, statusReason };
};

// The bookings.carID field matches the car doc's OWN "carID" field, not its
// Firestore doc id — but some older car docs never got one written, so this
// falls back to the doc id itself, same fallback Fleet.jsx's frontend
// already uses for its own booking lookups.
const carBookingIDValue = (carDoc) => carDoc.data().carID || carDoc.id;

// Bookings currently in flight for a car — "upcoming" (not yet started,
// still cancellable/refundable) and "ongoing" (car already with the
// customer, shown for awareness only). Used both by the status-change
// preview endpoint below and, as a lighter existence check, by
// changeCarStatus() to block Maintenance/Inactive until every upcoming
// booking has been resolved.
export const getOpenBookingsForCar = async (carID) => {
  const carDoc = await db.collection("cars").doc(carID).get();
  if (!carDoc.exists) throw new Error("Car not found.");
  const carIDValue = carBookingIDValue(carDoc);

  const snap = await db.collection("bookings").where("carID", "==", carIDValue).get();
  const bookings = snap.docs.map((d) => ({ id: d.id, ...d.data() }));

  const upcoming = bookings.filter((b) => String(b.status || "").toLowerCase() === "upcoming");
  const ongoing  = bookings.filter((b) => String(b.status || "").toLowerCase() === "ongoing");

  return { upcoming, ongoing };
};

// Firestore Timestamp or a plain date value — same fallback used elsewhere
// in the backend (auditLogs/transactionLogs/refundRequest services).
const toJsDate = (v) => (v?.toDate ? v.toDate() : v ? new Date(v) : null);

const startOfToday = () => { const d = new Date(); d.setHours(0, 0, 0, 0); return d; };

// Raw Firestore Timestamps don't survive res.json() — the Admin SDK
// serializes them as { _seconds, _nanoseconds }, which the frontend can't
// turn back into a date (no .toDate(), and new Date({...}) is Invalid Date).
// That's why Start/End showed "—" in the Fleet status-change modals. Every
// Timestamp on a booking doc is converted to an ISO string here instead, so
// the frontend always receives something new Date(...) understands.
const toISO = (v) => {
  if (!v) return null;
  if (typeof v.toDate === "function") return v.toDate().toISOString();
  if (v instanceof Date) return v.toISOString();
  if (typeof v === "object" && typeof v._seconds === "number") return new Date(v._seconds * 1000).toISOString();
  if (typeof v === "string" || typeof v === "number") { const d = new Date(v); return isNaN(d) ? null : d.toISOString(); }
  return null;
};

// Booking doc → JSON-safe copy: every Timestamp-shaped field becomes an ISO
// string, everything else passes through untouched.
const serializeBooking = (b) => {
  const out = {};
  for (const [k, v] of Object.entries(b)) {
    const isTs = v && typeof v === "object" && (typeof v.toDate === "function" || typeof v._seconds === "number" || v instanceof Date);
    out[k] = isTs ? toISO(v) : v;
  }
  return out;
};

// Vehicle label for the confirm modal ("Mitsubishi L300"), same
// car → model → brand walk the Payments page uses.
const resolveCarLabel = async (carDocID) => {
  try {
    const carDoc = await db.collection("cars").doc(carDocID).get();
    if (!carDoc.exists) return null;
    const { modelID, platenumber, plateNumber } = carDoc.data();
    let label = null;
    if (modelID) {
      const modelDoc = await db.collection("model").doc(modelID).get();
      if (modelDoc.exists) {
        const { brandID, modelName } = modelDoc.data();
        const brandDoc = brandID ? await db.collection("brand").doc(brandID).get() : null;
        label = [brandDoc?.exists ? brandDoc.data().brandName : "", modelName].filter(Boolean).join(" ") || null;
      }
    }
    return { label, plateNumber: platenumber || plateNumber || null };
  } catch { return null; }
};

// Bookings on this car that staff already cancelled through THIS flow
// (cancellationRequests rows with cancelledBy "staff"), scoped to today-or-later starts only —
// a booking from months ago that happened to get cancelled this way
// shouldn't pile up here forever. Shown on the status-change screen after
// a partial batch failure so staff see the full picture (what already
// went through), not just what's still blocking — see StatusChangeFlow /
// AreYouSureRefundModal in Fleet.jsx.
export const getResolvedBookingsForCar = async (carID) => {
  const carDoc = await db.collection("cars").doc(carID).get();
  if (!carDoc.exists) throw new Error("Car not found.");
  const carIDValue = carBookingIDValue(carDoc);
  const cutoff = startOfToday();

  const snap = await db.collection("bookings")
    .where("carID", "==", carIDValue)
    .where("status", "==", "cancelled")
    .get();

  const staffKeys = await getStaffCancelledBookingKeys();
  const candidates = snap.docs
    .map((d) => ({ id: d.id, ...d.data() }))
    .filter((b) => staffKeys.has(b.bookingID || b.id))
    .filter((b) => {
      const start = toJsDate(b.startDateTime);
      return !start || start >= cutoff; // no date on record — don't hide it, show it
    });

  return Promise.all(
    candidates.map(async (b) => {
      const outcome = await getStaffRefundOutcome(b.bookingID);
      return { bookingID: b.bookingID, startDateTime: toISO(b.startDateTime), endDateTime: toISO(b.endDateTime), ...outcome };
    })
  );
};

// Same as getOpenBookingsForCar, plus a refund-amount preview attached to
// each upcoming booking and the resolved list above — this is what the
// "are you sure" modal in Fleet.jsx actually renders: one Refund row +
// ₱ amount per upcoming booking (or an "already refunded" flag), one FYI
// row per ongoing booking, and an "already resolved" section for context
// on a retry after a partial batch failure.
export const getCarBookingsForStatusChange = async (carID) => {
  const { upcoming, ongoing } = await getOpenBookingsForCar(carID);
  const carInfo = await resolveCarLabel(carID);

  // paymentDetails carries the full picture (discounts, the deposit/balance
  // timeline, payment stage, customer name) — same shape the main Payments
  // page already builds, reused here (getPaymentDetailsByBookingID) rather
  // than a stripped-down version, so Fleet.jsx's per-booking confirm modal
  // can show real payment history before staff confirm it, not a summary
  // that can drift out of sync with what Payments.jsx itself shows.
  const upcomingWithPreview = await Promise.all(
    upcoming.map(async (b) => ({
      ...serializeBooking(b),
      vehicleLabel: carInfo?.label || null,
      plateNumber: carInfo?.plateNumber || null,
      refundPreview: await getBookingRefundPreview(b.bookingID).catch(() => ({ total: 0, onlineAmount: 0, manualAmount: 0, alreadyRefunded: false })),
      paymentDetails: await getPaymentDetailsByBookingID(b.bookingID).catch(() => null),
    }))
  );

  // Ongoing bookings were previously sent raw too — same Timestamp problem
  // for their date range, so they get serialized as well.
  const ongoingSerialized = ongoing.map(serializeBooking);

  const resolved = await getResolvedBookingsForCar(carID);

  return { upcoming: upcomingWithPreview, ongoing: ongoingSerialized, resolved };
};

// ─────────────────────────────────────────────
// DELETE car (also removes its images and pricing)
// ─────────────────────────────────────────────
export const deleteCar = async (carID) => {
  const carDoc = await db.collection("cars").doc(carID).get();
  if (!carDoc.exists) throw new Error("Car not found.");

  const batch = db.batch();

  // Queue car deletion
  batch.delete(db.collection("cars").doc(carID));

  // Queue carImages deletion
  const imgSnap = await db.collection("carImages").where("carID", "==", carID).get();
  imgSnap.docs.forEach(d => batch.delete(d.ref));

  // Queue carPricing deletion
  const priceSnap = await db.collection("carPricing").where("carID", "==", carID).get();
  priceSnap.docs.forEach(d => batch.delete(d.ref));

  await batch.commit();
  return { id: carID, deleted: true };
};

// ─────────────────────────────────────────────
// PRICING — Get pricing tiers for a car
// ─────────────────────────────────────────────
export const getPricingByCar = async (carID) => {
  const snap = await db.collection("carPricing").where("carID", "==", carID).get();
  return sortPricing(snap.docs.map(d => ({ id: d.id, ...d.data() })));
};

// ─────────────────────────────────────────────
// PRICING — Add a single pricing tier
// ─────────────────────────────────────────────
export const addPricingTier = async (carID, { durationType, price }) => {
  if (!durationType || price === undefined || price === "") {
    throw new Error("durationType and price are required.");
  }
  const ref = await db.collection("carPricing").add({
    carID,
    durationType,
    price: Number(price),
  });
  return { id: ref.id, carID, durationType, price: Number(price) };
};

// ─────────────────────────────────────────────
// PRICING — Update a single pricing tier
// ─────────────────────────────────────────────
export const updatePricingTier = async (pricingID, { durationType, price }) => {
  const ref = db.collection("carPricing").doc(pricingID);
  const doc = await ref.get();
  if (!doc.exists) throw new Error("Pricing tier not found.");
  await ref.update({ durationType, price: Number(price) });
  return { id: pricingID, durationType, price: Number(price) };
};

// ─────────────────────────────────────────────
// PRICING — Delete a single pricing tier
// ─────────────────────────────────────────────
export const deletePricingTier = async (pricingID) => {
  const ref = db.collection("carPricing").doc(pricingID);
  const doc = await ref.get();
  if (!doc.exists) throw new Error("Pricing tier not found.");
  await ref.delete();
  return { id: pricingID, deleted: true };
};

// ─────────────────────────────────────────────
// PRICING — Bulk replace all pricing tiers for a car
// (delete existing, insert new list)
// ─────────────────────────────────────────────
export const replacePricingForCar = async (carID, pricingList = []) => {
  const existingSnap = await db.collection("carPricing").where("carID", "==", carID).get();

  const batch = db.batch();
  existingSnap.docs.forEach(d => batch.delete(d.ref));
  await batch.commit();

  const newTiers = [];
  for (const p of pricingList) {
    if (p.durationType && p.price !== undefined && p.price !== "") {
      const ref = await db.collection("carPricing").add({
        carID,
        durationType: p.durationType,
        price: Number(p.price),
      });
      newTiers.push({ id: ref.id, carID, durationType: p.durationType, price: Number(p.price) });
    }
  }

  return sortPricing(newTiers);
};

// ─────────────────────────────────────────────
// BRANDS — Get all brands
// ─────────────────────────────────────────────
export const getAllBrands = async () => {
  const snap = await db.collection("brand").get();
  return snap.docs.map(d => ({ id: d.id, ...d.data() }));
};

// ─────────────────────────────────────────────
// BRANDS — Add brand
// ─────────────────────────────────────────────
export const addBrand = async (brandName) => {
  if (!brandName?.trim()) throw new Error("brandName is required.");
  const ref = await db.collection("brand").add({ brandName: brandName.trim() });
  await ref.update({ brandID: ref.id });
  return { id: ref.id, brandName: brandName.trim() };
};

// ─────────────────────────────────────────────
// BRANDS — Delete brand (also removes its models)
// ─────────────────────────────────────────────
export const deleteBrand = async (brandID) => {
  const brandDoc = await db.collection("brand").doc(brandID).get();
  if (!brandDoc.exists) throw new Error("Brand not found.");

  const batch = db.batch();
  batch.delete(db.collection("brand").doc(brandID));

  const modelsSnap = await db.collection("model").where("brandID", "==", brandID).get();
  modelsSnap.docs.forEach(d => batch.delete(d.ref));

  await batch.commit();
  return { id: brandID, deleted: true };
};

// ─────────────────────────────────────────────
// MODELS — Get all models (optionally filter by brandID)
// ─────────────────────────────────────────────
export const getAllModels = async (brandID) => {
  let q = db.collection("model");
  if (brandID) q = q.where("brandID", "==", brandID);
  const snap = await q.get();
  return snap.docs.map(d => ({ id: d.id, ...d.data() }));
};

// ─────────────────────────────────────────────
// MODELS — Add model
// ─────────────────────────────────────────────
export const addModel = async (modelName, brandID) => {
  if (!modelName?.trim() || !brandID) throw new Error("modelName and brandID are required.");
  const ref = await db.collection("model").add({ modelName: modelName.trim(), brandID });
  await ref.update({ modelID: ref.id });
  return { id: ref.id, modelName: modelName.trim(), brandID };
};

// ─────────────────────────────────────────────
// MODELS — Delete model
// ─────────────────────────────────────────────
export const deleteModel = async (modelID) => {
  const modelDoc = await db.collection("model").doc(modelID).get();
  if (!modelDoc.exists) throw new Error("Model not found.");
  await db.collection("model").doc(modelID).delete();
  return { id: modelID, deleted: true };
};

// ─────────────────────────────────────────────
// IMAGES — Upsert the primary image for a car
// (Upload to Storage still happens client-side with the Firebase SDK —
// only the resulting Firestore carImages doc write moves here.)
// ─────────────────────────────────────────────
export const setPrimaryCarImage = async (carID, imageURL) => {
  if (!imageURL) throw new Error("imageURL is required.");

  const carDoc = await db.collection("cars").doc(carID).get();
  if (!carDoc.exists) throw new Error("Car not found.");

  const existingSnap = await db.collection("carImages")
    .where("carID", "==", carID)
    .where("isPrimary", "==", true)
    .limit(1)
    .get();

  if (!existingSnap.empty) {
    await existingSnap.docs[0].ref.update({ imageURL });
    return { id: existingSnap.docs[0].id, carID, imageURL, isPrimary: true, label: "Primary" };
  }

  const ref = await db.collection("carImages").add({
    carID,
    imageURL,
    isPrimary: true,
    label: "Primary",
    createdAt: timestamp(),
  });
  return { id: ref.id, carID, imageURL, isPrimary: true, label: "Primary" };
};