// Compiles bookingSessions/{id}/archive/{date} day-docs into one permanent
// JSON file in Firebase Storage under bookingHistory/ — the Firestore
// equivalent of the test backend's Cloudinary flush.
//
// Format: a plain JSON array (not NDJSON) — see the earlier discussion:
// this is a full-overwrite compile every run, not an incremental append, so
// NDJSON's append-friendliness doesn't buy anything here, and a JSON array
// is one clean res.json() away on the frontend (HistoryTab-equivalent),
// matching how the Cloudinary version already worked.
//
// NOTE: unlike the test backend's Sheets tabs, the archive subcollection
// here is NOT deleted after flushing (or ever, on any retention schedule) —
// Firestore storage is cheap enough that there's no 3-day-rotation pressure
// forcing a "protect from deletion if the flush failed" safeguard the way
// Sheets needed. A failed flush just means try again next run; nothing is
// ever at risk of being lost.

import { db, bucket } from "../../config/firebaseConnection/firebase.js";
import { recordArchiveFlush } from "../booking/bookingSession.service.js";

/**
 * Compile and upload one session's full trail.
 * @param {string} bookingSessionID
 * @returns {Promise<string>} the public archive URL
 */
export const flushSessionArchive = async (bookingSessionID) => {
  const archiveSnap = await db
    .collection("bookingSessions")
    .doc(bookingSessionID)
    .collection("archive")
    .get();

  // Day-docs are named "YYYY-MM-DD", so sorting doc IDs in JS already gives
  // chronological order — same trick the customer backend's traceback
  // endpoint uses, no orderBy() needed.
  const days = archiveSnap.docs.sort((a, b) => (a.id < b.id ? -1 : 1));

  // Each day-doc is expected to hold its points under a `points` array field
  // (pushed to via arrayUnion as pings come in — see the live-ping writer,
  // not yet built). Flatten every day into one continuous trail.
  const fullTrail = days.flatMap((doc) => doc.data()?.points || []);

  const filePath = `bookingHistory/${bookingSessionID}.json`;
  const file = bucket.file(filePath);

  await file.save(JSON.stringify(fullTrail, null, 2), {
    contentType: "application/json",
    metadata: { cacheControl: "no-cache" },
  });
  await file.makePublic();

  const archiveUrl = `https://storage.googleapis.com/${bucket.name}/${filePath}`;
  await recordArchiveFlush(bookingSessionID, archiveUrl);

  return archiveUrl;
};