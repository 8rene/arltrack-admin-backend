import { db, bucket } from "../../config/firebaseConnection/firebase.js";
import { roleIDToName } from "../../utils/roles/role.util.js";
import admin from "firebase-admin";
import { getSessionById, recordArchiveFlush, getSessionByBookingID, markSessionActive, markSessionEnded, markSessionCancelled, markSessionStolen, markDroppedOff, updateSessionStops } from "../../services/booking/bookingSession.service.js";
import { toDate, sessionStartedAt, sessionEndedAt } from "../../utils/date/sessionDates.js";
import { fetchSessionRows } from "../../services/sheets/sheets.service.js";
import { datesBetweenPHT } from "../../utils/date/phtDate.js";
import { getPhaseChecklist, describeMissingInspection } from "../../services/vehicleDocumentation/vehicleDocumentation.service.js";
import { resolveInspectionReminders } from "../../services/inspectionReminders/inspectionReminders.service.js";
import { computeAmounts, derivePaymentStage, findOpenRefundRequest } from "../../services/payments/payments.service.js";
import { computeRefundPlan } from "../payments/paymentBreakdown.js";
import { resolveNotification } from "../../services/notification/notification.service.js";
import { createAuditLog, auditSafe } from "../../services/auditLogs/auditLogs.service.js";
import { listPenaltiesForBooking, settleBooking } from "../../services/penalty/penalty.service.js";
import { planOnlineDepositReturn, sendOnlineReturns, onlineDepositReturnOption, getDepositReturnForBooking, notifyCustomerReturnedInStore } from "../../services/depositReturn/depositReturn.service.js";
import { getDepositView } from "../payments/paymentHelpers.js";
import { getDiscountFigures } from "../payments/discountLedger.js";
import { hydratePaymentData } from "../../services/paymentEntries/paymentEntries.service.js";
import { getHolidaysBetween } from "../gps/coding.service.js";
import {
  bookingKeyOf, attachCurrentDrivers, attachFinishedDrivers, resolveCurrentDriverID, getBookingsByKeys, completeActiveAssignment,
} from "../../services/driverAssignments/driverAssignments.service.js";
import {
  REQUEST_STATUS, getPendingRequest, getAllPendingRequests, getRequestsByBookingKeys, resolveRequest, recordDirectCancellation,
} from "../../services/cancellationRequests/cancellationRequests.service.js";
// ─────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────

export const resolveVehicleName = async (carID) => {
  if (!carID) return "—";
  try {
    const carDoc = await db.collection("cars").doc(carID).get();
    if (!carDoc.exists) return "—";
    const { modelID } = carDoc.data();
    if (!modelID) return "—";
    const modelDoc = await db.collection("model").doc(modelID).get();
    if (!modelDoc.exists) return "—";
    const { brandID, modelName } = modelDoc.data();
    const brandDoc = await db.collection("brand").doc(brandID).get();
    const brandName = brandDoc.exists ? brandDoc.data().brandName : "";
    return [brandName, modelName].filter(Boolean).join(" ") || "—";
  } catch { return "—"; }
};

// bookingID → { paymentMethod, totalFee, rentalFee, serviceFee,
// extraFee, amountPaid, balance, payType, paymentStatus } from payments
// collection. totalFee comes from payments.amount; the fee breakdown comes
// straight off the same doc. amountPaid/balance/payType are derived via the
// shared computeAmounts() (same logic payments.service.js uses for
// /api/payments), so these numbers can't drift between Bookings, Car
// Tracking, and driver-facing screens. paymentStatus mirrors the "Paid" →
// "Approved" normalization getAllPayments() applies, so badge styling in
// PaymentStatusModal lines up regardless of which endpoint fed it; a
// cancelled *booking* still forces "Cancelled" (applied by the caller,
// which has b.status handy — see getAllBookings below).
const EMPTY_PAYMENT_INFO = {
  paymentMethod: "—", totalFee: 0, rentalFee: 0, serviceFee: 0, extraFee: 0,
  driversFee: 0, gatewayFee: 0, securityDeposit: 0, deposit: null,
  amountPaid: 0, balance: 0, payType: "—", paymentStatus: "—", paymentStage: "—", discountAmount: 0,
  refundDue: 0, refundIssued: false,
  // Deposit / penalty breakdown — same "what should actually come back to
  // the customer" math as settleBooking() in penalty.service.js (deposit
  // held minus every unpaid Confirmed penalty, still-negative-allowed).
  // Read-only here, just a live preview for staff before Return actually
  // runs settlement — mirrors the same fields the driver's My Trips
  // Payments button already gets via driverDispatch.service.js, so a
  // supervisor confirming/collecting payment on Car Tracking while a
  // booking is still ongoing can see the rightful return amount instead
  // of only finding out once Return triggers the real deduction.
  depositAmount: 0, depositStatus: "—", confirmedPenaltyTotal: 0, amountToReturn: 0,
  depositSettled: false, depositDeducted: 0,
};
export const resolvePaymentInfo = async (bookingID) => {
  if (!bookingID) return EMPTY_PAYMENT_INFO;
  try {
    const snap = await db.collection("payments")
      .where("bookingID", "==", bookingID)
      .limit(1)
      .get();
    if (snap.empty) return EMPTY_PAYMENT_INFO;
    // Hydrated so paymentMethod / referenceNumber etc. still resolve once the
    // moved fields are cleaned off the payment doc (they live in paymentEntries).
    const data = await hydratePaymentData(snap.docs[0].data(), snap.docs[0].id);
    const { amountPaid, balance, payType, refundDue } = computeAmounts(data);
    let paymentStatus = data.status || "Pending";
    if (paymentStatus.toLowerCase() === "paid") paymentStatus = "Approved";

    const penalties = await listPenaltiesForBooking(bookingID);
    const confirmedPenaltyTotal = penalties
      .filter((p) => p.status === "Confirmed")
      .reduce((sum, p) => sum + Math.max(0, (p.amount || 0) - (p.paidAmount || 0)), 0);
    // null = never recorded; same view for flat and old nested storage. The unpaid total is the live shortfall.
    const deposit = getDepositView(data, { unpaid: confirmedPenaltyTotal });
    const depositAmount = deposit?.amount || 0;
    const depositStatus = deposit?.status || "—";
    // Before settlement this is a live preview: deposit minus every unpaid
    // Confirmed penalty, still-negative-allowed (same as settleBooking()'s
    // `net`). AFTER settlement the deposit has already paid those penalties
    // out, so they now read as paid and the unpaid total falls to 0 —
    // recomputing would show the FULL deposit as "to return" again. So once
    // settled, report what actually happened instead: anything still unpaid
    // right now is owed by the customer (negative), otherwise it's the
    // amount that was handed back (depositReturned).
    const settlement = deposit?.settlement || null;
    const depositSettled = !!settlement;
    const depositDeducted = deposit?.deducted || 0;
    const appliedToPenalties = !settlement ? (deposit?.applied || 0) : 0;   // taken from the held deposit already
    // Discount credit held for the customer (a discount given on a fully paid booking): it covers penalties the deposit
    // can't, and what is left goes back WITH the deposit, so it is part of the amount to return.
    const discountFigures = getDiscountFigures(data);
    const heldCredit = !settlement && deposit?.status === "Held" ? discountFigures.credit : 0;
    const amountToReturn = settlement
      ? (confirmedPenaltyTotal > 0 ? -confirmedPenaltyTotal : Math.max(0, (deposit.returnedAmount || 0) + discountFigures.returned))
      : depositAmount - appliedToPenalties - confirmedPenaltyTotal + heldCredit;

    return {
      paymentMethod: data.paymentMethod || "—",
      totalFee:      data.amount        ?? 0,
      rentalFee:     data.rentalFee     ?? 0,
      serviceFee:    data.serviceFee    ?? 0,
      extraFee:      data.extraFee      ?? 0,
      driversFee:    data.driversFee    ?? 0,
      gatewayFee:    data.gatewayFee    ?? 0,
      // Refundable deposit charged as part of `amount` (0 on older bookings).
      securityDeposit: Number(data.securityDeposit) || 0,
      // The REAL security deposit (depositStatus & co on the payment, written by
      // penalty.service.js's waiveDeposit/settleBooking) — a light read-only
      // summary (no Firestore timestamps). null = never recorded yet. Not the
      // legacy depositFee. The API shape is unchanged from when it was a nested object.
      deposit: deposit ? {
        amount:         deposit.amount,
        status:         deposit.status,
        returnedAmount: deposit.returnedAmount,
      } : null,
      amountPaid,
      balance,
      payType,
      paymentStatus,
      // Pending / Partial / Completed / Failed / Refunded — the vocabulary staff
      // see. getAllBookings layers "Cancelled" and "For Refund" on top (it knows
      // the booking's status and any open refund request).
      paymentStage: derivePaymentStage(data),
      discountAmount: Number(data.discountAmount) || 0,
      refundDue,
      refundIssued: !!data.refundIssued,
      depositAmount, depositStatus, amountToReturn,
      discountCredit: heldCredit,   // held discount credit that goes back with the deposit
      confirmedPenaltyTotal: confirmedPenaltyTotal + appliedToPenalties,
      depositSettled, depositDeducted: depositDeducted || appliedToPenalties,
    };
  } catch { return EMPTY_PAYMENT_INFO; }
};

// Role name ("Owner" | "Admin" | "Supervisor" | ...) of a staff uid, for the "Cancelled by ..." lines. null when unknown.
const resolveRoleName = async (uid) => {
  if (!uid) return null;
  try {
    const snap = await db.collection("user").doc(uid).get();
    const roleID = snap.exists ? snap.data().roleID : null;
    if (!roleID) return null;
    const known = roleIDToName(roleID);
    if (known) return known;
    const r = await db.collection("roles").doc(roleID).get();
    return r.exists ? (r.data().roleName || null) : null;
  } catch { return null; }
};

const resolveUserInfo = async (userID) => {
  if (!userID) return { customerName: "—", phone: "—" };
  try {
    const [detailDoc, userDoc] = await Promise.all([
      db.collection("userDetails").doc(userID).get(),
      db.collection("user").doc(userID).get(),
    ]);
    const { firstName = "", lastName = "" } = detailDoc.exists ? detailDoc.data() : {};
    const fullName = [firstName, lastName].filter(Boolean).join(" ").trim();
    const { phone = "—", username = "", email = "" } = userDoc.exists ? userDoc.data() : {};
    const customerName = fullName || username || email || "—";
    return { customerName, phone };
  } catch { return { customerName: "—", phone: "—" }; }
};

const resolveServiceType = async (serviceTypeID) => {
  if (!serviceTypeID) return "—";
  try {
    const doc = await db.collection("serviceType").doc(serviceTypeID).get();
    if (!doc.exists) return "—";
    // The serviceType collection's actual field is `serviceType` (see
    // customer-backend/controllers/services/services.controller.js, which
    // creates/reads this same shape) — not serviceTypeName/name.
    return doc.data().serviceType || "—";
  } catch { return "—"; }
};

// bookingID → { hasHistory, bookingSessionID, lastArchivedAt } — powers the
// "Trip History" row in the Bookings page's detail view, and the deep-link
// into Car Tracking's History tab (see routes/booking/booking.routes.js
// callers). hasHistory is true only once flushBookingHistory (below) has
// actually flushed a trail to Storage (archiveUrl set) — a session that
// exists but never got flushed still reports false, same as "no session at
// all", since either way there's nothing in History to show yet.
const EMPTY_HISTORY_INFO = {
  hasHistory: false, bookingSessionID: null, lastArchivedAt: null, startedAt: null, droppedOffTime: null,
  // { address, lat, lng } | null — set by the customer backend at booking
  // time (see bookingsession.model.js). geofenceZones carries any extra
  // stops the customer selected beyond pickup/dropoff (same field
  // CarTracking's live map and BookingInfoPanel already read) — surfaced
  // here too so Bookings.jsx's detail view can plot every stop on a map,
  // not just the two endpoints.
  pickupLocation: null, dropoffLocation: null, geofenceZones: [],
  // Booking-time Number Coding warnings from the customer app ([] on older bookings).
  codingWarnings: [],
};
// Booking-time Number Coding warnings (session.codingWarnings): a FLAT array, one entry per
// matched rule — { city, plateLastDigit, ruleID, dayOfWeek, startTime, endTime }. No timestamps
// inside, so it passes straight through. [] on older sessions.
const codingWarningsOut = (list) => (Array.isArray(list) ? list : []);
const resolveHistoryInfo = async (bookingID) => {
  if (!bookingID) return EMPTY_HISTORY_INFO;
  try {
    const snap = await db.collection("bookingSessions").where("bookingID", "==", bookingID).limit(1).get();
    if (snap.empty) return EMPTY_HISTORY_INFO;
    const data = snap.docs[0].data();
    return {
      hasHistory:       !!data.archiveUrl,
      bookingSessionID: data.bookingSessionID || null,
      lastArchivedAt:   data.lastArchivedAt || null,
      // Surfaced here (rather than a separate fetch) since this query
      // already reads the session doc for hasHistory/bookingSessionID —
      // Car Tracking's "Current trip" panel and Bookings.jsx need both to
      // show the Dropped Off marker without an extra round trip per booking.
      startedAt:        sessionStartedAt(data),
      droppedOffTime:   data.droppedOffTime || null,
      pickupLocation:   data.pickupLocation || null,
      dropoffLocation:  data.dropoffLocation || null,
      geofenceZones:    data.geofenceZones || [],
      codingWarnings:   codingWarningsOut(data.codingWarnings),
    };
  } catch { return EMPTY_HISTORY_INFO; }
};

// ─────────────────────────────────────────────
// Main service functions
// ─────────────────────────────────────────────

// The T&C number (1.00, 1.01 …) a booking agreed to. The booking only stores the immutable
// termsVersions doc ID, so the number is read from that doc. null if it can't be found.
const resolveTermsVersionNumber = async (id) => {
  try {
    const doc = await db.collection("termsVersions").doc(String(id)).get();
    return doc.exists ? (doc.data().version ?? null) : null;
  } catch {
    return null;
  }
};


// -- Cancelled bookings: who cancelled, why, when, and what happened to the money --------------------------------
// Everything the Bookings page's red "Cancelled by ..." banner shows. `all` is the booking's cancellationRequests
// rows (newest first). The system-written wording ("Cancelled: refund approved.", "Cancelled by user.") is NOT a
// reason, so it is dropped; on a refund the customer's own words are on the row that carries refundRequestID.
const SYSTEM_REASON = /^(Cancelled: refund (approved|completed)\.?|Cancelled by user\.?|Cancelled by (admin|staff)\.?)$/i;
const describeCancellation = (all, reasonRow) => {
  const approvedReq = all.find((r) => !r.cancelledBy && !r.refundRequestID && r.status === REQUEST_STATUS.APPROVED);
  const refundRow   = all.find((r) => r.refundRequestID && r.reason);
  const direct      = all.find((r) => r.cancelledBy) || null;
  let cancelledBy = null;
  if (direct) {
    cancelledBy = ["customer", "refund"].includes(direct.cancelledBy) ? "customer"
      : ["staff", "admin"].includes(direct.cancelledBy) ? "staff"
      : direct.cancelledBy === "system" ? "system" : "unknown";
  } else if (approvedReq) {
    cancelledBy = "customer";   // the customer asked to end an ongoing trip and staff approved it
  }
  let reason = String(reasonRow?.reason || "").trim();
  reason = reason.replace(/^Cancelled by (staff|admin):\s*/i, "").trim();
  if (SYSTEM_REASON.test(reason)) reason = "";
  if (!reason && direct?.cancelledBy === "refund" && refundRow) reason = String(refundRow.reason).trim();
  // The person behind it: the customer for a customer / refund / approved-request cancel, the staff member for a staff one
  // (processedBy on the direct row). For a customer cancel that staff approved, processedBy is the approver.
  // Older staff cancels never stored it, so cancelledByID is null and the page says "name not recorded".
  const cancelledByID = cancelledBy === "customer" ? (direct?.userID || approvedReq?.userID || null)
    : cancelledBy === "staff" ? (direct?.processedBy || null)
    : null;
  const approvedByID = cancelledBy === "customer" ? (direct?.processedBy || approvedReq?.processedBy || null) : null;
  return {
    cancelledBy,
    cancelledByID,
    approvedByID,
    cancelDisplayReason: reason,
    cancelledAt: direct ? (direct.createdAt || null) : (approvedReq?.processedAt || approvedReq?.updatedAt || null),
  };
};

// The booking's latest refund request, boiled down to one of: Pending | Refunded | Failed | No refund.
// A booking with no refund request gets no refundSummary (the page falls back to the payment fields).
const attachRefundSummaries = async (rows) => {
  const cancelled = rows.filter((b) => (b.status || "").toLowerCase() === "cancelled");
  const keys = [...new Set(cancelled.map((b) => bookingKeyOf(b.id, b)).filter(Boolean))];
  if (!keys.length) return;
  const byBooking = new Map();
  for (let i = 0; i < keys.length; i += 30) {
    const snap = await db.collection("refundRequests").where("bookingID", "in", keys.slice(i, i + 30)).get();
    snap.docs.forEach((d) => {
      const data = d.data();
      if (!byBooking.has(data.bookingID)) byBooking.set(data.bookingID, []);
      byBooking.get(data.bookingID).push({ id: d.id, ...data });
    });
  }
  const ms = (v) => (v?.toMillis ? v.toMillis() : v?._seconds ? v._seconds * 1000 : 0);
  cancelled.forEach((b) => {
    const list = (byBooking.get(bookingKeyOf(b.id, b)) || []).sort((x, y) => ms(y.createdAt) - ms(x.createdAt));
    const r = list[0];
    if (!r) return;
    const st = String(r.status || "").toLowerCase();
    const outcome = r.outcome || null;
    const status = st === "refunded" ? (outcome === "nothing_owed" || outcome === "already_refunded" ? "No refund" : "Refunded")
      : st === "failed" ? "Failed"
      : st === "rejected" ? "No refund"
      : "Pending";                                       // pending / approved (incl. scheduled for after midnight)
    const sendAfterDate = r.sendAfter?.toDate ? r.sendAfter.toDate() : r.sendAfter?._seconds ? new Date(r.sendAfter._seconds * 1000) : null;
    b.refundSummary = {
      status,
      refundRequestID: r.refundRequestID || r.id,
      amount: Number(r.toRefundAmount ?? r.amount ?? 0) || 0,
      bookingPaid: Number(r.bookingPaid) || 0,
      byStaff: r.source === "staff",   // the page labels a staff refund from depositForfeited / gatewayFeeKept below
      gatewayFeeKept: Number(r.gatewayFeeKept) || 0,
      depositForfeited: Number(r.depositForfeited) || 0,
      // Approved, but PayMongo is only sent after midnight (same-day payment): the page says "Sends after midnight".
      scheduled: !!sendAfterDate,
      sendAfter: sendAfterDate ? sendAfterDate.toISOString() : null,
    };
  });
};

export const getAllBookings = async (statusFilter) => {
  const filter = statusFilter?.toLowerCase();

  let rows = [];
  const seen = new Set();
  const addSnap = (snap) => snap.forEach((doc) => {
    if (seen.has(doc.id)) return;
    seen.add(doc.id);
    rows.push({ id: doc.id, ...doc.data() });
  });

  if (!filter || filter === "all") {
    // "to pay" = created but the deposit hasn't cleared yet. Shown (read-only, badge
    // in the UI) so staff can see what's pending and that the car is spoken for.
    const statuses = ["to pay", "upcoming", "ongoing", "completed", "cancelled", "stolen"];
    const snaps = await Promise.all(
      statuses.map((st) => db.collection("bookings").where("status", "==", st).get())
    );
    snaps.forEach(addSnap);
  } else if (filter === "cancellation_request") {
    // Pending requests live in the cancellationRequests collection.
    const pending = await getAllPendingRequests();
    (await getBookingsByKeys([...new Set(pending.map((r) => r.bookingID))])).forEach((b) => {
      if (seen.has(b.id)) return;
      seen.add(b.id);
      rows.push(b);
    });
  } else {
    addSnap(await db.collection("bookings").where("status", "==", filter).get());
  }

  // Every booking carries its cancellation request history (newest first) and
  // the latest one as `cancellationRequest`, so the detail view can show WHY the
  // customer asked. A booking with a PENDING request is still PRESENTED as
  // "cancellation_request" (the value the Bookings page already knows how to
  // show and act on) while its real status is kept as actualStatus.
  // Only the rows of THESE bookings are read (not the whole collection).
  const requestMap = await getRequestsByBookingKeys(rows.map((b) => bookingKeyOf(b.id, b)));
  rows = rows.map((b) => {
    const all     = requestMap.get(bookingKeyOf(b.id, b)) || [];
    const reqs    = all.filter((r) => !r.cancelledBy && !r.refundRequestID);          // real customer requests only
    const latest  = reqs[0] || null;
    const pending = reqs.some((r) => r.status === REQUEST_STATUS.PENDING);
    // Why the booking was cancelled: the direct-cancellation row, else the approved request's reason.
    const reasonRow = all.find((r) => r.cancelledBy) || all.find((r) => r.status === REQUEST_STATUS.APPROVED && r.reason);
    const cancelInfo = describeCancellation(all, reasonRow);
    const out = { ...b, cancellationRequest: latest, cancellationRequests: reqs, cancellationReason: reasonRow?.reason || "", ...cancelInfo };
    return pending && (b.status || "").toLowerCase() !== "cancelled"
      ? { ...out, actualStatus: b.status, status: "cancellation_request" }
      : out;
  });
  // Names of whoever cancelled the booking (customer or staff member) and, for a customer cancel, who approved it.
  // Staff also get their role (Owner / Admin / Supervisor).
  const nameKey = (b) => [b.cancelledByID || (b.cancelledBy === "customer" ? b.userID : null), b.approvedByID];
  const cancellerIDs = [...new Set(rows.flatMap(nameKey).filter(Boolean))];
  if (cancellerIDs.length) {
    const staffIDsToRole = new Set(rows.flatMap((b) => [b.cancelledBy === "staff" ? b.cancelledByID : null, b.approvedByID]).filter(Boolean));
    const info = Object.fromEntries(await Promise.all(cancellerIDs.map(async (id) => {
      const [u, role] = await Promise.all([resolveUserInfo(id), staffIDsToRole.has(id) ? resolveRoleName(id) : null]);
      return [id, { name: u?.customerName || null, role }];
    })));
    rows.forEach((b) => {
      const [by, appr] = nameKey(b);
      if (by)   { b.cancelledByID = by; b.cancelledByName = info[by]?.name || null; if (b.cancelledBy === "staff") b.cancelledByRole = info[by]?.role || null; }
      if (appr) { b.approvedByName = info[appr]?.name || null; b.approvedByRole = info[appr]?.role || null; }
    });
  }
  // Show WHO handled a request, not just a uid.
  const staffIDs = [...new Set(rows.map((b) => b.cancellationRequest?.processedBy).filter(Boolean))];
  if (staffIDs.length) {
    const staffMap = Object.fromEntries(await Promise.all(staffIDs.map((id) => resolveUserInfo(id).then((u) => [id, u]))));
    rows.forEach((b) => {
      const pb = b.cancellationRequest?.processedBy;
      if (pb) b.cancellationRequest = { ...b.cancellationRequest, processedByName: staffMap[pb]?.customerName || null };
    });
  }
  await attachRefundSummaries(rows);
  if (filter && filter !== "all") rows = rows.filter((b) => (b.status || "").toLowerCase() === filter);

  rows.sort((a, b) => {
    const ta = a.updatedAt?.toMillis?.() ?? 0;
    const tb = b.updatedAt?.toMillis?.() ?? 0;
    return tb - ta;
  });

  // Current driver comes from driverAssignments now (see attachCurrentDrivers).
  await attachCurrentDrivers(rows);
  await attachFinishedDrivers(rows);   // completed trips keep their driver (their assignment row is "completed", not "assigned")

  // Bookings that have a refund request in flight → shown as "For Refund".
  const openRefundSnap = await db.collection("refundRequests").where("status", "in", ["Pending", "Approved"]).get();
  const bookingsWithOpenRefund = new Set(openRefundSnap.docs.map((d) => d.data().bookingID));

  const carIDs         = [...new Set(rows.map((b) => b.carID).filter(Boolean))];
  const bookingIDs     = [...new Set(rows.map((b) => b.bookingID || b.id).filter(Boolean))];
  const userIDs        = [...new Set(rows.map((b) => b.userID).filter(Boolean))];
  const serviceTypeIDs = [...new Set(rows.map((b) => b.serviceTypeID).filter(Boolean))];
  // The current driver is the booking's "assigned" row in driverAssignments
  // (attachCurrentDrivers above puts it on each row as a read-only view). It is
  // resolved the same way as the customer (userDetails + user collections) so
  // Bookings.jsx can show who's actually driving, or that no one's assigned yet,
  // without a separate Driver Dispatch lookup.
  const driverIDs      = [...new Set(rows.map((b) => b.driverID).filter(Boolean))];

  const [vehicleEntries, paymentEntries, userEntries, driverEntries, serviceTypeEntries, historyEntries, beforeDocsEntries, afterDocsEntries, linkedWork] = await Promise.all([
    Promise.all(carIDs.map((id) => resolveVehicleName(id).then((v) => [id, v]))),
    Promise.all(bookingIDs.map((id) => resolvePaymentInfo(id).then((p) => [id, p]))),
    Promise.all(userIDs.map((id) => resolveUserInfo(id).then((u) => [id, u]))),
    Promise.all(driverIDs.map((id) => resolveUserInfo(id).then((u) => [id, u]))),
    Promise.all(serviceTypeIDs.map((id) => resolveServiceType(id).then((s) => [id, s]))),
    Promise.all(bookingIDs.map((id) => resolveHistoryInfo(id).then((h) => [id, h]))),
    Promise.all(bookingIDs.map((id) => getPhaseChecklist(id, "before").then((v) => [id, v]))),
    Promise.all(bookingIDs.map((id) => getPhaseChecklist(id, "after").then((v) => [id, v]))),
    getLinkedWorkCounts(bookingIDs),
  ]);

  const vehicleMap     = Object.fromEntries(vehicleEntries);
  const paymentMap     = Object.fromEntries(paymentEntries);
  const userMap        = Object.fromEntries(userEntries);
  const driverMap      = Object.fromEntries(driverEntries);
  const serviceTypeMap = Object.fromEntries(serviceTypeEntries);
  const historyMap     = Object.fromEntries(historyEntries);
  const beforeDocsMap  = Object.fromEntries(beforeDocsEntries);
  const afterDocsMap   = Object.fromEntries(afterDocsEntries);
  // Which T&C version each booking agreed to — one read per DISTINCT termsVersionID.
  const termsIDs = [...new Set(rows.map((b) => b.termsVersionID).filter(Boolean))];
  const termsMap = Object.fromEntries(
    await Promise.all(termsIDs.map((id) => resolveTermsVersionNumber(id).then((v) => [id, v])))
  );

  return rows.map((b) => {
    const bID     = b.bookingID || b.id;
    const payInfo = paymentMap[bID] || EMPTY_PAYMENT_INFO;
    const histInfo = historyMap[bID] || { hasHistory: false, bookingSessionID: null, lastArchivedAt: null, startedAt: null, droppedOffTime: null };
    // A cancelled booking always shows "Cancelled" payment status, matching
    // getAllPayments()'s override — the underlying payment doc's own status
    // (e.g. still "Pending") isn't what matters once the trip itself is off.
    // …EXCEPT a payment that was actually refunded: that stays "Refunded" (it used
    // to be hidden behind "Cancelled", losing the fact that the money went back).
    const isCancelled = (b.status || "").toLowerCase() === "cancelled";
    const paymentStatus = isCancelled && payInfo.paymentStatus !== "Refunded" ? "Cancelled" : payInfo.paymentStatus;
    let paymentStage = payInfo.paymentStage;
    if (paymentStage !== "Refunded") {
      if (bookingsWithOpenRefund.has(bID)) paymentStage = "For Refund";
      else if (isCancelled) paymentStage = "Cancelled";
    }
    return {
      ...b,
      vehicleName:      vehicleMap[b.carID] || "—",
      paymentMethod:    payInfo.paymentMethod,
      totalFee:         payInfo.totalFee,        // from payments.amount
      rentalFee:        payInfo.rentalFee,
      serviceFee:       payInfo.serviceFee,
      extraFee:         payInfo.extraFee,
      driversFee:       payInfo.driversFee,
      gatewayFee:       payInfo.gatewayFee,
      deposit:          payInfo.deposit,
      securityDeposit:  payInfo.securityDeposit,
      amountPaid:       payInfo.amountPaid,
      balance:          payInfo.balance,
      payType:          payInfo.payType,
      discountAmount:   payInfo.discountAmount,
      paymentStatus,
      paymentStage,
      refundDue:        payInfo.refundDue,
      refundIssued:     payInfo.refundIssued,
      depositAmount:         payInfo.depositAmount,
      depositStatus:         payInfo.depositStatus,
      confirmedPenaltyTotal: payInfo.confirmedPenaltyTotal,
      amountToReturn:        payInfo.amountToReturn,
      depositSettled:        payInfo.depositSettled,
      depositDeducted:       payInfo.depositDeducted,
      customerName:     userMap[b.userID]?.customerName || "—",
      phone:            userMap[b.userID]?.phone || "—",
      // No driverID at all (e.g. self-drive, or a chauffeur booking not yet
      // assigned) → driverName stays null so the UI can say "No driver
      // assigned" instead of a misleading "—".
      driverID:         b.driverID || null,
      driverName:       b.driverID ? (driverMap[b.driverID]?.customerName || "—") : null,
      driverPhone:      b.driverID ? (driverMap[b.driverID]?.phone || "—") : null,
      serviceTypeName:  serviceTypeMap[b.serviceTypeID] || "—",
      // T&C the customer agreed to. termsVersionID + termsAcceptedAt are already on `b`.
      // termsViewID is what /terms?version=<id> opens: the termsVersions doc ID.
      // termsVersionNumber is the readable 1.00 / 1.01.
      termsViewID:        b.termsVersionID || null,
      termsVersionNumber: b.termsVersionID ? (termsMap[b.termsVersionID] ?? null) : null,
      hasHistory:       histInfo.hasHistory,
      bookingSessionID: histInfo.bookingSessionID,
      lastArchivedAt:   histInfo.lastArchivedAt,
      startedAt:            histInfo.startedAt,
      droppedOffTime:       histInfo.droppedOffTime,
      // Every stop for this booking's trip — pickup, dropoff, and any
      // extra stops selected at booking time — so the detail view can
      // plot them on a map instead of just printing the address string.
      pickupLocation:   histInfo.pickupLocation,
      dropoffLocation:  histInfo.dropoffLocation,
      geofenceZones:    histInfo.geofenceZones,
      codingWarnings:   histInfo.codingWarnings || [],
      // "Complete" now means photos AND the parts-condition record — see
      // getPhaseChecklist in vehicleDocumentation.service.js. The
      // per-half breakdown is included for UIs that want to say which half
      // is still missing.
      beforeDocsComplete: beforeDocsMap[bID]?.complete ?? false,
      afterDocsComplete:  afterDocsMap[bID]?.complete ?? false,
      beforeInspection:   beforeDocsMap[bID] ?? { photos: false, parts: false, complete: false },
      afterInspection:    afterDocsMap[bID] ?? { photos: false, parts: false, complete: false },
      // Open maintenance / penalties tied to this booking — lets the Bookings list show which step it is on.
      ...(linkedWork.get(bID) || EMPTY_LINKED_WORK),
    };
  });
};

// Maintenance + penalty summary per booking for the Bookings list's "Phase" (current step) column. Same facts the
// booking popup fetches one booking at a time, here in batches of 30 ids (Firestore's "in" limit).
//   maintenanceTotal / maintenancePending  records filed / not yet "Completed"
//   penaltyCount / penaltyReview           penalties noted / waiting for a supervisor's review
// Never throws: on any error the list still loads and those steps just aren't flagged.
const EMPTY_LINKED_WORK = { maintenanceTotal: 0, maintenancePending: 0, penaltyCount: 0, penaltyReview: 0 };
async function getLinkedWorkCounts(bookingIDs) {
  const out = new Map();
  const entry = (id) => {
    if (!out.has(id)) out.set(id, { ...EMPTY_LINKED_WORK });
    return out.get(id);
  };
  const chunks = [];
  for (let i = 0; i < bookingIDs.length; i += 30) chunks.push(bookingIDs.slice(i, i + 30));
  try {
    await Promise.all(chunks.map(async (ids) => {
      const [mSnap, pSnap] = await Promise.all([
        db.collection("maintenance").where("bookingID", "in", ids).get(),
        db.collection("penalties").where("bookingID", "in", ids).get(),
      ]);
      mSnap.forEach((d) => {
        const m = d.data();
        const e = entry(m.bookingID);
        e.maintenanceTotal += 1;
        if (m.status !== "Completed") e.maintenancePending += 1;
      });
      pSnap.forEach((d) => {
        const p = d.data();
        const e = entry(p.bookingID);
        e.penaltyCount += 1;
        if (p.status === "UnderReview") e.penaltyReview += 1;
      });
    }));
  } catch (err) {
    console.warn("[BOOKING] getLinkedWorkCounts failed:", err.message);
  }
  return out;
}

// ─────────────────────────────────────────────
// Deposit/penalty position for a booking, read-only. Shared by the Return
// gate, settleDeposit and the Return checklist so both always agree.
//   unpaidTotal            confirmed penalties not yet paid
//   depositAvailable       the held deposit, only while it is unsettled
//   creditAvailable        discount credit held for the customer (a discount given on a fully paid booking)
//   outstandingAfterDeposit what the customer would still owe after the
//                          deposit AND the held credit are applied (0 = fully covered)
//   amountToReturn         signed: deposit + held credit minus penalties (negative = owed)
// ─────────────────────────────────────────────
const getDepositPosition = async (bID) => {
  const [paymentSnap, penalties] = await Promise.all([
    db.collection("payments").where("bookingID", "==", bID).limit(1).get(),
    listPenaltiesForBooking(bID),
  ]);
  const paymentData = paymentSnap.empty
    ? null
    : await hydratePaymentData(paymentSnap.docs[0].data(), paymentSnap.docs[0].id);
  const confirmed = penalties.filter((p) => p.status === "Confirmed");
  const unpaidTotal = confirmed.reduce((sum, p) => sum + Math.max(0, (p.amount || 0) - (p.paidAmount || 0)), 0);
  const confirmedTotal = confirmed.reduce((sum, p) => sum + (p.amount || 0), 0);   // all Confirmed penalties, paid or not
  const deposit = getDepositView(paymentData, { unpaid: unpaidTotal });
  const alreadySettled = !!deposit?.settlement;
  const held = deposit?.status === "Held" && !alreadySettled;
  const applied = held ? (deposit.applied || 0) : 0;   // already used for penalties when they were confirmed
  const depositAvailable = held ? Math.max(0, (deposit.amount || 0) - applied) : 0;
  // Discount credit held for the customer: pays what the deposit can't cover, and the rest goes back with the deposit.
  const figures = getDiscountFigures(paymentData);
  const creditAvailable = held ? figures.credit : 0;
  const creditUsed = Math.min(creditAvailable, Math.max(0, unpaidTotal - depositAvailable));
  return {
    penalties, deposit, unpaidTotal, confirmedTotal, alreadySettled, applied,
    depositStatus: deposit?.status || "—",
    depositAvailable,
    creditAvailable,                                   // discount credit still held
    creditUsed,                                        // the part of it settling would use on penalties
    creditReturn: creditAvailable - creditUsed,        // the part of it that would go back
    discountReturned: figures.returned,                // credit already returned (after settlement)
    outstandingAfterDeposit: Math.max(0, unpaidTotal - depositAvailable - creditAvailable),
    amountToReturn: depositAvailable + creditAvailable - unpaidTotal,
  };
};

// The deposit actions are opened from more than one screen: Car Tracking knows the booking's document id, the Payments
// page only knows the booking's bookingID field. Accept either, so the same endpoints serve both.
const resolveBookingDocID = async (idOrBookingID) => {
  const direct = await db.collection("bookings").doc(idOrBookingID).get();
  if (direct.exists) return idOrBookingID;
  const q = await db.collection("bookings").where("bookingID", "==", idOrBookingID).limit(1).get();
  return q.empty ? idOrBookingID : q.docs[0].id;
};

/**
 * Settle the security deposit once the booking is completed: deducts every confirmed unpaid
 * penalty from the held deposit (oldest first) and records the handback of
 * whatever is left, in one transaction (see settleBooking). Callable by the
 * driver (own trip) or a supervisor once the vehicle is dropped off — the
 * point is that whoever is physically with the customer can close out the
 * deposit without waiting for the after-trip inspection. A penalty raised
 * after this stays a normal unpaid penalty.
 */
export const settleDeposit = async (docID, { method, referenceNumber = "", online = false, completeBooking = false } = {}, performedBy = null) => {
  docID = await resolveBookingDocID(docID);
  const bookingDoc = await db.collection("bookings").doc(docID).get();
  if (!bookingDoc.exists) throw new Error("Booking not found.");
  let booking = bookingDoc.data();
  const bID = booking.bookingID || docID;

  // A booking flagged stolen is never completed (updateBooking refuses to touch it), so its deposit can't be returned here.
  if (String(booking.status || "").toLowerCase() === "stolen") {
    throw new Error("This booking was flagged as stolen, so it can't be completed and its deposit can't be returned here.");
  }

  // Payments can return the deposit of a booking that is still ongoing, on one condition: the booking is COMPLETED first,
  // in the same step. The Car Tracking completion gates (vehicle dropped off, after-trip inspection, GPS unassigned) are
  // skipped here -- they are only warnings on this screen. Everything the settlement itself needs (held deposit, no penalty
  // waiting for review, a valid way to return the money) is still checked BEFORE completing, so a refusal there never
  // leaves the booking completed with the deposit still held.
  if (completeBooking === true && String(booking.status || "").toLowerCase() === "ongoing") {
    const pre = await getDepositPosition(bID);
    if (!pre.deposit || pre.deposit.status !== "Held") {
      throw new Error(`There is no held security deposit to settle (deposit status: ${pre.depositStatus}).`);
    }
    if (pre.alreadySettled) throw new Error("This booking's deposit has already been settled.");
    const waiting = (pre.penalties || []).filter((p) => p.status === "UnderReview").length;
    if (waiting > 0) {
      throw new Error(`${waiting} penalt${waiting === 1 ? "y is" : "ies are"} still waiting for a supervisor's review. Confirm or discard ${waiting === 1 ? "it" : "them"} on the Penalties page first.`);
    }
    const preOnline = online === true || online === "true";
    if (preOnline) {
      if (!(pre.amountToReturn > 0)) throw new Error("There is nothing to return to the customer, so there is nothing to refund online.");
      const payDoc = await db.collection("payments").where("bookingID", "==", bID).limit(1).get();
      if (payDoc.empty) throw new Error("This booking has no payment record.");
      const payment = await hydratePaymentData(payDoc.docs[0].data(), payDoc.docs[0].id);
      const plan = planOnlineDepositReturn(payment, pre.amountToReturn);
      if (!plan.ok) throw new Error(plan.reason);
    } else if (pre.amountToReturn > 0 && !method) {
      throw new Error("Choose how the deposit is being returned to the customer.");
    }
    await updateBooking(docID, { status: "completed" }, performedBy, { skipReturnGates: true });
    booking = (await db.collection("bookings").doc(docID).get()).data();
  }

  // The deposit is returned only AFTER the booking is completed (Car Tracking step 3: drop-off, inspection and the GPS
  // trail are all done by then, so the penalties are final). Completing no longer waits for the deposit -- see the note
  // in updateBooking.
  if (String(booking.status || "").toLowerCase() !== "completed") {
    throw new Error(`Cannot settle the deposit yet: booking status is "${booking.status}". Complete the booking first, then return the deposit.`);
  }
  // No drop-off requirement any more: a completed booking is enough. Payments can complete an ongoing trip and return the
  // deposit in one step; the screen warns about whatever Car Tracking hasn't finished.

  const pos = await getDepositPosition(bID);
  if (!pos.deposit || pos.deposit.status !== "Held") {
    throw new Error(`There is no held security deposit to settle (deposit status: ${pos.depositStatus}).`);
  }
  if (pos.alreadySettled) throw new Error("This booking's deposit has already been settled.");
  const goOnline = online === true || online === "true";
  if (goOnline) {
    if (!(pos.amountToReturn > 0)) throw new Error("There is nothing to return to the customer, so there is nothing to refund online.");
  } else if (pos.amountToReturn > 0 && !method) {
    throw new Error("Choose how the deposit is being returned to the customer.");
  }

  // Online: check up front that PayMongo can take this refund. Nothing is saved if it can't.
  let onlinePlan = null;
  let customerUserID = null;
  if (goOnline) {
    const payDoc = await db.collection("payments").where("bookingID", "==", bID).limit(1).get();
    if (payDoc.empty) throw new Error("This booking has no payment record.");
    const payment = await hydratePaymentData(payDoc.docs[0].data(), payDoc.docs[0].id);
    onlinePlan = planOnlineDepositReturn(payment, pos.amountToReturn);
    if (!onlinePlan.ok) throw new Error(onlinePlan.reason);
    customerUserID = payment.userID || booking.userID || null;
  }

  // Settles the deposit and saves the payout rows in one transaction: the deposit's (deposit_return) and the discount
  // credit's (discount_return), separate rows. Online, they are "pending" -- the claim that makes a second click or a
  // retry fail here, before any money is sent.
  const res = await settleBooking({
    bookingID: bID, actorUid: performedBy,
    returnMethod: goOnline ? null : (method || null), returnReferenceNumber: referenceNumber,
    onlineReturn: goOnline,
    // Same-day first payment: the return is saved as scheduled (sendAfter) and the midnight cron sends it.
    sendAfter: onlinePlan?.deferred ? onlinePlan.sendAfter : null,
    paymongoPaymentID: onlinePlan?.paymongoPaymentID || null,
  });
  if (res?.error) throw new Error(res.error);

  // Only now is PayMongo called (never inside the transaction). sendOnlineReturns never throws: the deposit is already
  // settled, so a refusal is reported back and that return waits for a retry or an in-store hand-back. The deposit and the
  // discount credit are two separate PayMongo refunds, each with its own outcome.
  let onlineResult = null;
  if (goOnline && (res.returnEntryID || res.creditEntryID)) {
    onlineResult = await sendOnlineReturns({
      bookingID: bID, paymentID: res.paymentID,
      deposit: res.returnEntryID ? { entryID: res.returnEntryID, amount: res.depositReturn } : null,
      credit: res.creditEntryID ? { entryID: res.creditEntryID, amount: res.creditReturn } : null,
      paymongoPaymentID: onlinePlan.paymongoPaymentID, performedBy, customerUserID: customerUserID || res.userID || null,
      deferred: !!onlinePlan.deferred, sendAfter: onlinePlan.sendAfter || null,
    });
  }

  // In store the money is already in the customer's hands, so tell them (the online path tells them in sendOnlineReturns).
  if (!goOnline && res.net > 0) {
    notifyCustomerReturnedInStore(res.userID || booking.userID || null, bID, { deposit: res.depositReturn, credit: res.creditReturn });
  }

  createAuditLog({
    action: "update", userID: performedBy, bookingID: bID,
    description: res.net > 0
      ? `Settled deposit on booking ${bID}: penalties ₱${res.confirmedPenaltyTotal}, ₱${res.net} ${res.creditReturn > 0 ? `(₱${res.depositReturn} deposit + ₱${res.creditReturn} discount credit, as separate returns) ` : ""}${goOnline ? `being returned online through PayMongo (${onlineResult?.state === "scheduled" ? "scheduled: the first payment was made today, so the scheduled job sends it after midnight" : onlineResult?.state === "failed" ? "PayMongo refused it — needs follow-up" : onlineResult?.state === "partial" ? "one of the two was refused — needs follow-up" : "waiting for PayMongo"})` : `returned via ${method}`}.`
      : `Settled deposit on booking ${bID}: penalties ₱${res.confirmedPenaltyTotal}, ${res.outstandingAfterDeposit > 0 ? `₱${res.outstandingAfterDeposit} still owed by the customer` : "nothing to return"}.`,
  }).catch((err) => console.error("[AuditLog] Deposit settle log failed:", err.message));

  return onlineResult ? { ...res, online: onlineResult } : res;
};

// skipReturnGates: only the Payments "Return deposit" flow passes it. Completing from there no longer waits for the
// drop-off / after-trip inspection / GPS unassign checks: staff are warned on screen and confirm anyway.
export const updateBooking = async (docID, updates, performedBy = null, { skipReturnGates = false } = {}) => {
  const doc = await db.collection("bookings").doc(docID).get();
  if (!doc.exists) throw new Error("Booking not found");

  const bookingData = doc.data();
  const { status: oldStatus, userID, carID, bookingID } = bookingData;

  const nonEditable = ["completed", "cancelled", "stolen"]; // once flagged stolen, no further edits through this endpoint
  if (nonEditable.includes(oldStatus?.toLowerCase())) {
    // The one thing still allowed on a finished booking is the admin note ("Add Note"): nothing else may be sent with it.
    const sent = Object.keys(updates || {}).filter((k) => updates[k] !== undefined);
    const notesOnly = sent.length > 0 && sent.every((k) => k === "notesAdmin");
    if (!notesOnly) throw new Error(`Cannot edit a booking with status: ${oldStatus}`);

    await db.collection("bookings").doc(docID).update({ notesAdmin: String(updates.notesAdmin ?? "") });
    createAuditLog({
      action: "update", userID: performedBy, bookingID: bookingID || docID,
      description: `Updated admin note on ${String(oldStatus).toLowerCase()} booking ${bookingID || docID}`,
    }).catch((err) => console.error("[AuditLog] Note update log failed:", err.message));
    return { success: true };
  }

  // "location" (free text) is deliberately not editable: the name always comes from a map pick (stopEdits below),
  // so the text and the geofence pin can never drift apart.
  // The booking's dates are not editable either: a booking is never rescheduled from the admin side, so pickupAt,
  // startDateTime and endDateTime always stay the values the customer booked with.
  const allowed = ["notesAdmin", "notesUser", "status"];
  const filtered = {};
  allowed.forEach((k) => {
    if (updates[k] !== undefined && !(k === "status" && !updates[k])) { // "" status = "no change"
      filtered[k] = k === "status" ? updates[k].toLowerCase() : updates[k];
    }
  });

  // Only a booking that has NOT started can be cancelled here ("to pay" / "upcoming"). An ongoing trip is never cancelled:
  // the car is out, the security deposit is held, and a cancellation would leave that deposit (and any held discount
  // credit) with no way to be returned, because settlement only runs on a completed booking.
  if (filtered.status === "cancelled" && !["to pay", "upcoming"].includes(String(oldStatus || "").toLowerCase())) {
    throw new Error(
      `Cannot cancel booking ${bookingID || docID}: it is "${oldStatus}". A trip that has already started can't be cancelled -- ` +
      "reject the request instead, or drop the car off and complete the trip, then return the deposit."
    );
  }

  // The Edit form is not where money is decided. Cancelling here would skip the checks and choices of the Cancel button (an open
  // customer refund request, the refund type -- full / normal / no deposit refund --, the held deposit, held discount credit), so a booking
  // that has money collected, or an open refund request, has to be cancelled from there. A booking with nothing paid still
  // cancels from here.
  if (filtered.status === "cancelled") {
    const payKey = bookingID || docID;
    const paySnap = await db.collection("payments").where("bookingID", "==", payKey).limit(1).get();
    if (!paySnap.empty) {
      const pay = await hydratePaymentData(paySnap.docs[0].data(), paySnap.docs[0].id);
      const open = await findOpenRefundRequest(pay.paymentID || paySnap.docs[0].id).catch(() => null);
      if (open) {
        throw new Error(`Cannot cancel booking ${payKey} from here: the customer has an open refund request. Approve or reject it from the Refund Requests page.`);
      }
      if (String(pay.status || "").toLowerCase() !== "refunded" && computeRefundPlan(pay).grossPaid > 0) {
        throw new Error(`Cannot cancel booking ${payKey} from here: the customer has already paid for it. Use the Cancel button on the booking so you can choose Full refund, Normal refund, No Deposit Refund or Cancel only.`);
      }
    }
  }

  // ── Stolen only makes sense for a trip that is out on the road: the booking must be
  // ongoing and the car not yet marked dropped off (a dropped-off car is back). The Car
  // Tracking button already hides this; this stops a direct API call from skipping it. ──
  if (filtered.status === "stolen" && oldStatus?.toLowerCase() !== "stolen") {
    if (oldStatus?.toLowerCase() !== "ongoing") {
      throw new Error(`Cannot flag as stolen: booking status is "${oldStatus}", not "ongoing".`);
    }
    const stolenSession = await getSessionByBookingID(bookingID || docID);
    if (stolenSession?.data?.droppedOffTime) {
      throw new Error("Cannot flag as stolen: the car was already marked dropped off.");
    }
  }

  // ── Map-picked stops: a booking can have several locations (destination + extra
  // stops), so the admin sends stopEdits = [{ zoneIndex, oldLabel, address, lat, lng }],
  // one per stop they moved. The zones on the session move; if one of them is the
  // booking's destination, bookings.location follows its new address. ──
  let stopEdits = [];
  if (updates.stopEdits !== undefined) {
    if (!Array.isArray(updates.stopEdits)) throw new Error("stopEdits must be an array.");
    stopEdits = updates.stopEdits.map((e) => {
      const lat = Number(e?.lat), lng = Number(e?.lng);
      if (!Number.isFinite(lat) || !Number.isFinite(lng) || Math.abs(lat) > 90 || Math.abs(lng) > 180) {
        throw new Error("Invalid map coordinates for location.");
      }
      const address = String(e?.address || "").trim();
      if (!address) throw new Error("A location address is required.");
      const zoneIndex = Number.isInteger(e?.zoneIndex) && e.zoneIndex >= 0 ? e.zoneIndex : null;
      return { zoneIndex, oldLabel: String(e?.oldLabel || ""), address, lat, lng };
    });
    const seen = new Set();
    for (const e of stopEdits) {
      if (e.zoneIndex === null) continue;
      if (seen.has(e.zoneIndex)) throw new Error("The same stop was edited twice.");
      seen.add(e.zoneIndex);
    }
    const normLabel = (x) => (x || "").trim().toLowerCase();
    const destEdit = stopEdits.find((e) => normLabel(e.oldLabel) && normLabel(e.oldLabel) === normLabel(bookingData.location));
    if (destEdit) filtered.location = destEdit.address;
  }

  // ── Payment validation: cannot mark picked-up/ongoing if payment is not yet approved/paid ──
  if (filtered.status === "ongoing" && oldStatus?.toLowerCase() !== "ongoing") {
    const bID = bookingID || docID;
    const paySnap = await db.collection("payments")
      .where("bookingID", "==", bID)
      .limit(1)
      .get();

    if (paySnap.empty) {
      throw new Error("Cannot approve booking: no payment record found for this booking.");
    }

    const paymentData = await hydratePaymentData(paySnap.docs[0].data(), paySnap.docs[0].id);
    const payStatus   = paymentData.status || "";
    const approvedStatuses = ["approved", "paid"];

    if (!approvedStatuses.includes(payStatus.toLowerCase())) {
      throw new Error(
        `Cannot approve booking: payment is still "${payStatus}". ` +
        `Please approve the payment first in the Payments page.`
      );
    }

    // Balance must also be fully settled — this is a stricter rule than
    // before. Previously an approved deposit with balance > 0 was enough
    // to reach "ongoing"; now Pickup is blocked until the full balance is
    // collected (discounts included — applying a discount lowers this
    // balance the same way a payment does).
    const { balance } = computeAmounts(paymentData);
    if (balance > 0) {
      throw new Error(
        `Cannot approve booking: payment still requires action — ₱${balance.toLocaleString()} remaining. ` +
        `Collect or apply a discount for the remaining balance first.`
      );
    }
  }

  // ── Vehicle inspection validation: cannot mark picked-up/ongoing until
  // the before-trip inspection is complete — the 3 exterior photos AND the
  // parts-condition record, both entered by staff (drivers can't write
  // either, see vehicleDocumentation.routes.js). This is the real gate the
  // driver's Start Pickup goes through; the My Trips button state is just a
  // convenience mirror of it. ──
  if (filtered.status === "ongoing" && oldStatus?.toLowerCase() !== "ongoing") {
    const bID = bookingID || docID;
    const checklist = await getPhaseChecklist(bID, "before");
    if (!checklist.complete) {
      throw new Error(
        `Cannot mark picked up: the before-trip vehicle inspection is incomplete — still missing ${describeMissingInspection(checklist)}. ` +
        "A supervisor needs to complete it in Vehicle Inspections first."
      );
    }
  }

  // ── Vehicle inspection validation: cannot mark completed until
  // the after-trip inspection is complete (photos AND parts condition).
  // Mirrors the before-trip guard above so Return can't skip the
  // inspection the same way Pickup can't. ──
  if (!skipReturnGates && filtered.status === "completed" && oldStatus?.toLowerCase() === "ongoing") {
    const bID = bookingID || docID;
    const checklist = await getPhaseChecklist(bID, "after");
    if (!checklist.complete) {
      throw new Error(
        `Cannot mark complete: the after-trip vehicle inspection is incomplete — still missing ${describeMissingInspection(checklist)}. ` +
        "A supervisor needs to complete it in Vehicle Inspections first."
      );
    }
  }

  // ── Vehicle drop-off validation: cannot mark completed until
  // someone (the assigned driver, or a supervisor/staff for a no-driver
  // booking) has marked the vehicle itself physically dropped off. This is
  // the checkpoint that unblocks the after-trip inspection in the first
  // place — a supervisor can't meaningfully inspect a car that, per the
  // system, hasn't arrived yet. ──
  if (!skipReturnGates && filtered.status === "completed" && oldStatus?.toLowerCase() === "ongoing") {
    const bID = bookingID || docID;
    const session = await getSessionByBookingID(bID);
    if (!session?.data?.droppedOffTime) {
      throw new Error(
        "Cannot mark complete: the vehicle hasn't been marked dropped off yet. " +
        "Mark it dropped off first, then complete the after-trip inspection."
      );
    }
  }

  // ── GPS gate: cannot mark completed while a GPS device is still
  // assigned to this car. Unassign it first on the GPS Setup page. ──
  if (!skipReturnGates && filtered.status === "completed" && oldStatus?.toLowerCase() === "ongoing") {
    const stillAssigned = await getDevicesStillAssigned(bookingData.carID);
    if (stillAssigned.length > 0) {
      throw new Error(
        `Cannot mark complete: GPS device ${describeAssignedDevices(stillAssigned)} is still assigned to this car. ` +
        "Unassign it on the GPS Setup page first."
      );
    }
  }

  // No deposit gate here: a booking can be completed while its security deposit is still held. The deposit is
  // returned afterwards from Payments, which can also complete an ongoing booking and return the deposit in one step
  // (settleDeposit with completeBooking: it comes back through this same function, so the gates above still apply).

  // Stamp the actual return moment, once, at the exact instant Return is
  // clicked (ongoing -> completed). This is deliberately a server
  // timestamp on THIS transition only — never editable afterward (this
  // endpoint already blocks further edits to a "completed" booking via
  // the nonEditable guard above) and never derived from GPS. Note this is
  // NOT the same moment as droppedOffTime above — the vehicle can sit
  // dropped-off for a while going through inspection/penalty/device-check
  // before Return is actually confirmed.
  if (filtered.status === "completed" && oldStatus?.toLowerCase() === "ongoing") {
    filtered.completedAt = admin.firestore.FieldValue.serverTimestamp();
  }

  filtered.updatedAt = admin.firestore.FieldValue.serverTimestamp();

  // Move the destination geofence zone BEFORE saving the booking, so a failure here
  // surfaces to the admin instead of leaving the text and the pin out of sync.
  if (stopEdits.length) {
    await updateSessionStops(bookingID || docID, stopEdits);
  }

  const bookingRef = db.collection("bookings").doc(docID);
  if (filtered.status === "cancelled") {
    // A cancellation is a booking update PLUS a cancellationRequests row (the reason no
    // longer lives on the booking). Both commit together:
    //   * a customer request is still pending  -> it is the row; mark it approved
    //   * otherwise                            -> write the "direct" row
    // ("admin", not "staff": cancelledBy "staff" is what Fleet uses to find the bookings
    // it cancelled itself, so this manual edit must not be mistaken for that.)
    const bookingKey = bookingKeyOf(docID, bookingData);
    const pendingRequest = await getPendingRequest(bookingKey);
    const cancelBatch = db.batch();
    cancelBatch.update(bookingRef, filtered);
    if (pendingRequest) {
      resolveRequest(pendingRequest, { status: REQUEST_STATUS.APPROVED, processedBy: performedBy }, cancelBatch);
    } else {
      const reason = String(updates.cancellationReason ?? updates.reason ?? "").trim();
      recordDirectCancellation(bookingKey, {
        userID: userID || null,
        reason: reason || "Cancelled by admin.",
        cancelledBy: performedBy ? "admin" : "unknown",
        processedBy: performedBy,
      }, cancelBatch);
    }
    await cancelBatch.commit();
    if (pendingRequest) {
      resolveNotification("cancellation_request", docID).catch((err) =>
        console.error("[Booking] Failed to resolve cancellation_request notification:", err.message)
      );
    }
  } else {
    await bookingRef.update(filtered);
  }

  if (stopEdits.length) {
    const changes = stopEdits
      .map((e) => `"${e.oldLabel || "—"}" → "${e.address}"`)
      .join(", ");
    createAuditLog({
      action: "update",
      userID: performedBy,
      bookingID: bookingID || docID,
      description: `Moved ${stopEdits.length === 1 ? "a stop" : `${stopEdits.length} stops`} on booking ${bookingID || docID} (pin moved on map): ${changes}.`,
    }).catch((err) => console.error("[AuditLog] Location edit log failed:", err.message));
  }

  // The booking has moved on, so any "driver is waiting on the inspection"
  // reminder for it is stale: pickup clears the pickup one, and once the
  // trip is completed/cancelled/stolen nothing is left to remind about.
  // Best-effort — never blocks the status change itself.
  if (filtered.status && filtered.status !== oldStatus?.toLowerCase()) {
    const reminderKey = bookingID || docID;
    const stalePhases =
      filtered.status === "ongoing" ? ["before"]
      : ["completed", "cancelled", "stolen"].includes(filtered.status) ? ["before", "after"]
      : [];
    if (stalePhases.length) {
      resolveInspectionReminders(reminderKey, stalePhases).catch((err) =>
        console.error("[Booking] Failed to resolve inspection reminders:", err.message)
      );
    }
  }

  // ── Link booking status transitions to the GPS session lifecycle ──
  // "ongoing" = pickup happened, car is now actually on the trip. This is
  // the one place that status-vocabulary decision actually takes effect —
  // flagging it here rather than silently assuming it, since it was still
  // an open question. Session activation/ending is best-effort: a failure
  // here must never block the booking status update itself, since staff
  // still need to be able to mark a car picked up/returned even if the
  // Firestore session link is temporarily unavailable.
  if (filtered.status === "ongoing" && oldStatus?.toLowerCase() !== "ongoing") {
    const bID = bookingID || docID;
    createAuditLog({
      action: "update",
      userID: performedBy,
      bookingID: bID,
      description: `Marked pickup complete on booking ${bID}.`,
    }).catch((err) => console.error("[AuditLog] Pickup log failed:", err.message));
    try {
      const bID = bookingID || docID;
      const session = await getSessionByBookingID(bID);
      if (session) {
        await markSessionActive(session.data.bookingSessionID, carID);
        // Flush right away too — mostly just so a file actually shows up in
        // Storage the moment tracking starts, as reassurance the pipeline is
        // wired correctly, rather than only ever appearing at Return or
        // whenever tonight's cron happens to run. It'll be near-empty at
        // this exact instant (no GPS pings have landed yet), and gets
        // overwritten with the real trail as the trip progresses and again
        // at Return — this first flush is just an early proof-of-life, not
        // the final archive.
        try {
          await flushBookingHistory(session.data.bookingSessionID);
        } catch (flushErr) {
          console.error("[Booking] Pickup flush failed (session still marked active, cron will retry tonight):", flushErr.message);
        }
      } else {
        console.warn(`[Booking] No bookingSession found for booking ${bID} — GPS tracking won't start for this trip.`);
      }
    } catch (err) {
      console.error("[Booking] Failed to activate GPS session:", err.message);
    }
  } else if (filtered.status === "completed" && oldStatus?.toLowerCase() === "ongoing") {
    const bID = bookingID || docID;
    createAuditLog({
      action: "update",
      userID: performedBy,
      bookingID: bID,
      description: `Marked complete on booking ${bID}.`,
    }).catch((err) => console.error("[AuditLog] Return log failed:", err.message));
    try {
      const bID = bookingID || docID;
      const session = await getSessionByBookingID(bID);
      if (session) {
        await markSessionEnded(session.data.bookingSessionID);
        // Flush the full trail to Storage right now — this is the "Return"
        // action, no reason to make the history file wait for tonight's
        // cron when the trip is already over.
        try {
          await flushBookingHistory(session.data.bookingSessionID);
        } catch (flushErr) {
          console.error("[Booking] Return flush failed (session still marked ended, cron will retry tonight):", flushErr.message);
        }
      }
    } catch (err) {
      console.error("[Booking] Failed to end GPS session:", err.message);
    }
  } else if (filtered.status === "cancelled" && oldStatus?.toLowerCase() !== "cancelled") {
    try {
      const bID = bookingID || docID;
      const session = await getSessionByBookingID(bID);
      if (session) {
        await markSessionCancelled(session.data.bookingSessionID);
      } else {
        console.warn(`[Booking] No bookingSession found for booking ${bID} — nothing to cancel.`);
      }
    } catch (err) {
      console.error("[Booking] Failed to cancel GPS session:", err.message);
    }
  } else if (filtered.status === "stolen" && oldStatus?.toLowerCase() !== "stolen") {
    // Manual only — set by staff hitting "Stolen" on the car card. No
    // auto-trigger off geofence breach.
    try {
      const bID = bookingID || docID;
      const session = await getSessionByBookingID(bID);
      if (session) {
        await markSessionStolen(session.data.bookingSessionID);
        // Same as Return — flush the trail immediately for documentation
        // rather than waiting for the nightly cron. This is manual/admin-
        // triggered, so there's no reason to delay the record.
        try {
          await flushBookingHistory(session.data.bookingSessionID);
        } catch (flushErr) {
          console.error("[Booking] Stolen flush failed (session still marked stolen, cron will retry tonight):", flushErr.message);
        }
      } else {
        console.warn(`[Booking] No bookingSession found for booking ${bID} — cannot flag session stolen.`);
      }
    } catch (err) {
      console.error("[Booking] Failed to flag session stolen:", err.message);
    }
  }

  // -- Trip over -> close the driver's assignment row (best effort) --
  if (["completed", "cancelled", "stolen"].includes(filtered.status)) {
    completeActiveAssignment(bookingID || docID).catch((err) =>
      console.error("[Booking] Failed to close driver assignment:", err.message)
    );
  }

  // ── Auto-delete the "new booking" notification once the booking is handled ──
  const newStatus = filtered.status;
  const activeStatuses = ["upcoming", "cancellation_request"];
  const resolvedStatuses = ["upcoming", "ongoing", "completed", "cancelled", "stolen"];
  if (
    newStatus &&
    newStatus !== oldStatus?.toLowerCase() &&
    activeStatuses.includes(oldStatus?.toLowerCase()) &&
    resolvedStatuses.includes(newStatus)
  ) {
    // The "new booking" notification is no longer actionable, so remove it
    try {
      const bID = bookingID || docID;
      const notifSnap = await db.collection("notifications")
        .where("bookingID", "==", bID)
        .where("type", "==", "new_booking")
        .get();
      if (!notifSnap.empty) {
        const batch = db.batch();
        notifSnap.docs.forEach(d => batch.delete(d.ref));
        await batch.commit();
        console.log(`[NOTIF] Auto-deleted ${notifSnap.size} new_booking notif(s) for booking: ${bID}`);
      }
    } catch (err) {
      console.error("[NOTIF] Failed to delete booking notifications:", err.message);
    }
  }

  return { success: true };
};

// ─────────────────────────────────────────────
// Mark the vehicle itself physically dropped off — every booking type,
// not just chauffeur. Distinct from Return: the session stays "active",
// only the timestamp changes, and Return itself stays blocked until
// inspection/penalties/device-check are also cleared (see updateBooking's
// "completed" gates above). See bookingsession.model.js for why this is
// never auto-filled/backfilled.
// ─────────────────────────────────────────────
export const markBookingDroppedOff = async (docID, performedBy = null) => {
  const bookingRef = db.collection("bookings").doc(docID);
  const bookingDoc = await bookingRef.get();
  if (!bookingDoc.exists) throw new Error("Booking not found.");
  const booking = bookingDoc.data();

  if (booking.status?.toLowerCase() !== "ongoing") {
    throw new Error(`Cannot mark dropped off: booking status is "${booking.status}", not "ongoing" (has it been picked up yet?).`);
  }

  const bID = booking.bookingID || docID;
  const session = await getSessionByBookingID(bID);
  if (!session) throw new Error("No active trip session found for this booking.");
  if (session.data.droppedOffTime) {
    throw new Error("Already marked dropped off — this can't be re-triggered or edited.");
  }

  await markDroppedOff(session.ref.id);
  createAuditLog({
    action: "update",
    userID: performedBy,
    bookingID: bID,
    description: `Marked vehicle dropped off on booking ${bID}.`,
  }).catch((err) => console.error("[AuditLog] Dropoff log failed:", err.message));

  // Save the history file right now so the drop-off time is in it immediately (not only after Return or the
  // nightly job). This does NOT end the trip: the session stays active, pings keep being recorded, and the
  // nightly save continues. Same rule as the pickup save: a failure here must never undo the drop-off.
  try {
    await flushBookingHistory(session.ref.id);
  } catch (err) {
    console.error("[Booking] Drop-off history save failed (drop-off itself was recorded):", err.message);
  }
  return { id: docID };
};

// ─────────────────────────────────────────────
// GPS-unassigned requirement at Return. Before a booking can be marked
// returned, the tracker must have been detached from the car (GPS Setup
// page → Unassign). Returns the gpsDevice docs still assigned to this
// car — an empty array means the car is clear to return. The `assigned`
// filter is done in JS so this needs no composite Firestore index.
// ─────────────────────────────────────────────
const getDevicesStillAssigned = async (carID) => {
  if (!carID) return [];
  const snap = await db.collection("gpsDevice").where("carID", "==", carID).get();
  return snap.docs.map((d) => d.data()).filter((d) => d.assigned === true);
};

const describeAssignedDevices = (devices) =>
  devices.map((d) => d.gpsName || d.gpsDeviceID).join(", ");

// ─────────────────────────────────────────────
// Read-only pre-return checklist — never blocks anything, just reports
// where a booking stands against every Return requirement, so the
// frontend can show a "here's what's still missing" panel instead of a
// disabled/greyed-out button. The actual enforcement lives in
// updateBooking's "completed" gates above; this is purely a mirror of
// those same checks for display purposes.
// ─────────────────────────────────────────────
export const getReturnChecklist = async (docID) => {
  docID = await resolveBookingDocID(docID);
  const bookingRef = db.collection("bookings").doc(docID);
  const bookingDoc = await bookingRef.get();
  if (!bookingDoc.exists) throw new Error("Booking not found.");
  const booking = bookingDoc.data();
  const bID = booking.bookingID || docID;

  const [session, afterChecklist, pos, assignedDevices] = await Promise.all([
    getSessionByBookingID(bID),
    getPhaseChecklist(bID, "after"),
    getDepositPosition(bID),
    getDevicesStillAssigned(booking.carID),
  ]);

  const droppedOff = !!session?.data?.droppedOffTime;
  const holdsDeposit = pos.deposit?.status === "Held" && !pos.alreadySettled;
  // Penalties a driver noted that no supervisor has confirmed yet: settling now would return the whole deposit and
  // leave them as money owed later, so the server refuses (see settleBooking) and the screen says why up front.
  const underReviewCount = (pos.penalties || []).filter((p) => p.status === "UnderReview").length;
  const isCompleted = String(booking.status || "").toLowerCase() === "completed";
  const isOngoing = String(booking.status || "").toLowerCase() === "ongoing";
  const settlement = pos.deposit?.settlement || null;
  // Can the deposit go back through PayMongo? Only while it is still to be returned, and only for GCash / Maya.
  const onlineOption = holdsDeposit && pos.amountToReturn > 0
    ? await onlineDepositReturnOption(bID, pos.amountToReturn)
    : { available: false, reason: null };

  const items = [
    {
      key: "droppedOff",
      label: "Vehicle dropped off",
      complete: droppedOff,
      detail: droppedOff ? null : "Nobody has marked the vehicle physically dropped off yet.",
    },
    {
      key: "inspection",
      label: "After-trip vehicle inspection",
      complete: !!afterChecklist.complete,
      detail: afterChecklist.complete ? null : `Still missing ${describeMissingInspection(afterChecklist)}.`,
    },
    {
      key: "gpsUnassigned",
      label: "GPS device unassigned",
      complete: assignedDevices.length === 0,
      detail: assignedDevices.length === 0
        ? null
        : `${describeAssignedDevices(assignedDevices)} is still assigned to this car. Unassign it on the GPS Setup page first.`,
    },
  ];

  return {
    bookingID: bID,
    canReturn: items.every((i) => i.complete),
    canSettle: isCompleted && droppedOff && holdsDeposit && underReviewCount === 0,
    // Payments can complete an ongoing booking and return its deposit in one step. Unmet Return requirements (items) are only shown as a warning.
    canCompleteAndSettle: isOngoing && holdsDeposit && underReviewCount === 0,
    bookingStatus: booking.status || null,
    underReviewCount,
    onlineReturn: onlineOption,   // { available, channel?, scheduled?, sendAfter?, reason? }  (scheduled = same-day payment: sent by the midnight cron)
    items,
    driverID: await resolveCurrentDriverID(booking, docID),
    depositStatus: pos.depositStatus,
    depositHeld: pos.deposit?.amount ?? null,
    depositSettled: !!settlement,
    // Pesos of the deposit used for penalties: what is already deducted + what settling would still take (capped at the deposit).
    depositDeducted: settlement ? (pos.deposit.deducted || 0) : Math.min(pos.deposit?.amount || 0, (pos.applied || 0) + pos.unpaidTotal),
    // Before settlement: deposit minus penalties (negative = customer owes).
    // After settlement: what was actually returned (depositReturned) / is still owed (the unpaid penalties, live).
    penaltyTotal: settlement ? pos.confirmedTotal : pos.unpaidTotal + (pos.applied || 0),
    amountToReturn: settlement ? (pos.unpaidTotal > 0 ? -pos.unpaidTotal : (pos.deposit.returnedAmount || 0) + (pos.discountReturned || 0)) : pos.amountToReturn,
    // The discount credit held for the customer, as the part of that amount that is NOT the deposit. creditUsed would pay
    // penalties the deposit can't; creditReturn goes back with the deposit. Both are 0 when no discount credit is held.
    discountCredit: pos.creditAvailable,
    discountCreditUsed: pos.creditUsed,
    discountCreditReturn: settlement ? (pos.discountReturned || 0) : pos.creditReturn,
    // Still-unpaid penalty money right now (includes penalties raised after settling).
    stillOwed: pos.outstandingAfterDeposit,
    outstandingAfterDeposit: pos.outstandingAfterDeposit,
    penalties: pos.penalties,
    depositReturn: await getDepositReturnForBooking(bID),   // how/whether the deposit went back: in store, or PayMongo (processing / failed / refunded)
  };
};

// ─────────────────────────────────────────────
// Approve / reject a pending cancellation_request — the customer-side
// counterpart of this lives in customer-backend's requestCancellation()
// (bookings.controller.js), which is the only thing that ever sets a
// booking to "cancellation_request" in the first place. bookingWatcher.js
// used to auto-resolve the notification when status left that state;
// now that the watcher is gone, these two actions resolve it directly,
// same pattern as every other direct-write notification in this codebase.
// ─────────────────────────────────────────────

// A pending request is a row in cancellationRequests.
const findPendingCancellation = async (docID, booking) => {
  const request = await getPendingRequest(bookingKeyOf(docID, booking));
  return { request, pending: !!request };
};

// A cancellation request is only honoured while the booking has NOT started ("to pay" / "upcoming"). Once the trip is
// ongoing the car is out, the security deposit is held and the rental is in use: cancelling it would move no money and
// leave the deposit (and any held discount credit) unreturnable, because settlement only runs on a COMPLETED booking.
// Staff reject the request, or complete the trip (drop-off, inspection) and return the deposit as usual.
const assertCancellableStatus = (status, label) => {
  const s = String(status || "").toLowerCase();
  if (!["to pay", "upcoming"].includes(s)) {
    throw new Error(
      `Cannot approve: booking ${label} is "${status}". A trip that has already started can't be cancelled -- ` +
      "reject the request instead, or drop the car off and complete the trip, then return the deposit."
    );
  }
};

export const approveCancellationRequest = async (docID, performedBy = null) => {
  const bookingRef = db.collection("bookings").doc(docID);
  const bookingDoc = await bookingRef.get();
  if (!bookingDoc.exists) throw new Error("Booking not found.");
  const booking = bookingDoc.data();

  const { request, pending } = await findPendingCancellation(docID, booking);
  if (!pending) {
    throw new Error(`Cannot approve: booking ${docID} has no pending cancellation request (status is "${booking.status}").`);
  }
  assertCancellableStatus(booking.status, booking.bookingID || docID);

  const now = new Date();
  // One transaction: the request is marked approved and the booking cancelled together,
  // and both are re-read inside it, so two staff approving at once (or approving a request
  // someone just rejected, or a trip that already ended) cannot both go through.
  // The customer's own words stay on the request row; the booking list reads the
  // cancellation reason from there.
  await db.runTransaction(async (t) => {
    const [reqSnap, bookingSnap] = await Promise.all([t.get(request.ref), t.get(bookingRef)]);
    if (!reqSnap.exists || reqSnap.data().status !== REQUEST_STATUS.PENDING) {
      throw new Error(`Cannot approve: the cancellation request for booking ${docID} was already handled.`);
    }
    const current = String(bookingSnap.data()?.status || "").toLowerCase();
    if (["cancelled", "completed", "stolen"].includes(current)) {
      throw new Error(`Cannot approve: booking ${docID} is already ${current}.`);
    }
    assertCancellableStatus(current, booking.bookingID || docID);   // re-checked inside the transaction: the trip may have started since
    resolveRequest(request, { status: REQUEST_STATUS.APPROVED, processedBy: performedBy }, t);
    t.update(bookingRef, { status: "cancelled", updatedAt: now });
  });

  // Mirror onto the session doc, same as the customer's own instant-cancel
  // path already does for "upcoming" bookings.
  try {
    const bID = booking.bookingID || docID;
    const session = await getSessionByBookingID(bID);
    if (session) {
      await markSessionCancelled(session.ref.id);
    }
  } catch (err) {
    console.error("[BOOKINGS] approveCancellationRequest: failed to sync bookingSession:", err.message);
  }

  completeActiveAssignment(booking.bookingID || docID).catch((err) =>
    console.error("[BOOKINGS] approveCancellationRequest: failed to close driver assignment:", err.message)
  );

  // Resolves every Owner/Admin/Supervisor's own copy of this notification
  // at once -- see notification.service.js's resolveNotification() header
  // comment for why no userID filter is needed here.
  await resolveNotification("cancellation_request", docID).catch((err) =>
    console.error("[BOOKINGS] approveCancellationRequest: failed to resolve notification:", err.message)
  );

  auditSafe({
    action: "update",
    description: `Cancellation request for booking ${booking.bookingID || docID} APPROVED -- booking cancelled.`,
    userID: performedBy,
    bookingID: booking.bookingID || docID,
  });

  return { id: docID, status: "cancelled" };
};

export const rejectCancellationRequest = async (docID, rejectReason, performedBy = null) => {
  const bookingRef = db.collection("bookings").doc(docID);
  const bookingDoc = await bookingRef.get();
  if (!bookingDoc.exists) throw new Error("Booking not found.");
  const booking = bookingDoc.data();

  const { request, pending } = await findPendingCancellation(docID, booking);
  if (!pending) {
    throw new Error(`Cannot reject: booking ${docID} has no pending cancellation request (status is "${booking.status}").`);
  }

  // The booking's status never changed while the request was pending, so there is
  // nothing to restore; only the request row is resolved.
  const revertTo = booking.status;

  const now = new Date();
  await db.runTransaction(async (t) => {
    const reqSnap = await t.get(request.ref);
    if (!reqSnap.exists || reqSnap.data().status !== REQUEST_STATUS.PENDING) {
      throw new Error(`Cannot reject: the cancellation request for booking ${docID} was already handled.`);
    }
    resolveRequest(request, { status: REQUEST_STATUS.REJECTED, processedBy: performedBy, rejectReason }, t);
    t.update(bookingRef, { updatedAt: now });
  });

  await resolveNotification("cancellation_request", docID).catch((err) =>
    console.error("[BOOKINGS] rejectCancellationRequest: failed to resolve notification:", err.message)
  );

  auditSafe({
    action: "update",
    description: `Cancellation request for booking ${booking.bookingID || docID} REJECTED${rejectReason ? `: ${rejectReason}` : ""}.`,
    userID: performedBy,
    bookingID: booking.bookingID || docID,
  });

  return { id: docID, status: revertTo };
};

// ─────────────────────────────────────────────
// History flush
//
// Compiles a session's full GPS trail into one permanent JSON file in
// Firebase Storage under bookingHistory/. The trail is read from Google
// Sheets (one tab per PHT date, shared by every car — see
// services/sheets/sheets.service.js) across every PHT date the session
// spans; it no longer comes from a Firestore archive/{date} sub-collection.
// (Lived in services/storage/bookingHistory.service.js, then bookingSession.service.js;
// now here so booking.service.js owns the whole booking → history flow.)
// ─────────────────────────────────────────────

/**
 * When a booking was marked completed (ISO string), or null. Looks the booking up by document id first, then by
 * its bookingID field. Never throws: callers use it for display/history, so a failed lookup just means "unknown".
 */
export const getBookingCompletedAt = async (bID) => {
  try {
    if (!bID) return null;
    let bSnap = await db.collection("bookings").doc(bID).get();
    if (!bSnap.exists) {
      const q = await db.collection("bookings").where("bookingID", "==", bID).limit(1).get();
      bSnap = q.empty ? null : q.docs[0];
    }
    const d = toDate(bSnap?.data()?.completedAt);
    return d && !isNaN(d.getTime()) ? d.toISOString() : null;
  } catch (err) {
    console.error("[Booking] couldn't read completedAt:", err.message);
    return null;
  }
};

export const flushBookingHistory = async (bookingSessionID) => {
  const session = await getSessionById(bookingSessionID);
  if (!session) {
    throw new Error(`Booking session not found: ${bookingSessionID}`);
  }
  const { data } = session;

  // Start of the range = the REAL start of the trip (startedAt, stamped at
  // pickup), not the booking's scheduled date — so an early pickup (a booking
  // for Oct 23 handed over on Sep 28) reads the right Sheets date-tabs instead
  // of coming back empty. For sessions from before startedAt existed we also
  // look at droppedOffTime / lastArchivedAt / last ping and take the earliest
  // known real moment. If nothing is known at all (never started), start = now,
  // i.e. just today's tab.
  const realMoments = [sessionStartedAt(data), toDate(data.droppedOffTime), toDate(data.lastArchivedAt), toDate(data.currentPosition?.date)]
    .filter((d) => d && !isNaN(d.getTime()));
  const pickup = realMoments.length
    ? new Date(Math.min(...realMoments.map((d) => d.getTime())))
    : new Date();
  // Flushing always happens at or after the real event, and no ping can be
  // dated in the future — so "now" is the true upper bound (no wasted reads of
  // Sheets tabs that don't exist yet).
  const end = new Date();
  const dateStrings = datesBetweenPHT(pickup, end);

  const rows = await fetchSessionRows(data.carID, bookingSessionID, dateStrings);
  const fullTrail = rows
    .filter((r) => typeof r.lat === "number" && typeof r.lng === "number" && r.at)
    .map((r) => ({ lat: r.lat, lng: r.lng, at: r.at, speed: r.speed ?? 0, offline: r.offline === true }))
    .sort((a, b) => new Date(a.at) - new Date(b.at));

  const filePath = `bookingHistory/${bookingSessionID}.json`;
  const file = bucket.file(filePath);

  // Shape changed from a bare points array to an object carrying this trip's
  // geofence zones + alert timeline (and coding-restriction alerts) alongside
  // the trail, so History → Review can reconstruct breach state on playback
  // instead of only showing the dots. Older archive files already in Storage
  // stay as bare arrays — the frontend handles both shapes.
  //
  // droppedOffAt / completedAt / holidays are extra review details so a saved
  // trip can be read later without the live records: when the car was marked
  // dropped off, when the booking was marked completed (null until then — this
  // file is also written at pickup and by the nightly cron), and the holidays
  // that fell inside the trip's dates. Gathering them must never block the
  // save itself, so each lookup falls back to null / [].
  const iso = (v) => { const d = toDate(v); return d && !isNaN(d.getTime()) ? d.toISOString() : null; };
  const completedAt = await getBookingCompletedAt(data.bookingID);
  let holidays = [];
  try {
    holidays = await getHolidaysBetween(pickup, end);
  } catch (err) {
    console.error("[Booking] flush: couldn't read holidays:", err.message);
  }

  // `session` makes the file readable on its own: History, Review and the downloaded copy no longer need the
  // session record to know how the trip ended or when. IDs and times only -- this file is publicly readable,
  // so no customer or staff names go in. endedAt is the time the trip really ended: completion for a completed
  // trip, null while it is still going (a drop-off is NOT an end). A stolen car keeps pinging, so it has no end:
  // stolenAt is its own marker (the time it was flagged), same as sessionEndedAt treats stolen as "still going".
  const stolenAt = iso(data.stolenAt);
  const endedAt = data.status === "ended" ? (completedAt || iso(sessionEndedAt(data))) : null;
  const archivePayload = {
    session: {
      bookingSessionID,
      bookingID:    data.bookingID || null,
      carID:        data.carID || null,
      status:       data.status || null,
      startedAt:    iso(sessionStartedAt(data)),
      droppedOffAt: iso(data.droppedOffTime),
      completedAt,
      stolenAt,
      endedAt,
    },
    points: fullTrail,
    geofenceZones:  data.geofenceZones  || [],
    geofenceAlerts: data.geofenceAlerts || [],
    codingAlerts:   data.codingAlerts   || [],
    codingWarnings: codingWarningsOut(data.codingWarnings),
    droppedOffAt:   iso(data.droppedOffTime),
    completedAt,
    holidays,
  };

  // Compact JSON (no indentation): same data, a fraction of the size for a long GPS trail.
  await file.save(JSON.stringify(archivePayload), {
    contentType: "application/json",
    metadata: { cacheControl: "no-cache" },
  });
  await file.makePublic();

  const archiveUrl = `https://storage.googleapis.com/${bucket.name}/${filePath}`;
  // A save made after the trip ended / was flagged stolen is the final one: it clears the retry flag.
  await recordArchiveFlush(bookingSessionID, archiveUrl, { final: data.status === "ended" || data.status === "stolen" });

  return archiveUrl;
};