import { db, bucket } from "../../config/firebaseConnection/firebase.js";
import admin from "firebase-admin";
import { getSessionById, recordArchiveFlush, getSessionByBookingID, markSessionActive, markSessionEnded, markSessionCancelled, markSessionStolen, markDroppedOff, updateSessionDestination, updateSessionStops } from "../../services/booking/bookingSession.service.js";
import { toDate, sessionStartedAt } from "../../utils/date/sessionDates.js";
import { fetchSessionRows } from "../../services/sheets/sheets.service.js";
import { datesBetweenPHT } from "../../utils/date/phtDate.js";
import { getPhaseChecklist, describeMissingInspection } from "../../services/vehicleDocumentation/vehicleDocumentation.service.js";
import { resolveInspectionReminders } from "../../services/inspectionReminders/inspectionReminders.service.js";
import { computeAmounts, derivePaymentStage } from "../../services/payments/payments.service.js";
import { resolveNotification } from "../../services/notification/notification.service.js";
import { createAuditLog, auditSafe } from "../../services/auditLogs/auditLogs.service.js";
import { listPenaltiesForBooking, settleBooking } from "../../services/penalty/penalty.service.js";
import { getDepositView } from "../payments/paymentHelpers.js";
import { hydratePaymentData } from "../../services/paymentEntries/paymentEntries.service.js";
import { getHolidaysBetween } from "../gps/coding.service.js";
import {
  bookingKeyOf, attachCurrentDrivers, resolveCurrentDriverID, getBookingsByKeys, completeActiveAssignment,
} from "../../services/driverAssignments/driverAssignments.service.js";
import {
  REQUEST_STATUS, getPendingRequest, getAllPendingRequests, getRequestsByBookingKeys, resolveRequest, recordDirectCancellation,
} from "../../services/cancellationRequests/cancellationRequests.service.js";
// ─────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────

export const resolveVehicleName = async (carID) => {
  if (!carID) return "—";
  try {
    const carDoc = await db.collection("cars").doc(carID).get();
    if (!carDoc.exists) return "—";
    const { modelID } = carDoc.data();
    if (!modelID) return "—";
    const modelDoc = await db.collection("model").doc(modelID).get();
    if (!modelDoc.exists) return "—";
    const { brandID, modelName } = modelDoc.data();
    const brandDoc = await db.collection("brand").doc(brandID).get();
    const brandName = brandDoc.exists ? brandDoc.data().brandName : "";
    return [brandName, modelName].filter(Boolean).join(" ") || "—";
  } catch { return "—"; }
};

// bookingID → { paymentMethod, totalFee, rentalFee, serviceFee,
// extraFee, amountPaid, balance, payType, paymentStatus } from payments
// collection. totalFee comes from payments.amount; the fee breakdown comes
// straight off the same doc. amountPaid/balance/payType are derived via the
// shared computeAmounts() (same logic payments.service.js uses for
// /api/payments), so these numbers can't drift between Bookings, Car
// Tracking, and driver-facing screens. paymentStatus mirrors the "Paid" →
// "Approved" normalization getAllPayments() applies, so badge styling in
// PaymentStatusModal lines up regardless of which endpoint fed it; a
// cancelled *booking* still forces "Cancelled" (applied by the caller,
// which has b.status handy — see getAllBookings below).
const EMPTY_PAYMENT_INFO = {
  paymentMethod: "—", totalFee: 0, rentalFee: 0, serviceFee: 0, extraFee: 0,
  driversFee: 0, gatewayFee: 0, securityDeposit: 0, deposit: null,
  amountPaid: 0, balance: 0, payType: "—", paymentStatus: "—", paymentStage: "—", discountAmount: 0,
  refundDue: 0, refundIssued: false,
  // Deposit / penalty breakdown — same "what should actually come back to
  // the customer" math as settleBooking() in penalty.service.js (deposit
  // held minus every unpaid Confirmed penalty, still-negative-allowed).
  // Read-only here, just a live preview for staff before Return actually
  // runs settlement — mirrors the same fields the driver's My Trips
  // Payments button already gets via driverDispatch.service.js, so a
  // supervisor confirming/collecting payment on Car Tracking while a
  // booking is still ongoing can see the rightful return amount instead
  // of only finding out once Return triggers the real deduction.
  depositAmount: 0, depositStatus: "—", confirmedPenaltyTotal: 0, amountToReturn: 0,
  depositSettled: false, depositDeducted: 0,
};
export const resolvePaymentInfo = async (bookingID) => {
  if (!bookingID) return EMPTY_PAYMENT_INFO;
  try {
    const snap = await db.collection("payments")
      .where("bookingID", "==", bookingID)
      .limit(1)
      .get();
    if (snap.empty) return EMPTY_PAYMENT_INFO;
    // Hydrated so paymentMethod / referenceNumber etc. still resolve once the
    // moved fields are cleaned off the payment doc (they live in paymentEntries).
    const data = await hydratePaymentData(snap.docs[0].data(), snap.docs[0].id);
    const { amountPaid, balance, payType, refundDue } = computeAmounts(data);
    let paymentStatus = data.status || "Pending";
    if (paymentStatus.toLowerCase() === "paid") paymentStatus = "Approved";

    const penalties = await listPenaltiesForBooking(bookingID);
    const confirmedPenaltyTotal = penalties
      .filter((p) => p.status === "Confirmed")
      .reduce((sum, p) => sum + Math.max(0, (p.amount || 0) - (p.paidAmount || 0)), 0);
    // null = never recorded; same view for flat and old nested storage. The unpaid total is the live shortfall.
    const deposit = getDepositView(data, { unpaid: confirmedPenaltyTotal });
    const depositAmount = deposit?.amount || 0;
    const depositStatus = deposit?.status || "—";
    // Before settlement this is a live preview: deposit minus every unpaid
    // Confirmed penalty, still-negative-allowed (same as settleBooking()'s
    // `net`). AFTER settlement the deposit has already paid those penalties
    // out, so they now read as paid and the unpaid total falls to 0 —
    // recomputing would show the FULL deposit as "to return" again. So once
    // settled, report what actually happened instead: anything still unpaid
    // right now is owed by the customer (negative), otherwise it's the
    // amount that was handed back (depositReturned).
    const settlement = deposit?.settlement || null;
    const depositSettled = !!settlement;
    const depositDeducted = deposit?.deducted || 0;
    const amountToReturn = settlement
      ? (confirmedPenaltyTotal > 0 ? -confirmedPenaltyTotal : Math.max(0, deposit.returnedAmount || 0))
      : depositAmount - confirmedPenaltyTotal;

    return {
      paymentMethod: data.paymentMethod || "—",
      totalFee:      data.amount        ?? 0,
      rentalFee:     data.rentalFee     ?? 0,
      serviceFee:    data.serviceFee    ?? 0,
      extraFee:      data.extraFee      ?? 0,
      driversFee:    data.driversFee    ?? 0,
      gatewayFee:    data.gatewayFee    ?? 0,
      // Refundable deposit charged as part of `amount` (0 on older bookings).
      securityDeposit: Number(data.securityDeposit) || 0,
      // The REAL security deposit (depositStatus & co on the payment, written by
      // penalty.service.js's waiveDeposit/settleBooking) — a light read-only
      // summary (no Firestore timestamps). null = never recorded yet. Not the
      // legacy depositFee. The API shape is unchanged from when it was a nested object.
      deposit: deposit ? {
        amount:         deposit.amount,
        status:         deposit.status,
        returnedAmount: deposit.returnedAmount,
      } : null,
      amountPaid,
      balance,
      payType,
      paymentStatus,
      // Pending / Partial / Completed / Failed / Refunded — the vocabulary staff
      // see. getAllBookings layers "Cancelled" and "For Refund" on top (it knows
      // the booking's status and any open refund request).
      paymentStage: derivePaymentStage(data),
      discountAmount: Number(data.discountAmount) || 0,
      refundDue,
      refundIssued: !!data.refundIssued,
      depositAmount, depositStatus, confirmedPenaltyTotal, amountToReturn,
      depositSettled, depositDeducted,
    };
  } catch { return EMPTY_PAYMENT_INFO; }
};

const resolveUserInfo = async (userID) => {
  if (!userID) return { customerName: "—", phone: "—" };
  try {
    const [detailDoc, userDoc] = await Promise.all([
      db.collection("userDetails").doc(userID).get(),
      db.collection("user").doc(userID).get(),
    ]);
    const { firstName = "", lastName = "" } = detailDoc.exists ? detailDoc.data() : {};
    const fullName = [firstName, lastName].filter(Boolean).join(" ").trim();
    const { phone = "—", username = "", email = "" } = userDoc.exists ? userDoc.data() : {};
    const customerName = fullName || username || email || "—";
    return { customerName, phone };
  } catch { return { customerName: "—", phone: "—" }; }
};

const resolveServiceType = async (serviceTypeID) => {
  if (!serviceTypeID) return "—";
  try {
    const doc = await db.collection("serviceType").doc(serviceTypeID).get();
    if (!doc.exists) return "—";
    // The serviceType collection's actual field is `serviceType` (see
    // customer-backend/controllers/services/services.controller.js, which
    // creates/reads this same shape) — not serviceTypeName/name.
    return doc.data().serviceType || "—";
  } catch { return "—"; }
};

// bookingID → { hasHistory, bookingSessionID, lastArchivedAt } — powers the
// "Trip History" row in the Bookings page's detail view, and the deep-link
// into Car Tracking's History tab (see routes/booking/booking.routes.js
// callers). hasHistory is true only once flushBookingHistory (below) has
// actually flushed a trail to Storage (archiveUrl set) — a session that
// exists but never got flushed still reports false, same as "no session at
// all", since either way there's nothing in History to show yet.
const EMPTY_HISTORY_INFO = {
  hasHistory: false, bookingSessionID: null, lastArchivedAt: null, startedAt: null, droppedOffTime: null,
  // { address, lat, lng } | null — set by the customer backend at booking
  // time (see bookingsession.model.js). geofenceZones carries any extra
  // stops the customer selected beyond pickup/dropoff (same field
  // CarTracking's live map and BookingInfoPanel already read) — surfaced
  // here too so Bookings.jsx's detail view can plot every stop on a map,
  // not just the two endpoints.
  pickupLocation: null, dropoffLocation: null, geofenceZones: [],
  // Booking-time Number Coding warnings from the customer app ([] on older bookings).
  codingWarnings: [],
};
// Booking-time Number Coding warnings (session.codingWarnings): a FLAT array, one entry per
// matched rule — { city, plateLastDigit, ruleID, dayOfWeek, startTime, endTime }. No timestamps
// inside, so it passes straight through. [] on older sessions.
const codingWarningsOut = (list) => (Array.isArray(list) ? list : []);
const resolveHistoryInfo = async (bookingID) => {
  if (!bookingID) return EMPTY_HISTORY_INFO;
  try {
    const snap = await db.collection("bookingSessions").where("bookingID", "==", bookingID).limit(1).get();
    if (snap.empty) return EMPTY_HISTORY_INFO;
    const data = snap.docs[0].data();
    return {
      hasHistory:       !!data.archiveUrl,
      bookingSessionID: data.bookingSessionID || null,
      lastArchivedAt:   data.lastArchivedAt || null,
      // Surfaced here (rather than a separate fetch) since this query
      // already reads the session doc for hasHistory/bookingSessionID —
      // Car Tracking's "Current trip" panel and Bookings.jsx need both to
      // show the Dropped Off marker without an extra round trip per booking.
      startedAt:        sessionStartedAt(data),
      droppedOffTime:   data.droppedOffTime || null,
      pickupLocation:   data.pickupLocation || null,
      dropoffLocation:  data.dropoffLocation || null,
      geofenceZones:    data.geofenceZones || [],
      codingWarnings:   codingWarningsOut(data.codingWarnings),
    };
  } catch { return EMPTY_HISTORY_INFO; }
};

// ─────────────────────────────────────────────
// Archive to notificationsArchive when booking status resolves
// (Frontend reads live from bookings collection directly)
// ─────────────────────────────────────────────
const archiveNotification = async ({ userID, bookingID, docID, oldStatus, newStatus, bookingData }) => {
  try {
    await db.collection("notificationsArchive").add({
      bookingDocID:   docID,
      bookingID:      bookingID || docID,
      userID:         userID || "",
      previousStatus: oldStatus || "",
      resolvedStatus: newStatus || "",
      startDateTime:  bookingData.startDateTime  || null,
      endDateTime:    bookingData.endDateTime    || null,
      carID:          bookingData.carID          || "",
      location:       bookingData.location       || "",
      notesAdmin:     bookingData.notesAdmin     || "",
      archivedAt:     admin.firestore.FieldValue.serverTimestamp(),
    });
    console.log("[ARCHIVE] Notification archived for booking:", bookingID);
  } catch (err) {
    console.error("[ARCHIVE] Failed:", err.message);
  }
};



// ─────────────────────────────────────────────
// Main service functions
// ─────────────────────────────────────────────

// The T&C number (1.00, 1.01 …) a booking agreed to. The booking only stores the immutable
// termsVersions doc ID, so the number is read from that doc. null if it can't be found.
const resolveTermsVersionNumber = async (id) => {
  try {
    const doc = await db.collection("termsVersions").doc(String(id)).get();
    return doc.exists ? (doc.data().version ?? null) : null;
  } catch {
    return null;
  }
};

export const getAllBookings = async (statusFilter) => {
  const filter = statusFilter?.toLowerCase();

  let rows = [];
  const seen = new Set();
  const addSnap = (snap) => snap.forEach((doc) => {
    if (seen.has(doc.id)) return;
    seen.add(doc.id);
    rows.push({ id: doc.id, ...doc.data() });
  });

  if (!filter || filter === "all") {
    // "to pay" = created but the deposit hasn't cleared yet. Shown (read-only, badge
    // in the UI) so staff can see what's pending and that the car is spoken for.
    const statuses = ["to pay", "upcoming", "ongoing", "completed", "cancelled", "stolen"];
    const snaps = await Promise.all(
      statuses.map((st) => db.collection("bookings").where("status", "==", st).get())
    );
    snaps.forEach(addSnap);
  } else if (filter === "cancellation_request") {
    // Pending requests live in the cancellationRequests collection.
    const pending = await getAllPendingRequests();
    (await getBookingsByKeys([...new Set(pending.map((r) => r.bookingID))])).forEach((b) => {
      if (seen.has(b.id)) return;
      seen.add(b.id);
      rows.push(b);
    });
  } else {
    addSnap(await db.collection("bookings").where("status", "==", filter).get());
  }

  // Every booking carries its cancellation request history (newest first) and
  // the latest one as `cancellationRequest`, so the detail view can show WHY the
  // customer asked. A booking with a PENDING request is still PRESENTED as
  // "cancellation_request" (the value the Bookings page already knows how to
  // show and act on) while its real status is kept as actualStatus.
  // Only the rows of THESE bookings are read (not the whole collection).
  const requestMap = await getRequestsByBookingKeys(rows.map((b) => bookingKeyOf(b.id, b)));
  rows = rows.map((b) => {
    const all     = requestMap.get(bookingKeyOf(b.id, b)) || [];
    const reqs    = all.filter((r) => !r.cancelledBy && !r.refundRequestID);          // real customer requests only
    const latest  = reqs[0] || null;
    const pending = reqs.some((r) => r.status === REQUEST_STATUS.PENDING);
    // Why the booking was cancelled: the direct-cancellation row, else the approved request's reason.
    const reasonRow = all.find((r) => r.cancelledBy) || all.find((r) => r.status === REQUEST_STATUS.APPROVED && r.reason);
    const out = { ...b, cancellationRequest: latest, cancellationRequests: reqs, cancellationReason: reasonRow?.reason || "" };
    return pending && (b.status || "").toLowerCase() !== "cancelled"
      ? { ...out, actualStatus: b.status, status: "cancellation_request" }
      : out;
  });
  // Show WHO handled a request, not just a uid.
  const staffIDs = [...new Set(rows.map((b) => b.cancellationRequest?.processedBy).filter(Boolean))];
  if (staffIDs.length) {
    const staffMap = Object.fromEntries(await Promise.all(staffIDs.map((id) => resolveUserInfo(id).then((u) => [id, u]))));
    rows.forEach((b) => {
      const pb = b.cancellationRequest?.processedBy;
      if (pb) b.cancellationRequest = { ...b.cancellationRequest, processedByName: staffMap[pb]?.customerName || null };
    });
  }
  if (filter && filter !== "all") rows = rows.filter((b) => (b.status || "").toLowerCase() === filter);

  rows.sort((a, b) => {
    const ta = a.updatedAt?.toMillis?.() ?? 0;
    const tb = b.updatedAt?.toMillis?.() ?? 0;
    return tb - ta;
  });

  // Current driver comes from driverAssignments now (see attachCurrentDrivers).
  await attachCurrentDrivers(rows);

  // Bookings that have a refund request in flight → shown as "For Refund".
  const openRefundSnap = await db.collection("refundRequests").where("status", "in", ["Pending", "Approved"]).get();
  const bookingsWithOpenRefund = new Set(openRefundSnap.docs.map((d) => d.data().bookingID));

  const carIDs         = [...new Set(rows.map((b) => b.carID).filter(Boolean))];
  const bookingIDs     = [...new Set(rows.map((b) => b.bookingID || b.id).filter(Boolean))];
  const userIDs        = [...new Set(rows.map((b) => b.userID).filter(Boolean))];
  const serviceTypeIDs = [...new Set(rows.map((b) => b.serviceTypeID).filter(Boolean))];
  // The current driver is the booking's "assigned" row in driverAssignments
  // (attachCurrentDrivers above puts it on each row as a read-only view). It is
  // resolved the same way as the customer (userDetails + user collections) so
  // Bookings.jsx can show who's actually driving, or that no one's assigned yet,
  // without a separate Driver Dispatch lookup.
  const driverIDs      = [...new Set(rows.map((b) => b.driverID).filter(Boolean))];

  const [vehicleEntries, paymentEntries, userEntries, driverEntries, serviceTypeEntries, historyEntries, beforeDocsEntries, afterDocsEntries] = await Promise.all([
    Promise.all(carIDs.map((id) => resolveVehicleName(id).then((v) => [id, v]))),
    Promise.all(bookingIDs.map((id) => resolvePaymentInfo(id).then((p) => [id, p]))),
    Promise.all(userIDs.map((id) => resolveUserInfo(id).then((u) => [id, u]))),
    Promise.all(driverIDs.map((id) => resolveUserInfo(id).then((u) => [id, u]))),
    Promise.all(serviceTypeIDs.map((id) => resolveServiceType(id).then((s) => [id, s]))),
    Promise.all(bookingIDs.map((id) => resolveHistoryInfo(id).then((h) => [id, h]))),
    Promise.all(bookingIDs.map((id) => getPhaseChecklist(id, "before").then((v) => [id, v]))),
    Promise.all(bookingIDs.map((id) => getPhaseChecklist(id, "after").then((v) => [id, v]))),
  ]);

  const vehicleMap     = Object.fromEntries(vehicleEntries);
  const paymentMap     = Object.fromEntries(paymentEntries);
  const userMap        = Object.fromEntries(userEntries);
  const driverMap      = Object.fromEntries(driverEntries);
  const serviceTypeMap = Object.fromEntries(serviceTypeEntries);
  const historyMap     = Object.fromEntries(historyEntries);
  const beforeDocsMap  = Object.fromEntries(beforeDocsEntries);
  const afterDocsMap   = Object.fromEntries(afterDocsEntries);
  // Which T&C version each booking agreed to — one read per DISTINCT termsVersionID.
  const termsIDs = [...new Set(rows.map((b) => b.termsVersionID).filter(Boolean))];
  const termsMap = Object.fromEntries(
    await Promise.all(termsIDs.map((id) => resolveTermsVersionNumber(id).then((v) => [id, v])))
  );

  return rows.map((b) => {
    const bID     = b.bookingID || b.id;
    const payInfo = paymentMap[bID] || EMPTY_PAYMENT_INFO;
    const histInfo = historyMap[bID] || { hasHistory: false, bookingSessionID: null, lastArchivedAt: null, startedAt: null, droppedOffTime: null };
    // A cancelled booking always shows "Cancelled" payment status, matching
    // getAllPayments()'s override — the underlying payment doc's own status
    // (e.g. still "Pending") isn't what matters once the trip itself is off.
    // …EXCEPT a payment that was actually refunded: that stays "Refunded" (it used
    // to be hidden behind "Cancelled", losing the fact that the money went back).
    const isCancelled = (b.status || "").toLowerCase() === "cancelled";
    const paymentStatus = isCancelled && payInfo.paymentStatus !== "Refunded" ? "Cancelled" : payInfo.paymentStatus;
    let paymentStage = payInfo.paymentStage;
    if (paymentStage !== "Refunded") {
      if (bookingsWithOpenRefund.has(bID)) paymentStage = "For Refund";
      else if (isCancelled) paymentStage = "Cancelled";
    }
    return {
      ...b,
      vehicleName:      vehicleMap[b.carID] || "—",
      paymentMethod:    payInfo.paymentMethod,
      totalFee:         payInfo.totalFee,        // from payments.amount
      rentalFee:        payInfo.rentalFee,
      serviceFee:       payInfo.serviceFee,
      extraFee:         payInfo.extraFee,
      driversFee:       payInfo.driversFee,
      gatewayFee:       payInfo.gatewayFee,
      deposit:          payInfo.deposit,
      securityDeposit:  payInfo.securityDeposit,
      amountPaid:       payInfo.amountPaid,
      balance:          payInfo.balance,
      payType:          payInfo.payType,
      discountAmount:   payInfo.discountAmount,
      paymentStatus,
      paymentStage,
      refundDue:        payInfo.refundDue,
      refundIssued:     payInfo.refundIssued,
      depositAmount:         payInfo.depositAmount,
      depositStatus:         payInfo.depositStatus,
      confirmedPenaltyTotal: payInfo.confirmedPenaltyTotal,
      amountToReturn:        payInfo.amountToReturn,
      depositSettled:        payInfo.depositSettled,
      depositDeducted:       payInfo.depositDeducted,
      customerName:     userMap[b.userID]?.customerName || "—",
      phone:            userMap[b.userID]?.phone || "—",
      // No driverID at all (e.g. self-drive, or a chauffeur booking not yet
      // assigned) → driverName stays null so the UI can say "No driver
      // assigned" instead of a misleading "—".
      driverID:         b.driverID || null,
      driverName:       b.driverID ? (driverMap[b.driverID]?.customerName || "—") : null,
      driverPhone:      b.driverID ? (driverMap[b.driverID]?.phone || "—") : null,
      serviceTypeName:  serviceTypeMap[b.serviceTypeID] || "—",
      // T&C the customer agreed to. termsVersionID + termsAcceptedAt are already on `b`.
      // termsViewID is what /terms?version=<id> opens: the termsVersions doc ID, or (for bookings
      // from before the switch) the old termsHash. termsVersionNumber is the readable 1.00 / 1.01.
      termsViewID:        b.termsVersionID || b.termsHash || null,
      termsVersionNumber: b.termsVersionID ? (termsMap[b.termsVersionID] ?? null) : (b.termsVersion ?? null),
      termsLegacy:        !b.termsVersionID && !!b.termsHash,
      hasHistory:       histInfo.hasHistory,
      bookingSessionID: histInfo.bookingSessionID,
      lastArchivedAt:   histInfo.lastArchivedAt,
      startedAt:            histInfo.startedAt,
      droppedOffTime:       histInfo.droppedOffTime,
      // Every stop for this booking's trip — pickup, dropoff, and any
      // extra stops selected at booking time — so the detail view can
      // plot them on a map instead of just printing the address string.
      pickupLocation:   histInfo.pickupLocation,
      dropoffLocation:  histInfo.dropoffLocation,
      geofenceZones:    histInfo.geofenceZones,
      codingWarnings:   histInfo.codingWarnings || [],
      // "Complete" now means photos AND the parts-condition record — see
      // getPhaseChecklist in vehicleDocumentation.service.js. The
      // per-half breakdown is included for UIs that want to say which half
      // is still missing.
      beforeDocsComplete: beforeDocsMap[bID]?.complete ?? false,
      afterDocsComplete:  afterDocsMap[bID]?.complete ?? false,
      beforeInspection:   beforeDocsMap[bID] ?? { photos: false, parts: false, complete: false },
      afterInspection:    afterDocsMap[bID] ?? { photos: false, parts: false, complete: false },
    };
  });
};

// ─────────────────────────────────────────────
// Deposit/penalty position for a booking, read-only. Shared by the Return
// gate, settleDeposit and the Return checklist so both always agree.
//   unpaidTotal            confirmed penalties not yet paid
//   depositAvailable       the held deposit, only while it is unsettled
//   outstandingAfterDeposit what the customer would still owe after the
//                          deposit is applied (0 = fully covered)
//   amountToReturn         signed: deposit minus penalties (negative = owed)
// ─────────────────────────────────────────────
const getDepositPosition = async (bID) => {
  const [paymentSnap, penalties] = await Promise.all([
    db.collection("payments").where("bookingID", "==", bID).limit(1).get(),
    listPenaltiesForBooking(bID),
  ]);
  const paymentData = paymentSnap.empty
    ? null
    : await hydratePaymentData(paymentSnap.docs[0].data(), paymentSnap.docs[0].id);
  const confirmed = penalties.filter((p) => p.status === "Confirmed");
  const unpaidTotal = confirmed.reduce((sum, p) => sum + Math.max(0, (p.amount || 0) - (p.paidAmount || 0)), 0);
  const confirmedTotal = confirmed.reduce((sum, p) => sum + (p.amount || 0), 0);   // all Confirmed penalties, paid or not
  const deposit = getDepositView(paymentData, { unpaid: unpaidTotal });
  const alreadySettled = !!deposit?.settlement;
  const depositAvailable = deposit?.status === "Held" && !alreadySettled ? (deposit.amount || 0) : 0;
  return {
    penalties, deposit, unpaidTotal, confirmedTotal, alreadySettled,
    depositStatus: deposit?.status || "—",
    depositAvailable,
    outstandingAfterDeposit: Math.max(0, unpaidTotal - depositAvailable),
    amountToReturn: depositAvailable - unpaidTotal,
  };
};

/**
 * Settle the security deposit at drop-off: deducts every confirmed unpaid
 * penalty from the held deposit (oldest first) and records the handback of
 * whatever is left, in one transaction (see settleBooking). Callable by the
 * driver (own trip) or a supervisor once the vehicle is dropped off — the
 * point is that whoever is physically with the customer can close out the
 * deposit without waiting for the after-trip inspection. A penalty raised
 * after this stays a normal unpaid penalty.
 */
export const settleDeposit = async (docID, { method, referenceNumber = "" } = {}, performedBy = null) => {
  const bookingDoc = await db.collection("bookings").doc(docID).get();
  if (!bookingDoc.exists) throw new Error("Booking not found.");
  const booking = bookingDoc.data();
  const bID = booking.bookingID || docID;

  if (booking.status?.toLowerCase() !== "ongoing") {
    throw new Error(`Cannot settle the deposit: booking status is "${booking.status}", not "ongoing".`);
  }
  const session = await getSessionByBookingID(bID);
  if (!session?.data?.droppedOffTime) {
    throw new Error("Mark the vehicle dropped off before settling the deposit.");
  }

  const pos = await getDepositPosition(bID);
  if (!pos.deposit || pos.deposit.status !== "Held") {
    throw new Error(`There is no held security deposit to settle (deposit status: ${pos.depositStatus}).`);
  }
  if (pos.alreadySettled) throw new Error("This booking's deposit has already been settled.");
  if (pos.amountToReturn > 0 && !method) {
    throw new Error("Choose how the deposit is being returned to the customer.");
  }

  const res = await settleBooking({
    bookingID: bID, actorUid: performedBy,
    returnMethod: method || null, returnReferenceNumber: referenceNumber,
  });
  if (res?.error) throw new Error(res.error);

  createAuditLog({
    action: "update", userID: performedBy, bookingID: bID,
    description: res.net > 0
      ? `Settled deposit on booking ${bID}: penalties ₱${res.confirmedPenaltyTotal}, ₱${res.net} returned via ${method}.`
      : `Settled deposit on booking ${bID}: penalties ₱${res.confirmedPenaltyTotal}, ${res.outstandingAfterDeposit > 0 ? `₱${res.outstandingAfterDeposit} still owed by the customer` : "nothing to return"}.`,
  }).catch((err) => console.error("[AuditLog] Deposit settle log failed:", err.message));

  return res;
};

export const updateBooking = async (docID, updates, performedBy = null) => {
  const doc = await db.collection("bookings").doc(docID).get();
  if (!doc.exists) throw new Error("Booking not found");

  const bookingData = doc.data();
  const { status: oldStatus, userID, carID, bookingID } = bookingData;

  const nonEditable = ["completed", "cancelled", "stolen"]; // once flagged stolen, no further edits through this endpoint
  if (nonEditable.includes(oldStatus?.toLowerCase())) {
    throw new Error(`Cannot edit a booking with status: ${oldStatus}`);
  }

  // "location" (free text) is deliberately not editable: the name always comes from a map pick (stopEdits below),
  // so the text and the geofence pin can never drift apart.
  const allowed = ["startDateTime", "endDateTime", "notesAdmin", "notesUser", "status"];
  const filtered = {};
  allowed.forEach((k) => {
    if (updates[k] !== undefined && !(k === "status" && !updates[k])) { // "" status = "no change"
      filtered[k] = k === "status" ? updates[k].toLowerCase() : updates[k];
    }
  });

  // ── Stolen only makes sense for a trip that is out on the road: the booking must be
  // ongoing and the car not yet marked dropped off (a dropped-off car is back). The Car
  // Tracking button already hides this; this stops a direct API call from skipping it. ──
  if (filtered.status === "stolen" && oldStatus?.toLowerCase() !== "stolen") {
    if (oldStatus?.toLowerCase() !== "ongoing") {
      throw new Error(`Cannot flag as stolen: booking status is "${oldStatus}", not "ongoing".`);
    }
    const stolenSession = await getSessionByBookingID(bookingID || docID);
    if (stolenSession?.data?.droppedOffTime) {
      throw new Error("Cannot flag as stolen: the car was already marked dropped off.");
    }
  }

  // ── Map-picked stops: a booking can have several locations (destination + extra
  // stops), so the admin sends stopEdits = [{ zoneIndex, oldLabel, address, lat, lng }],
  // one per stop they moved. The zones on the session move; if one of them is the
  // booking's destination, bookings.location follows its new address. ──
  let stopEdits = [];
  if (updates.stopEdits !== undefined) {
    if (!Array.isArray(updates.stopEdits)) throw new Error("stopEdits must be an array.");
    stopEdits = updates.stopEdits.map((e) => {
      const lat = Number(e?.lat), lng = Number(e?.lng);
      if (!Number.isFinite(lat) || !Number.isFinite(lng) || Math.abs(lat) > 90 || Math.abs(lng) > 180) {
        throw new Error("Invalid map coordinates for location.");
      }
      const address = String(e?.address || "").trim();
      if (!address) throw new Error("A location address is required.");
      const zoneIndex = Number.isInteger(e?.zoneIndex) && e.zoneIndex >= 0 ? e.zoneIndex : null;
      return { zoneIndex, oldLabel: String(e?.oldLabel || ""), address, lat, lng };
    });
    const seen = new Set();
    for (const e of stopEdits) {
      if (e.zoneIndex === null) continue;
      if (seen.has(e.zoneIndex)) throw new Error("The same stop was edited twice.");
      seen.add(e.zoneIndex);
    }
    const normLabel = (x) => (x || "").trim().toLowerCase();
    const destEdit = stopEdits.find((e) => normLabel(e.oldLabel) && normLabel(e.oldLabel) === normLabel(bookingData.location));
    if (destEdit) filtered.location = destEdit.address;
  }

  // ── Payment validation: cannot mark picked-up/ongoing if payment is not yet approved/paid ──
  if (filtered.status === "ongoing" && oldStatus?.toLowerCase() !== "ongoing") {
    const bID = bookingID || docID;
    const paySnap = await db.collection("payments")
      .where("bookingID", "==", bID)
      .limit(1)
      .get();

    if (paySnap.empty) {
      throw new Error("Cannot approve booking: no payment record found for this booking.");
    }

    const paymentData = await hydratePaymentData(paySnap.docs[0].data(), paySnap.docs[0].id);
    const payStatus   = paymentData.status || "";
    const approvedStatuses = ["approved", "paid"];

    if (!approvedStatuses.includes(payStatus.toLowerCase())) {
      throw new Error(
        `Cannot approve booking: payment is still "${payStatus}". ` +
        `Please approve the payment first in the Payments page.`
      );
    }

    // Balance must also be fully settled — this is a stricter rule than
    // before. Previously an approved deposit with balance > 0 was enough
    // to reach "ongoing"; now Pickup is blocked until the full balance is
    // collected (discounts included — applying a discount lowers this
    // balance the same way a payment does).
    const { balance } = computeAmounts(paymentData);
    if (balance > 0) {
      throw new Error(
        `Cannot approve booking: payment still requires action — ₱${balance.toLocaleString()} remaining. ` +
        `Collect or apply a discount for the remaining balance first.`
      );
    }
  }

  // ── Vehicle inspection validation: cannot mark picked-up/ongoing until
  // the before-trip inspection is complete — the 3 exterior photos AND the
  // parts-condition record, both entered by staff (drivers can't write
  // either, see vehicleDocumentation.routes.js). This is the real gate the
  // driver's Start Pickup goes through; the My Trips button state is just a
  // convenience mirror of it. ──
  if (filtered.status === "ongoing" && oldStatus?.toLowerCase() !== "ongoing") {
    const bID = bookingID || docID;
    const checklist = await getPhaseChecklist(bID, "before");
    if (!checklist.complete) {
      throw new Error(
        `Cannot mark picked up: the before-trip vehicle inspection is incomplete — still missing ${describeMissingInspection(checklist)}. ` +
        "A supervisor needs to complete it in Vehicle Inspections first."
      );
    }
  }

  // ── Vehicle inspection validation: cannot mark completed until
  // the after-trip inspection is complete (photos AND parts condition).
  // Mirrors the before-trip guard above so Return can't skip the
  // inspection the same way Pickup can't. ──
  if (filtered.status === "completed" && oldStatus?.toLowerCase() === "ongoing") {
    const bID = bookingID || docID;
    const checklist = await getPhaseChecklist(bID, "after");
    if (!checklist.complete) {
      throw new Error(
        `Cannot mark complete: the after-trip vehicle inspection is incomplete — still missing ${describeMissingInspection(checklist)}. ` +
        "A supervisor needs to complete it in Vehicle Inspections first."
      );
    }
  }

  // ── Vehicle drop-off validation: cannot mark completed until
  // someone (the assigned driver, or a supervisor/staff for a no-driver
  // booking) has marked the vehicle itself physically dropped off. This is
  // the checkpoint that unblocks the after-trip inspection in the first
  // place — a supervisor can't meaningfully inspect a car that, per the
  // system, hasn't arrived yet. ──
  if (filtered.status === "completed" && oldStatus?.toLowerCase() === "ongoing") {
    const bID = bookingID || docID;
    const session = await getSessionByBookingID(bID);
    if (!session?.data?.droppedOffTime) {
      throw new Error(
        "Cannot mark complete: the vehicle hasn't been marked dropped off yet. " +
        "Mark it dropped off first, then complete the after-trip inspection."
      );
    }
  }

  // ── GPS gate: cannot mark completed while a GPS device is still
  // assigned to this car. Unassign it first on the GPS Setup page. ──
  if (filtered.status === "completed" && oldStatus?.toLowerCase() === "ongoing") {
    const stillAssigned = await getDevicesStillAssigned(bookingData.carID);
    if (stillAssigned.length > 0) {
      throw new Error(
        `Cannot mark complete: GPS device ${describeAssignedDevices(stillAssigned)} is still assigned to this car. ` +
        "Unassign it on the GPS Setup page first."
      );
    }
  }

  // ── Deposit gate: if a security deposit is being held, it must already
  // have been settled (penalties deducted, remainder handed back) — that
  // happens at drop-off via settleDeposit(), while the customer/driver are
  // still together, NOT here. This gate deliberately does not block on
  // money still owed: a penalty found during inspection after the deposit
  // was returned just stays an unpaid penalty (Mark Paid / customer pays
  // online) instead of leaving the car stuck "ongoing". ──
  if (filtered.status === "completed" && oldStatus?.toLowerCase() === "ongoing") {
    const pos = await getDepositPosition(bookingID || docID);
    if (pos.deposit?.status === "Held" && !pos.alreadySettled) {
      throw new Error(
        "Cannot mark complete: the security deposit hasn't been settled yet. " +
        "Settle it first (deduct any penalties and confirm the deposit handed back)."
      );
    }
  }

  // Stamp the actual return moment, once, at the exact instant Return is
  // clicked (ongoing -> completed). This is deliberately a server
  // timestamp on THIS transition only — never editable afterward (this
  // endpoint already blocks further edits to a "completed" booking via
  // the nonEditable guard above) and never derived from GPS. Note this is
  // NOT the same moment as droppedOffTime above — the vehicle can sit
  // dropped-off for a while going through inspection/penalty/device-check
  // before Return is actually confirmed.
  if (filtered.status === "completed" && oldStatus?.toLowerCase() === "ongoing") {
    filtered.completedAt = admin.firestore.FieldValue.serverTimestamp();
  }

  filtered.updatedAt = admin.firestore.FieldValue.serverTimestamp();

  // Move the destination geofence zone BEFORE saving the booking, so a failure here
  // surfaces to the admin instead of leaving the text and the pin out of sync.
  if (stopEdits.length) {
    await updateSessionStops(bookingID || docID, stopEdits);
  }

  const bookingRef = db.collection("bookings").doc(docID);
  if (filtered.status === "cancelled") {
    // A cancellation is a booking update PLUS a cancellationRequests row (the reason no
    // longer lives on the booking). Both commit together:
    //   * a customer request is still pending  -> it is the row; mark it approved
    //   * otherwise                            -> write the "direct" row
    // ("admin", not "staff": cancelledBy "staff" is what Fleet uses to find the bookings
    // it cancelled itself, so this manual edit must not be mistaken for that.)
    const bookingKey = bookingKeyOf(docID, bookingData);
    const pendingRequest = await getPendingRequest(bookingKey);
    const cancelBatch = db.batch();
    cancelBatch.update(bookingRef, filtered);
    if (pendingRequest) {
      resolveRequest(pendingRequest, { status: REQUEST_STATUS.APPROVED, processedBy: performedBy }, cancelBatch);
    } else {
      const reason = String(updates.cancellationReason ?? updates.reason ?? "").trim();
      recordDirectCancellation(bookingKey, {
        userID: userID || null,
        reason: reason || "Cancelled by admin.",
        cancelledBy: performedBy ? "admin" : "unknown",
        processedBy: performedBy,
      }, cancelBatch);
    }
    await cancelBatch.commit();
    if (pendingRequest) {
      resolveNotification("cancellation_request", docID).catch((err) =>
        console.error("[Booking] Failed to resolve cancellation_request notification:", err.message)
      );
    }
  } else {
    await bookingRef.update(filtered);
  }

  if (stopEdits.length) {
    const changes = stopEdits
      .map((e) => `"${e.oldLabel || "—"}" → "${e.address}"`)
      .join(", ");
    createAuditLog({
      action: "update",
      userID: performedBy,
      bookingID: bookingID || docID,
      description: `Moved ${stopEdits.length === 1 ? "a stop" : `${stopEdits.length} stops`} on booking ${bookingID || docID} (pin moved on map): ${changes}.`,
    }).catch((err) => console.error("[AuditLog] Location edit log failed:", err.message));
  }

  // The booking has moved on, so any "driver is waiting on the inspection"
  // reminder for it is stale: pickup clears the pickup one, and once the
  // trip is completed/cancelled/stolen nothing is left to remind about.
  // Best-effort — never blocks the status change itself.
  if (filtered.status && filtered.status !== oldStatus?.toLowerCase()) {
    const reminderKey = bookingID || docID;
    const stalePhases =
      filtered.status === "ongoing" ? ["before"]
      : ["completed", "cancelled", "stolen"].includes(filtered.status) ? ["before", "after"]
      : [];
    if (stalePhases.length) {
      resolveInspectionReminders(reminderKey, stalePhases).catch((err) =>
        console.error("[Booking] Failed to resolve inspection reminders:", err.message)
      );
    }
  }

  // ── Link booking status transitions to the GPS session lifecycle ──
  // "ongoing" = pickup happened, car is now actually on the trip. This is
  // the one place that status-vocabulary decision actually takes effect —
  // flagging it here rather than silently assuming it, since it was still
  // an open question. Session activation/ending is best-effort: a failure
  // here must never block the booking status update itself, since staff
  // still need to be able to mark a car picked up/returned even if the
  // Firestore session link is temporarily unavailable.
  if (filtered.status === "ongoing" && oldStatus?.toLowerCase() !== "ongoing") {
    const bID = bookingID || docID;
    createAuditLog({
      action: "update",
      userID: performedBy,
      bookingID: bID,
      description: `Marked pickup complete on booking ${bID}.`,
    }).catch((err) => console.error("[AuditLog] Pickup log failed:", err.message));
    try {
      const bID = bookingID || docID;
      const session = await getSessionByBookingID(bID);
      if (session) {
        await markSessionActive(session.data.bookingSessionID, carID);
        // Flush right away too — mostly just so a file actually shows up in
        // Storage the moment tracking starts, as reassurance the pipeline is
        // wired correctly, rather than only ever appearing at Return or
        // whenever tonight's cron happens to run. It'll be near-empty at
        // this exact instant (no GPS pings have landed yet), and gets
        // overwritten with the real trail as the trip progresses and again
        // at Return — this first flush is just an early proof-of-life, not
        // the final archive.
        try {
          await flushBookingHistory(session.data.bookingSessionID);
        } catch (flushErr) {
          console.error("[Booking] Pickup flush failed (session still marked active, cron will retry tonight):", flushErr.message);
        }
      } else {
        console.warn(`[Booking] No bookingSession found for booking ${bID} — GPS tracking won't start for this trip.`);
      }
    } catch (err) {
      console.error("[Booking] Failed to activate GPS session:", err.message);
    }
  } else if (filtered.status === "completed" && oldStatus?.toLowerCase() === "ongoing") {
    const bID = bookingID || docID;
    createAuditLog({
      action: "update",
      userID: performedBy,
      bookingID: bID,
      description: `Marked complete on booking ${bID}.`,
    }).catch((err) => console.error("[AuditLog] Return log failed:", err.message));
    try {
      const bID = bookingID || docID;
      const session = await getSessionByBookingID(bID);
      if (session) {
        await markSessionEnded(session.data.bookingSessionID);
        // Flush the full trail to Storage right now — this is the "Return"
        // action, no reason to make the history file wait for tonight's
        // cron when the trip is already over.
        try {
          await flushBookingHistory(session.data.bookingSessionID);
        } catch (flushErr) {
          console.error("[Booking] Return flush failed (session still marked ended, cron will retry tonight):", flushErr.message);
        }
      }
    } catch (err) {
      console.error("[Booking] Failed to end GPS session:", err.message);
    }
  } else if (filtered.status === "cancelled" && oldStatus?.toLowerCase() !== "cancelled") {
    try {
      const bID = bookingID || docID;
      const session = await getSessionByBookingID(bID);
      if (session) {
        await markSessionCancelled(session.data.bookingSessionID);
      } else {
        console.warn(`[Booking] No bookingSession found for booking ${bID} — nothing to cancel.`);
      }
    } catch (err) {
      console.error("[Booking] Failed to cancel GPS session:", err.message);
    }
  } else if (filtered.status === "stolen" && oldStatus?.toLowerCase() !== "stolen") {
    // Manual only — set by staff hitting "Stolen" on the car card. No
    // auto-trigger off geofence breach.
    try {
      const bID = bookingID || docID;
      const session = await getSessionByBookingID(bID);
      if (session) {
        await markSessionStolen(session.data.bookingSessionID);
        // Same as Return — flush the trail immediately for documentation
        // rather than waiting for the nightly cron. This is manual/admin-
        // triggered, so there's no reason to delay the record.
        try {
          await flushBookingHistory(session.data.bookingSessionID);
        } catch (flushErr) {
          console.error("[Booking] Stolen flush failed (session still marked stolen, cron will retry tonight):", flushErr.message);
        }
      } else {
        console.warn(`[Booking] No bookingSession found for booking ${bID} — cannot flag session stolen.`);
      }
    } catch (err) {
      console.error("[Booking] Failed to flag session stolen:", err.message);
    }
  }

  // -- Trip over -> close the driver's assignment row (best effort) --
  if (["completed", "cancelled", "stolen"].includes(filtered.status)) {
    completeActiveAssignment(bookingID || docID).catch((err) =>
      console.error("[Booking] Failed to close driver assignment:", err.message)
    );
  }

  // ── Archive + auto-delete notification when booking moves out of pending/cancellation_request ──
  const newStatus = filtered.status;
  const activeStatuses = ["upcoming", "cancellation_request"];
  const resolvedStatuses = ["upcoming", "ongoing", "completed", "cancelled", "stolen"];
  if (
    newStatus &&
    newStatus !== oldStatus?.toLowerCase() &&
    activeStatuses.includes(oldStatus?.toLowerCase()) &&
    resolvedStatuses.includes(newStatus)
  ) {
    await archiveNotification({
      userID,
      bookingID: bookingID || docID,
      docID,
      oldStatus: oldStatus?.toLowerCase(),
      newStatus,
      bookingData,
    });

    // Delete corresponding notifications from the notifications collection
    try {
      const bID = bookingID || docID;
      const notifSnap = await db.collection("notifications")
        .where("bookingID", "==", bID)
        .where("type", "==", "new_booking")
        .get();
      if (!notifSnap.empty) {
        const batch = db.batch();
        notifSnap.docs.forEach(d => batch.delete(d.ref));
        await batch.commit();
        console.log(`[NOTIF] Auto-deleted ${notifSnap.size} new_booking notif(s) for booking: ${bID}`);
      }
    } catch (err) {
      console.error("[NOTIF] Failed to delete booking notifications:", err.message);
    }
  }

  return { success: true };
};

// ─────────────────────────────────────────────
// Mark the vehicle itself physically dropped off — every booking type,
// not just chauffeur. Distinct from Return: the session stays "active",
// only the timestamp changes, and Return itself stays blocked until
// inspection/penalties/device-check are also cleared (see updateBooking's
// "completed" gates above). See bookingsession.model.js for why this is
// never auto-filled/backfilled.
// ─────────────────────────────────────────────
export const markBookingDroppedOff = async (docID, performedBy = null) => {
  const bookingRef = db.collection("bookings").doc(docID);
  const bookingDoc = await bookingRef.get();
  if (!bookingDoc.exists) throw new Error("Booking not found.");
  const booking = bookingDoc.data();

  if (booking.status?.toLowerCase() !== "ongoing") {
    throw new Error(`Cannot mark dropped off: booking status is "${booking.status}", not "ongoing" (has it been picked up yet?).`);
  }

  const bID = booking.bookingID || docID;
  const session = await getSessionByBookingID(bID);
  if (!session) throw new Error("No active trip session found for this booking.");
  if (session.data.droppedOffTime) {
    throw new Error("Already marked dropped off — this can't be re-triggered or edited.");
  }

  await markDroppedOff(session.ref.id);
  createAuditLog({
    action: "update",
    userID: performedBy,
    bookingID: bID,
    description: `Marked vehicle dropped off on booking ${bID}.`,
  }).catch((err) => console.error("[AuditLog] Dropoff log failed:", err.message));
  return { id: docID };
};

// ─────────────────────────────────────────────
// GPS-unassigned requirement at Return. Before a booking can be marked
// returned, the tracker must have been detached from the car (GPS Setup
// page → Unassign). Returns the gpsDevice docs still assigned to this
// car — an empty array means the car is clear to return. The `assigned`
// filter is done in JS so this needs no composite Firestore index.
// ─────────────────────────────────────────────
const getDevicesStillAssigned = async (carID) => {
  if (!carID) return [];
  const snap = await db.collection("gpsDevice").where("carID", "==", carID).get();
  return snap.docs.map((d) => d.data()).filter((d) => d.assigned === true);
};

const describeAssignedDevices = (devices) =>
  devices.map((d) => d.gpsName || d.gpsDeviceID).join(", ");

// ─────────────────────────────────────────────
// Read-only pre-return checklist — never blocks anything, just reports
// where a booking stands against every Return requirement, so the
// frontend can show a "here's what's still missing" panel instead of a
// disabled/greyed-out button. The actual enforcement lives in
// updateBooking's "completed" gates above; this is purely a mirror of
// those same checks for display purposes.
// ─────────────────────────────────────────────
export const getReturnChecklist = async (docID) => {
  const bookingRef = db.collection("bookings").doc(docID);
  const bookingDoc = await bookingRef.get();
  if (!bookingDoc.exists) throw new Error("Booking not found.");
  const booking = bookingDoc.data();
  const bID = booking.bookingID || docID;

  const [session, afterChecklist, pos, assignedDevices] = await Promise.all([
    getSessionByBookingID(bID),
    getPhaseChecklist(bID, "after"),
    getDepositPosition(bID),
    getDevicesStillAssigned(booking.carID),
  ]);

  const droppedOff = !!session?.data?.droppedOffTime;
  const holdsDeposit = pos.deposit?.status === "Held" && !pos.alreadySettled;
  const settlement = pos.deposit?.settlement || null;

  const items = [
    {
      key: "droppedOff",
      label: "Vehicle dropped off",
      complete: droppedOff,
      detail: droppedOff ? null : "Nobody has marked the vehicle physically dropped off yet.",
    },
    {
      key: "depositSettled",
      label: "Security deposit settled",
      // Nothing to settle when no deposit is held (none recorded / waived).
      complete: !holdsDeposit,
      detail: holdsDeposit
        ? (droppedOff ? "Deduct any penalties and confirm the deposit handed back." : "Mark the vehicle dropped off first, then settle the deposit.")
        : null,
    },
    {
      key: "inspection",
      label: "After-trip vehicle inspection",
      complete: !!afterChecklist.complete,
      detail: afterChecklist.complete ? null : `Still missing ${describeMissingInspection(afterChecklist)}.`,
    },
    {
      key: "gpsUnassigned",
      label: "GPS device unassigned",
      complete: assignedDevices.length === 0,
      detail: assignedDevices.length === 0
        ? null
        : `${describeAssignedDevices(assignedDevices)} is still assigned to this car. Unassign it on the GPS Setup page first.`,
    },
  ];

  return {
    bookingID: bID,
    canReturn: items.every((i) => i.complete),
    canSettle: droppedOff && holdsDeposit,
    items,
    driverID: await resolveCurrentDriverID(booking, docID),
    depositStatus: pos.depositStatus,
    depositHeld: pos.deposit?.amount ?? null,
    depositSettled: !!settlement,
    // Before settlement: deposit minus penalties (negative = customer owes).
    // After settlement: what was actually returned (depositReturned) / is still owed (the unpaid penalties, live).
    penaltyTotal: settlement ? pos.confirmedTotal : pos.unpaidTotal,
    amountToReturn: settlement ? (pos.unpaidTotal > 0 ? -pos.unpaidTotal : pos.deposit.returnedAmount) : pos.amountToReturn,
    // Still-unpaid penalty money right now (includes penalties raised after settling).
    stillOwed: pos.unpaidTotal > pos.depositAvailable ? pos.unpaidTotal - pos.depositAvailable : 0,
    outstandingAfterDeposit: Math.max(0, pos.unpaidTotal - pos.depositAvailable),
    penalties: pos.penalties,
  };
};

// ─────────────────────────────────────────────
// Approve / reject a pending cancellation_request — the customer-side
// counterpart of this lives in customer-backend's requestCancellation()
// (bookings.controller.js), which is the only thing that ever sets a
// booking to "cancellation_request" in the first place. bookingWatcher.js
// used to auto-resolve the notification when status left that state;
// now that the watcher is gone, these two actions resolve it directly,
// same pattern as every other direct-write notification in this codebase.
// ─────────────────────────────────────────────

// A pending request is a row in cancellationRequests.
const findPendingCancellation = async (docID, booking) => {
  const request = await getPendingRequest(bookingKeyOf(docID, booking));
  return { request, pending: !!request };
};

export const approveCancellationRequest = async (docID, performedBy = null) => {
  const bookingRef = db.collection("bookings").doc(docID);
  const bookingDoc = await bookingRef.get();
  if (!bookingDoc.exists) throw new Error("Booking not found.");
  const booking = bookingDoc.data();

  const { request, pending } = await findPendingCancellation(docID, booking);
  if (!pending) {
    throw new Error(`Cannot approve: booking ${docID} has no pending cancellation request (status is "${booking.status}").`);
  }

  const now = new Date();
  // One transaction: the request is marked approved and the booking cancelled together,
  // and both are re-read inside it, so two staff approving at once (or approving a request
  // someone just rejected, or a trip that already ended) cannot both go through.
  // The customer's own words stay on the request row; the booking list reads the
  // cancellation reason from there.
  await db.runTransaction(async (t) => {
    const [reqSnap, bookingSnap] = await Promise.all([t.get(request.ref), t.get(bookingRef)]);
    if (!reqSnap.exists || reqSnap.data().status !== REQUEST_STATUS.PENDING) {
      throw new Error(`Cannot approve: the cancellation request for booking ${docID} was already handled.`);
    }
    const current = String(bookingSnap.data()?.status || "").toLowerCase();
    if (["cancelled", "completed", "stolen"].includes(current)) {
      throw new Error(`Cannot approve: booking ${docID} is already ${current}.`);
    }
    resolveRequest(request, { status: REQUEST_STATUS.APPROVED, processedBy: performedBy }, t);
    t.update(bookingRef, { status: "cancelled", updatedAt: now });
  });

  // Mirror onto the session doc, same as the customer's own instant-cancel
  // path already does for "upcoming" bookings -- this one is "ongoing", so
  // there's a real active session to close out here.
  try {
    const bID = booking.bookingID || docID;
    const session = await getSessionByBookingID(bID);
    if (session) {
      await markSessionCancelled(session.ref.id);
    }
  } catch (err) {
    console.error("[BOOKINGS] approveCancellationRequest: failed to sync bookingSession:", err.message);
  }

  completeActiveAssignment(booking.bookingID || docID).catch((err) =>
    console.error("[BOOKINGS] approveCancellationRequest: failed to close driver assignment:", err.message)
  );

  // Resolves every Owner/Admin/Supervisor's own copy of this notification
  // at once -- see notification.service.js's resolveNotification() header
  // comment for why no userID filter is needed here.
  await resolveNotification("cancellation_request", docID).catch((err) =>
    console.error("[BOOKINGS] approveCancellationRequest: failed to resolve notification:", err.message)
  );

  auditSafe({
    action: "update",
    description: `Cancellation request for booking ${booking.bookingID || docID} APPROVED -- booking cancelled.`,
    userID: performedBy,
    bookingID: booking.bookingID || docID,
  });

  return { id: docID, status: "cancelled" };
};

export const rejectCancellationRequest = async (docID, rejectReason, performedBy = null) => {
  const bookingRef = db.collection("bookings").doc(docID);
  const bookingDoc = await bookingRef.get();
  if (!bookingDoc.exists) throw new Error("Booking not found.");
  const booking = bookingDoc.data();

  const { request, pending } = await findPendingCancellation(docID, booking);
  if (!pending) {
    throw new Error(`Cannot reject: booking ${docID} has no pending cancellation request (status is "${booking.status}").`);
  }

  // The booking's status never changed while the request was pending, so there is
  // nothing to restore; only the request row is resolved.
  const revertTo = booking.status;

  const now = new Date();
  await db.runTransaction(async (t) => {
    const reqSnap = await t.get(request.ref);
    if (!reqSnap.exists || reqSnap.data().status !== REQUEST_STATUS.PENDING) {
      throw new Error(`Cannot reject: the cancellation request for booking ${docID} was already handled.`);
    }
    resolveRequest(request, { status: REQUEST_STATUS.REJECTED, processedBy: performedBy, rejectReason }, t);
    t.update(bookingRef, { updatedAt: now });
  });

  await resolveNotification("cancellation_request", docID).catch((err) =>
    console.error("[BOOKINGS] rejectCancellationRequest: failed to resolve notification:", err.message)
  );

  auditSafe({
    action: "update",
    description: `Cancellation request for booking ${booking.bookingID || docID} REJECTED${rejectReason ? `: ${rejectReason}` : ""}.`,
    userID: performedBy,
    bookingID: booking.bookingID || docID,
  });

  return { id: docID, status: revertTo };
};

// ─────────────────────────────────────────────
// History flush
//
// Compiles a session's full GPS trail into one permanent JSON file in
// Firebase Storage under bookingHistory/. The trail is read from Google
// Sheets (one tab per PHT date, shared by every car — see
// services/sheets/sheets.service.js) across every PHT date the session
// spans; it no longer comes from a Firestore archive/{date} sub-collection.
// (Lived in services/storage/bookingHistory.service.js, then bookingSession.service.js;
// now here so booking.service.js owns the whole booking → history flow.)
// ─────────────────────────────────────────────

export const flushBookingHistory = async (bookingSessionID) => {
  const session = await getSessionById(bookingSessionID);
  if (!session) {
    throw new Error(`Booking session not found: ${bookingSessionID}`);
  }
  const { data } = session;

  // Start of the range = the REAL start of the trip (startedAt, stamped at
  // pickup), not the booking's scheduled date — so an early pickup (a booking
  // for Oct 23 handed over on Sep 28) reads the right Sheets date-tabs instead
  // of coming back empty. For sessions from before startedAt existed we also
  // look at droppedOffTime / lastArchivedAt / last ping and take the earliest
  // known real moment. If nothing is known at all (never started), start = now,
  // i.e. just today's tab.
  const realMoments = [sessionStartedAt(data), toDate(data.droppedOffTime), toDate(data.lastArchivedAt), toDate(data.currentPosition?.date)]
    .filter((d) => d && !isNaN(d.getTime()));
  const pickup = realMoments.length
    ? new Date(Math.min(...realMoments.map((d) => d.getTime())))
    : new Date();
  // Flushing always happens at or after the real event, and no ping can be
  // dated in the future — so "now" is the true upper bound (no wasted reads of
  // Sheets tabs that don't exist yet).
  const end = new Date();
  const dateStrings = datesBetweenPHT(pickup, end);

  const rows = await fetchSessionRows(data.carID, bookingSessionID, dateStrings);
  const fullTrail = rows
    .filter((r) => typeof r.lat === "number" && typeof r.lng === "number" && r.at)
    .map((r) => ({ lat: r.lat, lng: r.lng, at: r.at, speed: r.speed ?? 0, offline: r.offline === true }))
    .sort((a, b) => new Date(a.at) - new Date(b.at));

  const filePath = `bookingHistory/${bookingSessionID}.json`;
  const file = bucket.file(filePath);

  // Shape changed from a bare points array to an object carrying this trip's
  // geofence zones + alert timeline (and coding-restriction alerts) alongside
  // the trail, so History → Review can reconstruct breach state on playback
  // instead of only showing the dots. Older archive files already in Storage
  // stay as bare arrays — the frontend handles both shapes.
  //
  // droppedOffAt / completedAt / holidays are extra review details so a saved
  // trip can be read later without the live records: when the car was marked
  // dropped off, when the booking was marked completed (null until then — this
  // file is also written at pickup and by the nightly cron), and the holidays
  // that fell inside the trip's dates. Gathering them must never block the
  // save itself, so each lookup falls back to null / [].
  const iso = (v) => { const d = toDate(v); return d && !isNaN(d.getTime()) ? d.toISOString() : null; };
  let completedAt = null;
  try {
    const bID = data.bookingID;
    if (bID) {
      let bSnap = await db.collection("bookings").doc(bID).get();
      if (!bSnap.exists) {
        const q = await db.collection("bookings").where("bookingID", "==", bID).limit(1).get();
        bSnap = q.empty ? null : q.docs[0];
      }
      completedAt = iso(bSnap?.data()?.completedAt);
    }
  } catch (err) {
    console.error("[Booking] flush: couldn't read completedAt:", err.message);
  }
  let holidays = [];
  try {
    holidays = await getHolidaysBetween(pickup, end);
  } catch (err) {
    console.error("[Booking] flush: couldn't read holidays:", err.message);
  }

  const archivePayload = {
    points: fullTrail,
    geofenceZones:  data.geofenceZones  || [],
    geofenceAlerts: data.geofenceAlerts || [],
    codingAlerts:   data.codingAlerts   || [],
    codingWarnings: codingWarningsOut(data.codingWarnings),
    droppedOffAt:   iso(data.droppedOffTime),
    completedAt,
    holidays,
  };

  await file.save(JSON.stringify(archivePayload, null, 2), {
    contentType: "application/json",
    metadata: { cacheControl: "no-cache" },
  });
  await file.makePublic();

  const archiveUrl = `https://storage.googleapis.com/${bucket.name}/${filePath}`;
  await recordArchiveFlush(bookingSessionID, archiveUrl);

  return archiveUrl;
};