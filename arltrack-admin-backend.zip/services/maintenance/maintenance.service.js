import { db } from "../../config/firebaseConnection/firebase.js";
import admin from "firebase-admin";
import { BASIS_OPTIONS, STATUS_OPTIONS, SERVICE_CATALOG } from "../../models/maintenance/maintenance.model.js";
import { adminUpdateHistoryPartStatus } from "../inventory/inventory.service.js";
import { createAuditLog } from "../auditLogs/auditLogs.service.js";
import { createTransactionLog, rejectTransactionLogsByRef } from "../transactionLogs/transactionLogs.service.js";
import { notifyOwners } from "../notification/notification.service.js";
import { ROLES } from "../../utils/roles/role.util.js";

// ─────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────

const timestamp = () => admin.firestore.FieldValue.serverTimestamp();

// Converts a date string/Date from the request body into a real Firestore
// Timestamp, so downstream .toDate() calls (calendar view, sorting, isPast
// checks) work the same way they do for every other timestamp field in
// this app. Returns null for empty/invalid input.
const toFirestoreDate = (val) => {
  if (!val) return null;
  const d = val instanceof Date ? val : new Date(val);
  if (isNaN(d)) return null;
  return admin.firestore.Timestamp.fromDate(d);
};

// Flat lookup: serviceID -> serviceName, built from the grouped catalog
const SERVICE_LOOKUP = Object.fromEntries(
  SERVICE_CATALOG.flatMap((group) => group.services).map((s) => [s.serviceID, s.serviceName])
);

// Validates + normalizes the services[] array from a request body.
// Unknown serviceIDs are rejected unless they're explicitly marked custom
// (serviceID: "other"), which allows the frontend's free-text "Other" entry.
const normalizeServices = (services = []) => {
  if (!Array.isArray(services)) throw new Error("services must be an array.");

  return services.map((s) => {
    const price = Number(s.price) || 0;
    if (price < 0) throw new Error("Service price cannot be negative.");

    if (s.serviceID === "other") {
      if (!s.serviceName || !s.serviceName.trim()) {
        throw new Error("Custom services require a serviceName.");
      }
      return { serviceID: "other", serviceName: s.serviceName.trim(), price };
    }

    const knownName = SERVICE_LOOKUP[s.serviceID];
    if (!knownName) throw new Error(`Unknown serviceID: ${s.serviceID}`);

    return { serviceID: s.serviceID, serviceName: knownName, price };
  });
};

// Server-side total: sum of itemized services, unless overrideTotal is provided.
const computeTotal = (services, overrideTotal) => {
  if (overrideTotal !== undefined && overrideTotal !== null && overrideTotal !== "") {
    const total = Number(overrideTotal);
    if (total < 0) throw new Error("overrideTotal cannot be negative.");
    return total;
  }
  return services.reduce((sum, s) => sum + s.price, 0);
};

const toJSDate = (val) => {
  if (!val) return null;
  if (val.toDate) return val.toDate();
  const d = new Date(val);
  return isNaN(d) ? null : d;
};

const fmtDate = (d) => d.toLocaleDateString("en-PH", { month: "short", day: "numeric", year: "numeric" });

// Looks up a car's plate number for audit-log descriptions, so entries read
// "Maintenance for ABC-1234" instead of a bare carID. Falls back to the raw
// carID if the car doc is somehow gone by the time this runs.
const getPlateNumber = async (carID) => {
  if (!carID) return "unknown car";
  const snap = await db.collection("cars").doc(carID).get();
  return snap.exists ? snap.data().plateNumber || carID : carID;
};

// Checks whether `carID` has an active booking (pending/approved — i.e. the
// car will actually be out) whose date range overlaps the given day.
// Returns the conflicting booking, or null.
const findBookingConflict = async (carID, dateVal) => {
  const d = toJSDate(dateVal);
  if (!carID || !d) return null;

  const dayStart = new Date(d.getFullYear(), d.getMonth(), d.getDate(), 0, 0, 0);
  const dayEnd   = new Date(d.getFullYear(), d.getMonth(), d.getDate(), 23, 59, 59, 999);

  const snap = await db
    .collection("bookings")
    .where("carID", "==", carID)
    .where("status", "in", ["pending", "approved"])
    .get();

  for (const bDoc of snap.docs) {
    const b = bDoc.data();
    const bStart = toJSDate(b.startDateTime);
    const bEnd   = toJSDate(b.endDateTime);
    if (!bStart || !bEnd) continue;
    if (dayStart <= bEnd && dayEnd >= bStart) {
      return { id: bDoc.id, ...b };
    }
  }
  return null;
};

// Runs the conflict check against both dates and throws a descriptive
// error naming the conflicting booking, so the save is blocked with a
// clear reason rather than silently failing.
const assertNoBookingConflict = async (carID, maintenanceDate, nextMaintenanceDate, status) => {
  if (status === "Cancelled") return; // a cancelled record doesn't need the car

  const maintConflict = await findBookingConflict(carID, maintenanceDate);
  if (maintConflict) {
    throw new Error(
      `Cannot save: this car has an active booking (${maintConflict.bookingID || maintConflict.id}) ` +
      `from ${fmtDate(toJSDate(maintConflict.startDateTime))} to ${fmtDate(toJSDate(maintConflict.endDateTime))} ` +
      `that overlaps the maintenance date.`
    );
  }

  if (nextMaintenanceDate) {
    const nextConflict = await findBookingConflict(carID, nextMaintenanceDate);
    if (nextConflict) {
      throw new Error(
        `Cannot save: this car has an active booking (${nextConflict.bookingID || nextConflict.id}) ` +
        `from ${fmtDate(toJSDate(nextConflict.startDateTime))} to ${fmtDate(toJSDate(nextConflict.endDateTime))} ` +
        `that overlaps the next maintenance date.`
      );
    }
  }
};

// ─────────────────────────────────────────────
// CONFIG — basis / status / service catalog, so the frontend never
// has to hardcode its own copy of these lists.
// ─────────────────────────────────────────────
export const getMaintenanceConfig = () => ({
  basisOptions: BASIS_OPTIONS,
  statusOptions: STATUS_OPTIONS,
  serviceCatalog: SERVICE_CATALOG,
});

// ─────────────────────────────────────────────
// GET all maintenance records (with car plate/brand/model denormalized in)
// ─────────────────────────────────────────────
export const getAllMaintenance = async () => {
  const [maintSnap, carsSnap, brandSnap, modelSnap] = await Promise.all([
    db.collection("maintenance").orderBy("createdAt", "desc").get(),
    db.collection("cars").get(),
    db.collection("brand").get(),
    db.collection("model").get(),
  ]);

  const carMap = Object.fromEntries(carsSnap.docs.map((d) => [d.id, d.data()]));
  const brandMap = Object.fromEntries(brandSnap.docs.map((d) => [d.id, d.data().brandName]));
  const modelMap = Object.fromEntries(modelSnap.docs.map((d) => [d.id, d.data().modelName]));

  return maintSnap.docs.map((d) => {
    const data = d.data();
    const car = carMap[data.carID];
    return {
      id: d.id,
      ...data,
      plateNumber: car?.plateNumber || "—",
      brandName: car ? brandMap[car.brandID] || "—" : "—",
      modelName: car ? modelMap[car.modelID] || "—" : "—",
      createdAt: data.createdAt?.toDate ? data.createdAt.toDate().toISOString() : data.createdAt ?? null,
      updatedAt: data.updatedAt?.toDate ? data.updatedAt.toDate().toISOString() : data.updatedAt ?? null,
    };
  });
};

// ─────────────────────────────────────────────
// GET single maintenance record by ID
// ─────────────────────────────────────────────
export const getMaintenanceById = async (maintenanceID) => {
  const doc = await db.collection("maintenance").doc(maintenanceID).get();
  if (!doc.exists) throw new Error("Maintenance record not found.");
  return { id: doc.id, ...doc.data() };
};

// ─────────────────────────────────────────────
// GET all maintenance records for a single car
// ─────────────────────────────────────────────
export const getMaintenanceByCar = async (carID) => {
  const snap = await db
    .collection("maintenance")
    .where("carID", "==", carID)
    .orderBy("createdAt", "desc")
    .get();

  return snap.docs.map((d) => ({ id: d.id, ...d.data() }));
};

// Every maintenance record tied to one booking — powers the "linked
// maintenance" list on a booking's detail view (Bookings.jsx). Most
// bookings will return an empty array here, since routine maintenance
// isn't tied to any particular rental.
//
// No orderBy in the query itself on purpose — where("bookingID", ...) +
// orderBy("createdAt") on a different field needs a Firestore composite
// index that doesn't exist for this collection. Sorted client-side below
// instead, same visible result (newest first) without needing an index
// created for this collection — same tradeoff already made for
// editRequests/idResubmitRequests in the admin frontend's Account.jsx.
export const listMaintenanceForBooking = async (bookingID) => {
  const snap = await db
    .collection("maintenance")
    .where("bookingID", "==", bookingID)
    .get();

  const toMillis = (ts) => ts?.toMillis?.() ?? ts?._seconds * 1000 ?? 0;

  return snap.docs
    .map((d) => ({ id: d.id, ...d.data() }))
    .sort((a, b) => toMillis(b.createdAt) - toMillis(a.createdAt));
};

// ─────────────────────────────────────────────
// CREATE maintenance record
// ─────────────────────────────────────────────
// actor: { role } of whoever is creating it (the controller passes req.user.role).
// A Supervisor creating a record notifies the Owner(s); nobody else triggers it.
export const createMaintenance = async (payload, editedBy = null, actor = {}) => {
  const { carID, bookingID = null, basis, services = [], overrideTotal, description = "", maintenanceDate = null, nextMaintenanceDate = null, status, partsAddressed = [] } = payload;

  if (!carID) throw new Error("carID is required.");
  if (!BASIS_OPTIONS.includes(basis)) throw new Error(`Invalid basis. Must be one of: ${BASIS_OPTIONS.join(", ")}`);

  const finalStatus = status || "Scheduled";
  if (!STATUS_OPTIONS.includes(finalStatus)) throw new Error(`Invalid status. Must be one of: ${STATUS_OPTIONS.join(", ")}`);

  const carDoc = await db.collection("cars").doc(carID).get();
  if (!carDoc.exists) throw new Error("Car not found.");

  await assertNoBookingConflict(carID, maintenanceDate, nextMaintenanceDate, finalStatus);

  const normalizedServices = normalizeServices(services);
  const totalCost = computeTotal(normalizedServices, overrideTotal);

  const ref = await db.collection("maintenance").add({
    carID,
    // FK -> bookings. Null for routine/scheduled maintenance that isn't
    // tied to any one rental (oil changes, monthly checks). Set either
    // automatically (jobs/postRentalMaintenance.job.js, on the completed
    // booking) or manually via the "+ Post-Rental Maintenance" button on
    // a booking's detail view (Bookings.jsx's goToMaintenance), which
    // deep-links here with ?carID=&bookingID= pre-filled. See
    // listMaintenanceForBooking() below for the read side — this is what
    // lets a booking's detail view show "linked maintenance" and what a
    // penalty's optional maintenanceID field can point back to.
    bookingID,
    basis,
    services: normalizedServices,
    totalCost,
    overrideTotal: overrideTotal ? Number(overrideTotal) : null,
    description,
    maintenanceDate: toFirestoreDate(maintenanceDate),
    nextMaintenanceDate: toFirestoreDate(nextMaintenanceDate),
    status: finalStatus,
    // Which damaged/stolen/missing parts (from inventoryBeforeTrip/
    // inventoryAfterTrip's damageParts) this job is meant to fix. Not
    // resolved yet at creation — only actually applied to those trip
    // records once this maintenance record's status becomes "Completed"
    // (see updateMaintenanceStatus). Checking a box here just records
    // intent; a job that gets Cancelled instead should never mark a part
    // fixed that was never actually worked on.
    partsAddressed,
    createdAt: timestamp(),
    updatedAt: timestamp(),
  });

  // Mirror the doc's own ID onto itself, matching this app's existing convention
  await ref.update({ maintenanceID: ref.id });

  // Edge case: a record created already Completed (backdating a repair
  // that already happened) — resolve immediately rather than requiring a
  // separate edit afterward to trigger it.
  if (finalStatus === "Completed") {
    await resolveAddressedParts(ref.id, carID, partsAddressed);
  }

  await createAuditLog({
    action: "create",
    description: `Maintenance scheduled for ${carDoc.data().plateNumber || carID} (${basis}, ${finalStatus}): ` +
      `${description || "no description"} — total ₱${totalCost.toFixed(2)}.`,
    userID: editedBy,
  });

  createTransactionLog({
    type: "Expense",
    amount: totalCost,
    status: "Success",
    description: `${basis} for ${carDoc.data().plateNumber || carID}: ${description || "no description"}`,
    performedBy: editedBy,
    refID: ref.id,
    refCollection: "maintenance",
  }).catch((err) => console.error("[TXN] Maintenance expense log failed:", err.message));

  // A Supervisor scheduled this — let the Owner(s) know. Never blocks or fails the create.
  if (actor?.role === ROLES.SUPERVISOR) {
    try {
      let by = "A Supervisor";
      if (editedBy) {
        const [detail, user] = await Promise.all([
          db.collection("userDetails").doc(editedBy).get(),
          db.collection("user").doc(editedBy).get(),
        ]);
        const d = detail.exists ? detail.data() : {};
        const u = user.exists ? user.data() : {};
        const name = [d.firstName, d.lastName].filter(Boolean).join(" ").trim() || u.username || u.email;
        if (name) by = `${name} (Supervisor)`;
      }
      const plate = carDoc.data().plateNumber || carID;
      await notifyOwners({
        type: "maintenance_created",
        refID: ref.id,
        refCollection: "maintenance",
        title: "Maintenance Created",
        message: `${by} scheduled ${basis} maintenance for ${plate} (${finalStatus}) — ₱${totalCost.toFixed(2)}.`,
        extra: { carID },
      });
    } catch (err) {
      console.error("[MAINTENANCE] Owner notification failed:", err.message);
    }
  }

  return { id: ref.id };
};

// ─────────────────────────────────────────────
// UPDATE maintenance record
// ─────────────────────────────────────────────
// Resolves whichever damaged/stolen/missing parts a maintenance record's
// partsAddressed checklist named, by flipping each one's status to "Good"
// on its actual trip record (same write Maintenance.jsx's own "Mark
// Replaced" button uses). Called from both updateMaintenance (the real
// path the edit form's status picker actually uses) and
// updateMaintenanceStatus (the dedicated PATCH endpoint, kept in sync in
// case anything else calls it directly) — only ever on a genuine
// transition into "Completed", never on every re-save of an already-
// completed record, and never for Cancelled.
const resolveAddressedParts = async (maintenanceID, carID, partsAddressed) => {
  if (!Array.isArray(partsAddressed) || partsAddressed.length === 0) return;
  for (const p of partsAddressed) {
    try {
      await adminUpdateHistoryPartStatus({
        tripPhase: p.tripPhase,
        bookingID: p.bookingID,
        carID,
        carPartID: p.carPartID,
        newStatus: "Good",
        editedBy: null, // resolved via maintenance completion, not a direct admin edit
      });
    } catch (err) {
      // One part failing (e.g. its trip record was since deleted) shouldn't
      // block the others or the status update that already succeeded.
      console.error(`[MAINTENANCE] Failed to resolve part ${p.carPartID} on completion of ${maintenanceID}:`, err.message);
    }
  }
};

export const updateMaintenance = async (maintenanceID, payload, editedBy = null) => {
  const ref = db.collection("maintenance").doc(maintenanceID);
  const doc = await ref.get();
  if (!doc.exists) throw new Error("Maintenance record not found.");

  const { carID, basis, services, overrideTotal, description, maintenanceDate, nextMaintenanceDate, status, partsAddressed } = payload;
  const existing = doc.data();

  const effectiveCarID   = carID !== undefined ? carID : existing.carID;
  const effectiveMaintDate = maintenanceDate !== undefined ? maintenanceDate : existing.maintenanceDate;
  const effectiveNextDate  = nextMaintenanceDate !== undefined ? nextMaintenanceDate : existing.nextMaintenanceDate;
  const effectiveStatus    = status !== undefined ? status : existing.status;

  await assertNoBookingConflict(effectiveCarID, effectiveMaintDate, effectiveNextDate, effectiveStatus);

  const update = { updatedAt: timestamp() };

  if (carID !== undefined) update.carID = carID;

  if (basis !== undefined) {
    if (!BASIS_OPTIONS.includes(basis)) throw new Error(`Invalid basis. Must be one of: ${BASIS_OPTIONS.join(", ")}`);
    update.basis = basis;
  }

  if (status !== undefined) {
    if (!STATUS_OPTIONS.includes(status)) throw new Error(`Invalid status. Must be one of: ${STATUS_OPTIONS.join(", ")}`);
    update.status = status;
  }

  if (description !== undefined) update.description = description;
  if (maintenanceDate !== undefined) update.maintenanceDate = toFirestoreDate(maintenanceDate);
  if (nextMaintenanceDate !== undefined) update.nextMaintenanceDate = toFirestoreDate(nextMaintenanceDate);
  if (partsAddressed !== undefined) update.partsAddressed = partsAddressed;

  // Recompute total whenever services or overrideTotal change
  if (services !== undefined || overrideTotal !== undefined) {
    const normalizedServices = normalizeServices(services !== undefined ? services : existing.services);
    const effectiveOverride = overrideTotal !== undefined ? overrideTotal : existing.overrideTotal;

    update.services = normalizedServices;
    update.overrideTotal = effectiveOverride ? Number(effectiveOverride) : null;
    update.totalCost = computeTotal(normalizedServices, effectiveOverride);
  }

  await ref.update(update);

  // Fires only on a genuine transition into Completed (existing status
  // wasn't already Completed) — this is the endpoint the real edit form's
  // status picker actually calls, so this is where completion needs to be
  // caught, not just the unused dedicated PATCH endpoint below.
  if (update.status === "Completed" && existing.status !== "Completed") {
    const effectiveParts = partsAddressed !== undefined ? partsAddressed : existing.partsAddressed;
    await resolveAddressedParts(maintenanceID, effectiveCarID, effectiveParts);
  }

  const plate = await getPlateNumber(effectiveCarID);
  const statusNote = status !== undefined && status !== existing.status
    ? ` — status changed from ${existing.status} to ${status}`
    : "";
  await createAuditLog({
    action: "update",
    description: `Maintenance record for ${plate} updated${statusNote}.`,
    userID: editedBy,
  });

  // Only fires when the total actually changed. Rejects whatever Expense
  // entry this record logged before (creation, or an earlier revision) so
  // only one "live" Success entry per record ever counts toward a total,
  // then logs the new absolute amount as a fresh entry — same "one final
  // settled amount, not a delta" rule every other type in this ledger follows.
  if (update.totalCost !== undefined && update.totalCost !== existing.totalCost) {
    rejectTransactionLogsByRef(maintenanceID, "maintenance")
      .catch((err) => console.error("[TXN] Maintenance expense rejection (pre-revision) failed:", err.message));
    createTransactionLog({
      type: "Expense",
      amount: update.totalCost,
      status: "Success",
      description: `Revised maintenance cost for ${plate}: ₱${(existing.totalCost || 0).toFixed(2)} → ₱${update.totalCost.toFixed(2)}.`,
      performedBy: editedBy,
      refID: maintenanceID,
      refCollection: "maintenance",
    }).catch((err) => console.error("[TXN] Maintenance expense revision failed:", err.message));
  }

  return { id: maintenanceID };
};

// ─────────────────────────────────────────────
// UPDATE status only
// ─────────────────────────────────────────────
export const updateMaintenanceStatus = async (maintenanceID, status, editedBy = null) => {
  if (!STATUS_OPTIONS.includes(status)) throw new Error(`Invalid status. Must be one of: ${STATUS_OPTIONS.join(", ")}`);

  const ref = db.collection("maintenance").doc(maintenanceID);
  const doc = await ref.get();
  if (!doc.exists) throw new Error("Maintenance record not found.");
  const record = doc.data();

  await ref.update({ status, updatedAt: timestamp() });

  if (status === "Completed" && record.status !== "Completed") {
    await resolveAddressedParts(maintenanceID, record.carID, record.partsAddressed);
  }

  const plate = await getPlateNumber(record.carID);
  await createAuditLog({
    action: "update",
    description: `Maintenance status for ${plate} changed from ${record.status} to ${status}.`,
    userID: editedBy,
  });

  return { id: maintenanceID, status };
};

// ─────────────────────────────────────────────
// DELETE maintenance record
// ─────────────────────────────────────────────
export const deleteMaintenance = async (maintenanceID, editedBy = null) => {
  const ref = db.collection("maintenance").doc(maintenanceID);
  const doc = await ref.get();
  if (!doc.exists) throw new Error("Maintenance record not found.");
  const record = doc.data();

  await ref.delete();

  const plate = await getPlateNumber(record.carID);
  await createAuditLog({
    action: "delete",
    description: `Maintenance record for ${plate} deleted (was ${record.status}, ${record.basis}, ` +
      `${record.description || "no description"}).`,
    userID: editedBy,
  });

  // Rejects this record's live Expense entry (if any) so it stops
  // counting toward any Success-based total, without deleting it — the
  // ledger keeps it as history, just no longer "live".
  rejectTransactionLogsByRef(maintenanceID, "maintenance")
    .catch((err) => console.error("[TXN] Maintenance expense rejection (on delete) failed:", err.message));

  return { id: maintenanceID };
};