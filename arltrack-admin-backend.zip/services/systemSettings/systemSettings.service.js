import { db } from "../../config/firebaseConnection/firebase.js";
import admin from "firebase-admin";

const COLLECTION = "systemSettings";
const timestamp = () => admin.firestore.FieldValue.serverTimestamp();

// Defaults mirror the fallback constants in customer-backend/utils/pricing.js,
// so the very first read (before anyone has saved anything from the admin
// panel) returns the same numbers the system charges.
//
// serviceFeePercent / gatewayFeePercent are PERCENTAGES (0-100), not pesos:
//   service fee = serviceFeePercent % of the RENTAL FEE only (no extra fee,
//                 driver's fee or security deposit)
//   gateway fee = gatewayFeePercent % of everything else on the booking
//                 (rental + extra + driver's fee + service fee + security deposit)
// They replace the old flat serviceFee / gatewayFee pesos. Bookings already
// made keep the peso amounts they were charged (stored on each payment).
const DEFAULTS = {
  serviceFeePercent: 5,
  gatewayFeePercent: 5,
  extraFeeOutsideArea: 500,
  driversFeeBaseArea: 1000,
  driversFeeOutsideArea: 1500,
  baseAreaKeywords: ["manila", "bulacan"],
  // billingBlockHours intentionally omitted — see systemSettings.model.js
  // for why it stays a hardcoded constant in the customer backend instead.

  // In-store pickup location — null lat/lng means "not configured", and
  // the customer app hides the "Pick up in-store" option until both are set.
  storeName: "",
  storeLat: null,
  storeLng: null,

  // Security deposit + late-fee penalty settings — see
  // services/penalty/penalty.service.js, which snapshots these onto each
  // deposit/penalty at creation time so a later change here doesn't
  // retroactively affect bookings already in progress.
  securityDepositAmount: 1000, // ₱, refundable deposit collected at pickup
  lateFeeRatePerHour: 100,     // ₱ per billable hour late, after grace
  lateFeeGraceMinutes: 30,     // subtracted before rounding up to the next hour

  // Minimum gap between two trips for ONE driver. Dispatch treats a smaller gap as "tight" (a warning)
  // and the customer backend pads chauffeur bookings with it when checking if a driver is still free,
  // so both sides read this one value. 0 = trips may touch.
  driverBufferMinutes: 120,
};

// Percentage fields: must be a number between 0 and 100.
const PERCENT_FIELDS = ["serviceFeePercent", "gatewayFeePercent"];

const NUMERIC_FIELDS = [
  ...PERCENT_FIELDS,
  "extraFeeOutsideArea",
  "driversFeeBaseArea",
  "driversFeeOutsideArea",
  "securityDepositAmount",
  "lateFeeRatePerHour",
  "lateFeeGraceMinutes",
  "driverBufferMinutes",
];

// ─────────────────────────────────────────────
// systemSettings is a single combined doc shape — NOT split by a "type"
// field. Every save writes one complete snapshot containing every setting
// area (pricing today; other areas like maintenance can add their own
// fields onto this same doc shape later). There is only ever one kind of
// document in this collection.
//
// Get current settings. Reads the most recent doc (createdAt desc). If
// none exists yet, seeds one with DEFAULTS so the collection always has a
// doc after the first GET (simplifies the frontend — it never has to
// handle "no doc yet").
// ─────────────────────────────────────────────
export const getSystemSettings = async () => {
  const snap = await db
    .collection(COLLECTION)
    .orderBy("createdAt", "desc")
    .limit(1)
    .get();

  if (snap.empty) {
    const ref = db.collection(COLLECTION).doc();
    await ref.set({
      ...DEFAULTS,
      systemSettingsID: ref.id, // mirrors the doc's own ID, written in the same operation
      createdAt: timestamp(),
      updatedBy: null,
    });

    return { ...DEFAULTS, systemSettingsID: ref.id, createdAt: null, updatedBy: null };
  }

  return { ...DEFAULTS, ...snap.docs[0].data() };
};

// ─────────────────────────────────────────────
// Update settings. Only accepts known pricing fields — silently drops
// anything else in the payload so a stray/unexpected field can't get
// written. Validates numeric fields are numbers >= 0 before saving.
//
// Follows the same append-only pattern as the rest of the app (e.g.
// maintenance): every save creates a NEW doc rather than mutating the
// old one, carrying forward every existing field (pricing AND any other
// settings area that later gets added onto this same doc) so a partial
// save never wipes out unrelated settings. systemSettings doubles as a
// full history of every settings change; getSystemSettings() always
// reads back the most recent doc.
// ─────────────────────────────────────────────
export const updateSystemSettings = async (payload, actor) => {
  // Start from the current settings so a partial payload (e.g. just
  // { serviceFee }) still produces a complete new doc, not a sparse one —
  // this is what protects fields from OTHER settings areas (e.g. future
  // maintenance fields) from being dropped when only pricing is saved.
  const current = await getSystemSettings();
  const update = {};

  for (const field of NUMERIC_FIELDS) {
    if (payload[field] === undefined) continue;
    const num = Number(payload[field]);
    if (!Number.isFinite(num) || num < 0) {
      throw new Error(`${field} must be a number >= 0.`);
    }
    if (PERCENT_FIELDS.includes(field) && num > 100) {
      throw new Error(`${field} must be a percentage between 0 and 100.`);
    }
    update[field] = num;
  }

  if (payload.baseAreaKeywords !== undefined) {
    if (!Array.isArray(payload.baseAreaKeywords)) {
      throw new Error("baseAreaKeywords must be an array of strings.");
    }
    update.baseAreaKeywords = payload.baseAreaKeywords
      .map((k) => String(k).trim().toLowerCase())
      .filter(Boolean);
  }

  // ── Store location (in-store pickup) ──
  // storeLat/storeLng are validated as a pair — a name with no coordinates
  // (or vice versa) would leave the customer app's "in-store pickup"
  // condition (STORE_CONFIGURED-equivalent: name AND both coords set)
  // silently half-broken, so require them together.
  if (payload.storeName !== undefined || payload.storeLat !== undefined || payload.storeLng !== undefined) {
    const name = payload.storeName !== undefined ? String(payload.storeName).trim() : current.storeName;
    const lat  = payload.storeLat  !== undefined ? payload.storeLat  : current.storeLat;
    const lng  = payload.storeLng  !== undefined ? payload.storeLng  : current.storeLng;

    // Allow fully clearing it (all three blank/null) to turn the option off.
    const clearing = !name && (lat === null || lat === undefined) && (lng === null || lng === undefined);

    if (clearing) {
      update.storeName = "";
      update.storeLat  = null;
      update.storeLng  = null;
    } else {
      const latNum = Number(lat);
      const lngNum = Number(lng);
      if (!name) throw new Error("storeName is required when setting a store location.");
      if (!Number.isFinite(latNum) || latNum < -90 || latNum > 90) {
        throw new Error("storeLat must be a valid latitude between -90 and 90.");
      }
      if (!Number.isFinite(lngNum) || lngNum < -180 || lngNum > 180) {
        throw new Error("storeLng must be a valid longitude between -180 and 180.");
      }
      update.storeName = name;
      update.storeLat  = latNum;
      update.storeLng  = lngNum;
    }
  }

  if (Object.keys(update).length === 0) {
    throw new Error("No valid fields to update.");
  }

  // serviceFee / gatewayFee (flat pesos) are legacy — superseded by the
  // percent fields above. Drop them so new snapshots don't carry two sources
  // of truth for the same fee.
  const { systemSettingsID, createdAt, serviceFee: _legacyServiceFee, gatewayFee: _legacyGatewayFee, ...rest } = current;

  const ref = db.collection(COLLECTION).doc();
  await ref.set({
    ...rest,
    ...update,
    systemSettingsID: ref.id, // mirrors the doc's own ID, written in the same operation
    createdAt: timestamp(),
    updatedBy: actor ? { userID: actor.userID || actor.id || null, name: actor.name || actor.username || null } : null,
  });

  const snap = await ref.get();
  return { ...DEFAULTS, ...snap.data() };
};