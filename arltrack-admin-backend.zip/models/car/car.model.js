// Matches the actual 'cars' collection in Firestore
export const Car = {
  carID: "",
  modelID: "",        // references 'model' collection
  bodyType: "",       // e.g. "MPV", "SUV", "Sedan"
  color: "",
  fuelType: "",       // e.g. "Diesel", "Gasoline"
  plateNumber: "",
  seatingCapacity: 0,
  shortDescription: "",
  longDescription: "",
  transmission: "",   // "Automatic" | "Manual"
  year: 0,
  status: "",         // "Active" | "Inactive" | "Maintenance"
  // Only meaningful when status === "Inactive". Captured via a small modal
  // in Fleet.jsx when a car is switched to Maintenance or Inactive —
  // cleared (set back to null) if the car is later switched to any other
  // status. Free text; no fixed list.
  statusReason: null, // e.g. "Sold" | "Flat tire" | whatever staff typed
  // The car's standing geofence zones: [{ label, lat, lng, radius }], radius in METERS. They belong to the car (not to
  // the GPS tracker, which can be moved to another car, and not to one trip). Staff can set them any time from Car
  // Tracking (PATCH /api/gps/:carId/geofence-defaults, which overwrites the whole list). At pickup they are copied onto
  // that trip's bookingSessions.geofenceZones, but only if the session has no zones of its own (markSessionActive in
  // services/booking/bookingSession.service.js). Missing or [] = no default zones.
  defaultGeofenceZones: [],
  createdAt: null,
  updatedAt: null,
};