// Matches the 'userArchives' collection in Firestore.
// Primary key: userArchivesId (Firestore document ID)
//
// Written from controllers/user/user.controller.js's deleteUser(), which
// spreads the live 'user' doc's fields (see models/user/user.model.js) plus
// archivedAt/archivedBy. The archive's document ID IS the user's uid (set, not add).
//
// A deleted user's userDetails/userAddress/userDocument are deliberately
// NOT archived (or touched at all) here — they're left live and linked by
// userID for as long as this record sits in userArchives. Two things make
// that safe: (1) nothing in the app reads them without either a legitimate
// userID already in hand (from a booking/payment/refund) or a scoped,
// authenticated lookup, and (2)
// services/profileRequests/profileRequests.service.js's requireLiveUser()
// check stops a stale pending edit/ID-resubmit request from resurrecting
// them for an account that's already gone.
//
// The actual purge of userDetails/userAddress/userDocument (and the user's editRequests / idResubmitRequests, plus all their Storage files) happens in
// deleteUserArchive() (services/archives/userArchives.service.js) — that's
// the real point of no return for a deleted account, not this soft-delete
// step.
//
// NOTE: restore deletes this doc — see restoreUserArchive in
// services/archives/userArchives.service.js — rather than marking
// restoredAt/restoredBy, matching bookingArchives and
// bookingSessionArchives. Archiving only DISABLES the user's Firebase Auth login (same uid, email and password;
// they can't sign in while it is disabled), so restoring just switches it back on. The login is deleted for good only
// when this archive is permanently deleted (deleteUserArchive). Archives made before that change had their login
// deleted: restore recreates it under the same uid without a password and emails the customer to reset it.
//
// Restoring writes no restore stamp onto the live user doc either, so a user
// who is deleted (archived) again later carries none.
export const UserArchive = {
  userArchivesId: "",  // Firestore doc ID — same as collection name + "Id"
  // originalId is NOT stored any more: this archive document's ID IS the live document's ID (restore writes it back under that ID).
  // The archive list APIs still return it as originalId (= the document ID) so the pages keep working.
  // ---- copied from the live user document (see models/user/user.model.js) ----
  userID: "",
  createdAt: null,
  updatedAt: null,
  email: "",
  isVerified: false,
  isFlagged: false,
  phone: "",
  profileImage: "",
  roleID: "",
  status: "",           // whatever it was at time of deletion: "active" | "inactive" | "locked" (see user.model.js)
  username: "",
  referralCode: null,
  termsVersionID: null,
  termsAcceptedAt: null,
  // ---- bookkeeping ----
  archivedAt: null,
  archivedBy: "",
};