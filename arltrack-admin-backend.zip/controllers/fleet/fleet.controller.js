import {
  getAllCars,
  getCarById,
  addCar,
  updateCar,
  updateCarStatus,
  deleteCar,
  getPricingByCar,
  addPricingTier,
  updatePricingTier,
  deletePricingTier,
  replacePricingForCar,
  getAllBrands,
  addBrand,
  deleteBrand,
  getAllModels,
  addModel,
  deleteModel,
  setPrimaryCarImage,
  getOpenBookingsForCar,
  getCarBookingsForStatusChange,
} from "../../services/fleet/fleet.service.js";
import { createAuditLog } from "../../services/auditLogs/auditLogs.service.js";
import { consumeOtp, peekOtp } from "../otp/otp.controller.js";
import { staffRefundBooking } from "../../services/refundRequest/refundRequest.service.js";

// Statuses that need a reason + OTP + a clean bookings check before they can
// be written — see changeCarStatus() below. Leaving Maintenance/Inactive
// (going back to Active) never needs any of this.
const GATED_STATUSES = ["Maintenance", "Inactive"];

// ─────────────────────────────────────────────
// CARS
// ─────────────────────────────────────────────

// GET /api/fleet/cars
export const getCars = async (req, res) => {
  try {
    const data = await getAllCars();
    return res.status(200).json({ success: true, data });
  } catch (error) {
    console.error("[FLEET] getCars error:", error);
    return res.status(500).json({ success: false, message: error.message });
  }
};

// GET /api/fleet/cars/:carID
export const getCar = async (req, res) => {
  try {
    const { carID } = req.params;
    const data = await getCarById(carID);
    return res.status(200).json({ success: true, data });
  } catch (error) {
    console.error("[FLEET] getCar error:", error);
    const status = error.message === "Car not found." ? 404 : 500;
    return res.status(status).json({ success: false, message: error.message });
  }
};

// POST /api/fleet/cars
// Body: { brandID, modelID, platenumber, color, bodyType, year, seatingCapacity,
//         fuelType, transmission, status, shortDescription, longDescription,
//         pricing: [{ durationType, price }] }
export const createCar = async (req, res) => {
  try {
    const data = await addCar(req.body);
    return res.status(201).json({ success: true, data });
  } catch (error) {
    console.error("[FLEET] createCar error:", error);
    return res.status(400).json({ success: false, message: error.message });
  }
};

// PUT /api/fleet/cars/:carID
// Body: any subset of car fields (excluding pricing — use /pricing endpoints)
//
// Deliberately refuses to move status into Maintenance/Inactive from here —
// the EditCarModal's Details tab used to send status as just another field
// in this same call, which meant it could switch a car out of service with
// no reason, no bookings check, and no OTP. That whole flow now runs first
// against the dedicated /status endpoint below (reason → refund-any-upcoming
// bookings → OTP), and only THEN does the rest of the edit form save through
// here — with status either unchanged or already applied, either way fine.
export const editCar = async (req, res) => {
  try {
    const { carID } = req.params;
    if (GATED_STATUSES.includes(req.body?.status)) {
      const carDoc = await getCarById(carID).catch(() => null);
      if (carDoc && carDoc.status !== req.body.status) {
        return res.status(400).json({
          success: false,
          message: `Switching a car to ${req.body.status} needs a reason and confirmation — use the status control instead of Save Changes.`,
        });
      }
    }
    const data = await updateCar(carID, req.body);
    return res.status(200).json({ success: true, data });
  } catch (error) {
    console.error("[FLEET] editCar error:", error);
    const status = error.message === "Car not found." ? 404 : 500;
    return res.status(status).json({ success: false, message: error.message });
  }
};

// GET /api/fleet/cars/:carID/status-change-preview
// What staff see before confirming a switch to Maintenance/Inactive: every
// upcoming booking on this car (with what refunding it would cost) and
// every ongoing one (FYI only — the car's already with that customer, so
// there's nothing to refund or cancel here).
export const getStatusChangePreview = async (req, res) => {
  try {
    const { carID } = req.params;
    const data = await getCarBookingsForStatusChange(carID);
    return res.status(200).json({ success: true, data });
  } catch (error) {
    console.error("[FLEET] getStatusChangePreview error:", error);
    const status = error.message === "Car not found." ? 404 : 500;
    return res.status(status).json({ success: false, message: error.message });
  }
};

// PATCH /api/fleet/cars/:carID/status
// Body: { status, statusReason?, otp? }
//
// Moving TO Maintenance or Inactive is gated three ways: a reason is
// required, the acting staff member must supply a fresh OTP sent to their
// OWN email (consumeOtp — same "prove it's really you" mechanic already
// used for role changes, verified right here, right before anything real
// happens — not earlier in the flow, so the code that unlocks the actual
// money movement is the one actually protecting it), and every upcoming
// booking on the car gets refunded/cancelled in one batch, right here,
// server-side. The car's own upcoming-bookings list is re-derived from
// scratch on every call — never trusted from whatever the frontend showed
// a minute earlier, since a booking could appear in between. Moving to any
// other status (back to Active) skips all three — there's no
// bookings-safety concern leaving service.
//
// The batch is sequential and stops at the first real failure: anything
// already resolved before that point stays resolved (a real PayMongo
// refund can't be undone), the car's status is NOT written, and the
// response reports exactly what got through — see refundResults below.
// Retrying means a fresh OTP (the one just spent is single-use) and is
// safe to re-run: each booking's payment status is re-checked live before
// it's touched, so anything already resolved on a previous attempt is
// simply skipped rather than retried.
export const changeCarStatus = async (req, res) => {
  try {
    const { carID } = req.params;
    const { status, statusReason, otp } = req.body;
    if (!status) return res.status(400).json({ success: false, message: "status is required." });

    if (!GATED_STATUSES.includes(status)) {
      const data = await updateCarStatus(carID, status, null);
      createAuditLog({
        action: "update",
        description: `Status changed for car ${carID} to ${status}.`,
        userID: req.user?.uid || null,
      }).catch((err) => console.error("[FLEET] Failed to write audit log:", err));
      return res.status(200).json({ success: true, data: { ...data, statusChanged: true, refundResults: [] } });
    }

    const cleanReason = (statusReason || "").trim();
    if (!cleanReason) return res.status(400).json({ success: false, message: "A reason is required." });
    if (!otp) return res.status(400).json({ success: false, message: "Verification code is required." });
    // Only PEEK here (verify without burning). The code is spent below, after
    // the whole batch succeeded — otherwise one failed refund used up the code
    // and staff had to request + type a new one on every retry.
    const otpResult = await peekOtp(req.user?.email, otp);
    // `code` lets Fleet.jsx tell "the verification code is no good" (expired,
    // used up, locked out) apart from every other failure. The code is
    // checked BEFORE any refund runs, so nothing has happened yet when this
    // fires — the frontend sends staff back to get a fresh code instead of
    // leaving them on a dead-end error.
    if (!otpResult.ok) return res.status(otpResult.status).json({ success: false, code: "OTP_INVALID", message: otpResult.message });

    const { upcoming } = await getOpenBookingsForCar(carID);
    const refundResults = [];
    for (const booking of upcoming) {
      try {
        const r = await staffRefundBooking(booking.bookingID, cleanReason, req.user?.userID || req.user?.uid || null);
        refundResults.push({ bookingID: booking.bookingID, outcome: r.outcome, amount: r.amount, manualAmount: r.manualAmount, approvedExisting: !!r.approvedExisting });
      } catch (e) {
        refundResults.push({ bookingID: booking.bookingID, outcome: "failed", amount: 0, error: e.message });
        // Stop here — anything already resolved above is real and stays
        // that way; the status change itself does not go through.
        return res.status(200).json({
          success: true,
          message: `Stopped at ${booking.bookingID}: ${e.message}. The switch to ${status} was NOT applied. Anything already resolved above is final — request a fresh code and retry to finish the rest.`,
          data: { statusChanged: false, status: null, statusReason: null, refundResults },
        });
      }
    }

    const data = await updateCarStatus(carID, status, cleanReason);

    // Everything succeeded — now burn the code so it can't be replayed.
    await consumeOtp(req.user?.email, otp).catch((err) => console.error("[FLEET] consumeOtp after success failed:", err));

    createAuditLog({
      action: "update",
      description: `Status changed for car ${carID} to ${status}: ${cleanReason} (OTP-confirmed${refundResults.length > 0 ? `; ${refundResults.length} booking(s) resolved` : ""})`,
      userID: req.user?.uid || null,
    }).catch((err) => console.error("[FLEET] Failed to write audit log:", err));

    return res.status(200).json({
      success: true,
      data: { ...data, statusChanged: true, refundResults },
    });
  } catch (error) {
    console.error("[FLEET] changeCarStatus error:", error);
    const status = error.message === "Car not found." ? 404 : 400;
    return res.status(status).json({ success: false, message: error.message });
  }
};

// DELETE /api/fleet/cars/:carID
export const removeCar = async (req, res) => {
  try {
    const { carID } = req.params;
    const data = await deleteCar(carID);
    return res.status(200).json({ success: true, data });
  } catch (error) {
    console.error("[FLEET] removeCar error:", error);
    const status = error.message === "Car not found." ? 404 : 500;
    return res.status(status).json({ success: false, message: error.message });
  }
};

// ─────────────────────────────────────────────
// PRICING
// ─────────────────────────────────────────────

// GET /api/fleet/cars/:carID/pricing
export const getCarPricing = async (req, res) => {
  try {
    const { carID } = req.params;
    const data = await getPricingByCar(carID);
    return res.status(200).json({ success: true, data });
  } catch (error) {
    console.error("[FLEET] getCarPricing error:", error);
    return res.status(500).json({ success: false, message: error.message });
  }
};

// POST /api/fleet/cars/:carID/pricing
// Body: { durationType, price }
export const addCarPricing = async (req, res) => {
  try {
    const { carID } = req.params;
    const data = await addPricingTier(carID, req.body);
    return res.status(201).json({ success: true, data });
  } catch (error) {
    console.error("[FLEET] addCarPricing error:", error);
    return res.status(400).json({ success: false, message: error.message });
  }
};

// PUT /api/fleet/pricing/:pricingID
// Body: { durationType, price }
export const editCarPricing = async (req, res) => {
  try {
    const { pricingID } = req.params;
    const data = await updatePricingTier(pricingID, req.body);
    return res.status(200).json({ success: true, data });
  } catch (error) {
    console.error("[FLEET] editCarPricing error:", error);
    const status = error.message === "Pricing tier not found." ? 404 : 400;
    return res.status(status).json({ success: false, message: error.message });
  }
};

// DELETE /api/fleet/pricing/:pricingID
export const removeCarPricing = async (req, res) => {
  try {
    const { pricingID } = req.params;
    const data = await deletePricingTier(pricingID);
    return res.status(200).json({ success: true, data });
  } catch (error) {
    console.error("[FLEET] removeCarPricing error:", error);
    const status = error.message === "Pricing tier not found." ? 404 : 500;
    return res.status(status).json({ success: false, message: error.message });
  }
};

// PUT /api/fleet/cars/:carID/pricing/replace
// Body: { pricing: [{ durationType, price }] }
// Replaces ALL pricing tiers for the car at once (bulk save from modal)
export const replaceCarPricing = async (req, res) => {
  try {
    const { carID } = req.params;
    const { pricing } = req.body;
    if (!Array.isArray(pricing)) {
      return res.status(400).json({ success: false, message: "pricing must be an array." });
    }
    const data = await replacePricingForCar(carID, pricing);
    return res.status(200).json({ success: true, data });
  } catch (error) {
    console.error("[FLEET] replaceCarPricing error:", error);
    return res.status(500).json({ success: false, message: error.message });
  }
};

// ─────────────────────────────────────────────
// BRANDS
// ─────────────────────────────────────────────

// GET /api/fleet/brands
export const getBrands = async (req, res) => {
  try {
    const data = await getAllBrands();
    return res.status(200).json({ success: true, data });
  } catch (error) {
    console.error("[FLEET] getBrands error:", error);
    return res.status(500).json({ success: false, message: error.message });
  }
};

// POST /api/fleet/brands
// Body: { brandName }
export const createBrand = async (req, res) => {
  try {
    const { brandName } = req.body;
    const data = await addBrand(brandName);
    return res.status(201).json({ success: true, data });
  } catch (error) {
    console.error("[FLEET] createBrand error:", error);
    return res.status(400).json({ success: false, message: error.message });
  }
};

// DELETE /api/fleet/brands/:brandID
export const removeBrand = async (req, res) => {
  try {
    const { brandID } = req.params;
    const data = await deleteBrand(brandID);
    return res.status(200).json({ success: true, data });
  } catch (error) {
    console.error("[FLEET] removeBrand error:", error);
    const status = error.message === "Brand not found." ? 404 : 500;
    return res.status(status).json({ success: false, message: error.message });
  }
};

// ─────────────────────────────────────────────
// MODELS
// ─────────────────────────────────────────────

// GET /api/fleet/models?brandID=xxx  (optional filter)
export const getModels = async (req, res) => {
  try {
    const { brandID } = req.query;
    const data = await getAllModels(brandID);
    return res.status(200).json({ success: true, data });
  } catch (error) {
    console.error("[FLEET] getModels error:", error);
    return res.status(500).json({ success: false, message: error.message });
  }
};

// POST /api/fleet/models
// Body: { modelName, brandID }
export const createModel = async (req, res) => {
  try {
    const { modelName, brandID } = req.body;
    const data = await addModel(modelName, brandID);
    return res.status(201).json({ success: true, data });
  } catch (error) {
    console.error("[FLEET] createModel error:", error);
    return res.status(400).json({ success: false, message: error.message });
  }
};

// DELETE /api/fleet/models/:modelID
export const removeModel = async (req, res) => {
  try {
    const { modelID } = req.params;
    const data = await deleteModel(modelID);
    return res.status(200).json({ success: true, data });
  } catch (error) {
    console.error("[FLEET] removeModel error:", error);
    const status = error.message === "Model not found." ? 404 : 500;
    return res.status(status).json({ success: false, message: error.message });
  }
};

// ─────────────────────────────────────────────
// IMAGES
// ─────────────────────────────────────────────

// POST /api/fleet/cars/:carID/image
// Body: { imageURL } — the frontend uploads the file to Firebase Storage
// itself (client SDK) and sends the resulting downloadURL here; this
// endpoint only handles the Firestore carImages doc write, which used to
// happen directly from the browser with no role check or audit trail.
export const setCarImage = async (req, res) => {
  try {
    const { carID } = req.params;
    const { imageURL } = req.body;
    const data = await setPrimaryCarImage(carID, imageURL);

    createAuditLog({
      action: "update",
      description: `Updated primary image for car ${carID}.`,
      userID: req.user?.uid || null,
    }).catch((err) => console.error("[FLEET] Failed to write audit log:", err));

    return res.status(200).json({ success: true, data });
  } catch (error) {
    console.error("[FLEET] setCarImage error:", error);
    const status = error.message === "Car not found." ? 404 : 400;
    return res.status(status).json({ success: false, message: error.message });
  }
};