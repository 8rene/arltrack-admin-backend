import { saveLocation } from "../../services/gps/gps.service.js";
import { processLivePing } from "../../services/gps/livePing.service.js";
import { db } from "../../config/firebaseConnection/firebase.js";
import admin from "firebase-admin";

/** POST /api/gps  — GPS device pushes a live location */
export const receiveLocation = async (req, res) => {
  const { device_id, lat, lng } = req.body;
  if (!device_id || lat == null || lng == null) {
    return res.status(400).json({ status: "error", message: "device_id, lat, lng required." });
  }

  let data;
  try {
    data = await saveLocation(device_id, lat, lng);
  } catch (err) {
    console.error("[GPS] saveLocation failed:", err.message);
    return res.status(500).json({ status: "error", message: "Failed to save location." });
  }

  try {
    const deviceSnap = await db.collection("gpsDevice")
      .where("gpsDeviceID", "==", device_id).limit(1).get();

    if (!deviceSnap.empty) {
      await deviceSnap.docs[0].ref.update({
        lastLocation: { latitude: parseFloat(lat), longitude: parseFloat(lng) },
        updatedAt: admin.firestore.FieldValue.serverTimestamp(),
      });

      const assignedCarID = deviceSnap.docs[0].data().carID;
      if (assignedCarID) {
        processLivePing(assignedCarID, parseFloat(lat), parseFloat(lng)).catch((err) =>
          console.error("[GPS] processLivePing failed (raw ping was still saved):", err.message)
        );
      }
    }

    const locSnap = await db.collection("gpsLocation")
      .where("gpsDeviceID", "==", device_id).limit(1).get();

    if (!locSnap.empty) {
      await locSnap.docs[0].ref.update({
        latitude:   parseFloat(lat),
        longtitude: parseFloat(lng), // preserving existing typo in DB
        updatedAt:  admin.firestore.FieldValue.serverTimestamp(),
      });
    } else {
      await db.collection("gpsLocation").add({
        gpsDeviceID: device_id,
        latitude:    parseFloat(lat),
        longtitude:  parseFloat(lng), // preserving existing typo in DB
        updatedAt:   admin.firestore.FieldValue.serverTimestamp(),
        createdAt:   admin.firestore.FieldValue.serverTimestamp(),
      });
    }
  } catch (err) {
    console.error("[GPS] Firestore update failed:", err.message);
  }

  return res.json({ status: "ok", data });
};

/** GET /api/gps/:id  — Frontend reads one device's location from Firestore */
export const getDeviceLocation = async (req, res) => {
  try {
    const deviceId = req.params.id;

    const locSnap = await db.collection("gpsLocation")
      .where("gpsDeviceID", "==", deviceId).limit(1).get();

    if (!locSnap.empty) {
      const doc = locSnap.docs[0].data();
      return res.json({
        deviceId,
        lat:          parseFloat(doc.latitude)   || null,
        lng:          parseFloat(doc.longtitude) || parseFloat(doc.longitude) || null,
        lastLocation: doc.lastLocation || null,
        updatedAt:    doc.updatedAt?.toDate?.()?.toISOString?.() || null,
      });
    }

    const deviceSnap = await db.collection("gpsDevice")
      .where("gpsDeviceID", "==", deviceId).limit(1).get();

    if (!deviceSnap.empty) {
      const doc = deviceSnap.docs[0].data();
      const loc = doc.lastLocation;
      if (loc && typeof loc === "object" && loc.latitude && loc.longitude) {
        return res.json({
          deviceId,
          lat:          loc.latitude,
          lng:          loc.longitude,
          lastLocation: null,
          updatedAt:    doc.updatedAt?.toDate?.()?.toISOString?.() || null,
        });
      }
    }

    return res.json({});
  } catch (err) {
    console.error("[GPS] getDeviceLocation error:", err.message);
    return res.status(500).json({ status: "error", message: "Failed to fetch device location." });
  }
};

/** GET /api/gps  — Frontend reads ALL devices that have a stored location */
export const getAllDeviceLocations = async (req, res) => {
  try {
    const snap = await db.collection("gpsLocation").get();
    const data = snap.docs
      .map(d => {
        const doc = d.data();
        const lat = parseFloat(doc.latitude)   || doc.lastLocation?.latitude  || null;
        const lng = parseFloat(doc.longtitude) || parseFloat(doc.longitude)
                 || doc.lastLocation?.longitude || null;

        if (!lat || !lng) return null;

        return {
          deviceId:     doc.gpsDeviceID,
          lat,
          lng,
          lastLocation: doc.lastLocation || null,
          updatedAt:    doc.updatedAt?.toDate?.()?.toISOString?.() || null,
        };
      })
      .filter(Boolean);

    return res.json({ status: "ok", data });
  } catch (err) {
    console.error("[GPS] getAllDeviceLocations error:", err.message);
    return res.status(500).json({ status: "error", message: "Failed to fetch locations." });
  }
};

/** GET /api/gps/devices  — Get all GPS devices from gpsDevice collection */
export const getAllGpsDevices = async (req, res) => {
  try {
    // NOTE: previously used .orderBy("gpsName") here — Firestore silently
    // EXCLUDES any document missing the ordered field from the results
    // (no error, it just vanishes). Any device doc without a gpsName
    // (hand-created, seeded before the field existed, etc.) would never
    // show up on the page. Fetch everything and sort in memory instead so
    // no device can go missing just because a field is blank.
    const snap = await db.collection("gpsDevice").get();
    const devices = snap.docs
      .map(d => ({ id: d.id, ...d.data() }))
      .sort((a, b) => (a.gpsName || "").localeCompare(b.gpsName || ""));
    return res.json({ status: "ok", data: devices });
  } catch (err) {
    console.error("[GPS] getAllGpsDevices error:", err.message);
    return res.status(500).json({ status: "error", message: "Failed to fetch GPS devices." });
  }
};

/** POST /api/gps/devices  — Add a new GPS device (assigned = false by default) */
export const addGpsDevice = async (req, res) => {
  try {
    const snap  = await db.collection("gpsDevice").get();
    const count = snap.size + 1;

    const docRef = db.collection("gpsDevice").doc();

    await docRef.set({
      gpsDeviceID: docRef.id,
      gpsName:     `Gps Device Location ${count}`,
      assigned:    false,
      carID:       "",
      createdAt:   admin.firestore.FieldValue.serverTimestamp(),
      updatedAt:   admin.firestore.FieldValue.serverTimestamp(),
    });

    const newDoc = await docRef.get();
    return res.status(201).json({ status: "ok", data: { id: docRef.id, ...newDoc.data() } });
  } catch (err) {
    console.error("[GPS] addGpsDevice error:", err.message);
    return res.status(500).json({ status: "error", message: "Failed to add GPS device." });
  }
};

/** PUT /api/gps/devices/:id/unassign  — Detach a car from a GPS device */
export const unassignDeviceFromCar = async (req, res) => {
  const { id } = req.params;

  try {
    const docRef = db.collection("gpsDevice").doc(id);
    const doc    = await docRef.get();

    if (!doc.exists) {
      return res.status(404).json({ status: "error", message: "GPS device not found." });
    }

    const { carID: previousCarID } = doc.data();

    await docRef.update({
      carID:     "",
      assigned:  false,
      updatedAt: admin.firestore.FieldValue.serverTimestamp(),
    });

    // Reverse of assignCarToDevice's sync — that car's upcoming bookings no
    // longer have a device, so Car Tracking's badge should reappear for them.
    if (previousCarID) {
      const upcomingSnap = await db.collection("bookings")
        .where("carID", "==", previousCarID)
        .where("status", "==", "upcoming")
        .get();

      if (!upcomingSnap.empty) {
        const batch = db.batch();
        upcomingSnap.docs.forEach((doc) => batch.update(doc.ref, { hasDevice: false }));
        await batch.commit();
      }
    }

    return res.json({ status: "ok", message: "Car unassigned from GPS device." });
  } catch (err) {
    console.error("[GPS] unassignDeviceFromCar error:", err.message);
    return res.status(500).json({ status: "error", message: "Failed to unassign car." });
  }
};

/** PATCH /api/gps/devices/:id  — Rename a GPS device */
export const updateGpsDevice = async (req, res) => {
  const { id }      = req.params;
  const { gpsName } = req.body;

  if (!gpsName || !gpsName.trim()) {
    return res.status(400).json({ status: "error", message: "gpsName is required." });
  }

  try {
    const docRef = db.collection("gpsDevice").doc(id);
    const doc    = await docRef.get();

    if (!doc.exists) {
      return res.status(404).json({ status: "error", message: "GPS device not found." });
    }

    await docRef.update({
      gpsName:   gpsName.trim(),
      updatedAt: admin.firestore.FieldValue.serverTimestamp(),
    });

    const updated = await docRef.get();
    return res.json({ status: "ok", data: { id: docRef.id, ...updated.data() } });
  } catch (err) {
    console.error("[GPS] updateGpsDevice error:", err.message);
    return res.status(500).json({ status: "error", message: "Failed to rename GPS device." });
  }
};

/** DELETE /api/gps/devices/:id  — Permanently remove a GPS device */
export const deleteGpsDevice = async (req, res) => {
  const { id } = req.params;

  try {
    const docRef = db.collection("gpsDevice").doc(id);
    const doc    = await docRef.get();

    if (!doc.exists) {
      return res.status(404).json({ status: "error", message: "GPS device not found." });
    }

    await docRef.delete();
    return res.json({ status: "ok", message: "GPS device deleted." });
  } catch (err) {
    console.error("[GPS] deleteGpsDevice error:", err.message);
    return res.status(500).json({ status: "error", message: "Failed to delete GPS device." });
  }
};
export const assignCarToDevice = async (req, res) => {
  const { id }    = req.params;
  const { carID } = req.body;

  if (!carID) {
    return res.status(400).json({ status: "error", message: "carID is required." });
  }

  try {
    const docRef = db.collection("gpsDevice").doc(id);
    const doc    = await docRef.get();

    if (!doc.exists) {
      return res.status(404).json({ status: "error", message: "GPS device not found." });
    }

    await docRef.update({
      carID:     carID,
      assigned:  true,
      updatedAt: admin.firestore.FieldValue.serverTimestamp(),
    });

    // Sync to booking: any upcoming booking for this car no longer has a
    // "no device" gap — this is what Car Tracking's badge query reads.
    const upcomingSnap = await db.collection("bookings")
      .where("carID", "==", carID)
      .where("status", "==", "upcoming")
      .get();

    if (!upcomingSnap.empty) {
      const batch = db.batch();
      upcomingSnap.docs.forEach((doc) => batch.update(doc.ref, { hasDevice: true }));
      await batch.commit();
    }

    return res.json({ status: "ok", message: "Car assigned to GPS device." });
  } catch (err) {
    console.error("[GPS] assignCarToDevice error:", err.message);
    return res.status(500).json({ status: "error", message: "Failed to assign car." });
  }
};